<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>LibraryTree</name>
    <message>
        <location filename="../library/LibraryModel.cpp" line="428"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="430"/>
        <source>Location</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="432"/>
        <source>Platform</source>
        <translation>平台</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="434"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="436"/>
        <source>CRC32</source>
        <translation>CRC32</translation>
    </message>
</context>
<context>
    <name>QGBA</name>
    <message>
        <location filename="../utils.cpp" line="109"/>
        <source>Game Boy Advance ROMs (%1)</source>
        <translation>Game Boy Advance ROMs (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="135"/>
        <source>Game Boy ROMs (%1)</source>
        <translation>Game Boy ROMs (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="140"/>
        <source>All ROMs (%1)</source>
        <translation>所有 ROMs (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="142"/>
        <source>%1 Video Logs (*.mvl)</source>
        <translation>%1 视频日志 (*.mvl)</translation>
    </message>
</context>
<context>
    <name>QGBA::AboutScreen</name>
    <message>
        <location filename="../AboutScreen.ui" line="14"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="23"/>
        <source>&lt;a href=&quot;http://mgba.io/&quot;&gt;Website&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Forums / Support&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Donate&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Source&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;http://mgba.io/&quot;&gt;网站&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;论坛、支持&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;捐助&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;源代码&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="41"/>
        <source>Branch: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revision: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</source>
        <translation>分支: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;修订版: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="68"/>
        <source>{projectName} would like to thank the following patrons from Patreon:</source>
        <translation>{projectName} 感谢以下来自 Patreon 的赞助者:</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="86"/>
        <source>© 2013 – {year} Jeffrey Pfau, licensed under the Mozilla Public License, version 2.0
Game Boy Advance is a registered trademark of Nintendo Co., Ltd.</source>
        <translation>© 2013 – {year} Jeffrey Pfau，基于 Mozilla 公共许可证（版本 2.0）授权
Game Boy Advance 是任天堂有限公司（Nintendo Co., Ltd.）的注册商标。</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="177"/>
        <source>{projectName} is an open-source Game Boy Advance emulator</source>
        <translation>{projectName} 是开放源代码的 Game Boy Advance 模拟器</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdatePrompt</name>
    <message>
        <location filename="../ApplicationUpdatePrompt.ui" line="14"/>
        <source>An update is available</source>
        <translation>有可用的更新</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="27"/>
        <source>An update to %1 is available.
</source>
        <translation>%1 有更新可用。
</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="39"/>
        <source>
Do you want to download and install it now? You will need to restart the emulator when the download is complete.</source>
        <translation>
你想现在下载并安装吗？下载完成后，你需要重新启动模拟器。</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="42"/>
        <source>
Auto-update is not available on this platform. If you wish to update you will need to do it manually.</source>
        <translation>
自动更新在此平台上不可用。如果您希望更新，则需要手动进行。</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="46"/>
        <source>Current version: %1
New version: %2
Download size: %3</source>
        <translation>当前版本：%1
新版本：%2
更新大小：%3</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="64"/>
        <source>Downloading update...</source>
        <translation>正在下载更新...</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="78"/>
        <source>Verifying download failed. Please update manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="82"/>
        <source>Downloading failed. Please update manually.</source>
        <translation>下载失败。请手动更新。</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="84"/>
        <source>Downloading done. Press OK to restart %1 and install the update.</source>
        <translation>下载完成。按确定按钮以重新启动 %1 并安装更新。</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdater</name>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="95"/>
        <source>Stable</source>
        <translation>稳定版</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="98"/>
        <source>Development</source>
        <translation>开发版</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="100"/>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="246"/>
        <source>(None)</source>
        <translation>（无）</translation>
    </message>
</context>
<context>
    <name>QGBA::ArchiveInspector</name>
    <message>
        <location filename="../ArchiveInspector.ui" line="14"/>
        <source>Open in archive...</source>
        <translation>打开压缩文件...</translation>
    </message>
    <message>
        <location filename="../ArchiveInspector.ui" line="20"/>
        <source>Loading...</source>
        <translation>正在载入...</translation>
    </message>
</context>
<context>
    <name>QGBA::AssetTile</name>
    <message>
        <location filename="../AssetTile.ui" line="41"/>
        <source>Tile #</source>
        <translation>图块 #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="65"/>
        <source>Palette #</source>
        <translation>调色板 #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="89"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="138"/>
        <source>Red</source>
        <translation>红</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="145"/>
        <source>Green</source>
        <translation>绿</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="152"/>
        <source>Blue</source>
        <translation>蓝</translation>
    </message>
    <message>
        <location filename="../AssetTile.cpp" line="144"/>
        <location filename="../AssetTile.cpp" line="145"/>
        <location filename="../AssetTile.cpp" line="146"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioDevice</name>
    <message>
        <location filename="../AudioDevice.cpp" line="36"/>
        <source>Can&apos;t set format of context-less audio device</source>
        <translation>无法设置无上下文音频设备的格式</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="57"/>
        <source>Audio device is missing its core</source>
        <translation>音频设备缺少其核心</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="85"/>
        <source>Writing data to read-only audio device</source>
        <translation>将数据写入只读音频设备</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorDummy</name>
    <message>
        <location filename="../AudioProcessorDummy.cpp" line="31"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation type="unfinished">没有输入无法启动音频处理器</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorQt</name>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="57"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>没有输入无法启动音频处理器</translation>
    </message>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="82"/>
        <source>Audio outputting to %1</source>
        <translation>音频输出至 %1</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorSDL</name>
    <message>
        <location filename="../AudioProcessorSDL.cpp" line="35"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>没有输入无法启动音频处理器</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptModel</name>
    <message>
        <location filename="../scripting/AutorunScriptModel.cpp" line="32"/>
        <source>Could not load autorun script settings: unknown script info format %1</source>
        <translation>无法加载自动运行脚本设置：未知的脚本信息格式 %1</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptView</name>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="14"/>
        <source>Autorun scripts</source>
        <translation>自动运行脚本</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="20"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="30"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="53"/>
        <source>Move up</source>
        <translation>上移</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="63"/>
        <source>Move down</source>
        <translation>下移</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="73"/>
        <source>Run scripts when starting a game</source>
        <translation>启动游戏时运行脚本</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.cpp" line="29"/>
        <source>Select a script</source>
        <translation>选择一个脚本</translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipModel</name>
    <message>
        <location filename="../BattleChipModel.cpp" line="113"/>
        <source>Failed to open chip names list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipView</name>
    <message>
        <location filename="../BattleChipView.ui" line="14"/>
        <source>BattleChip Gate</source>
        <translation>BattleChip Gate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="67"/>
        <source>Chip name</source>
        <translation>芯片名称</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="76"/>
        <source>Insert</source>
        <translation>插入</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="87"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="94"/>
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="114"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="121"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="138"/>
        <source>Gate type</source>
        <translation>Gate 类型</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="180"/>
        <source>Inserted</source>
        <translation>已插入</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="194"/>
        <source>Chip ID</source>
        <translation>芯片 ID</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="207"/>
        <source>Update Chip data</source>
        <translation>更新芯片数据</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="219"/>
        <source>Show advanced</source>
        <translation>显示高级选项</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="112"/>
        <source>BattleChip data missing</source>
        <translation>缺失 BattleChip 数据</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="113"/>
        <source>BattleChip data is missing. BattleChip Gates will still work, but some graphics will be missing. Would you like to download the data now?</source>
        <translation>缺少 BattleChip 数据。BattleChip Gate 仍然可以使用,但一些图形将会丢失。您要立即下载数据吗？</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="179"/>
        <location filename="../BattleChipView.cpp" line="198"/>
        <source>Select deck file</source>
        <translation>选择卡座文件</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="210"/>
        <source>Incompatible deck</source>
        <translation>不兼容的卡座</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="211"/>
        <source>The selected deck is not compatible with this Chip Gate</source>
        <translation>选定的卡座与此 Chip Gate 不兼容</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsModel</name>
    <message>
        <location filename="../CheatsModel.cpp" line="54"/>
        <source>(untitled)</source>
        <translation>(无标题)</translation>
    </message>
    <message>
        <location filename="../CheatsModel.cpp" line="212"/>
        <source>Failed to open cheats file: %1</source>
        <translation>打开作弊码文件失败: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsView</name>
    <message>
        <location filename="../CheatsView.ui" line="14"/>
        <source>Cheats</source>
        <translation>作弊码</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="39"/>
        <source>Add New Code</source>
        <translation>添加作弊码</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="60"/>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="93"/>
        <source>Add Lines</source>
        <translation>添加行</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="100"/>
        <source>Code type</source>
        <translation>作弊码类型</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="53"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="46"/>
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="86"/>
        <source>Enter codes here...</source>
        <translation>在此处输入代码...</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="50"/>
        <location filename="../CheatsView.cpp" line="58"/>
        <source>Autodetect (recommended)</source>
        <translation>自动检测（推荐）</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="88"/>
        <location filename="../CheatsView.cpp" line="95"/>
        <source>Select cheats file</source>
        <translation>选择作弊码文件</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="187"/>
        <source>Some cheats could not be added. Please ensure they&apos;re formatted correctly and/or try other cheat types.</source>
        <translation>无法添加某些作弊码。请确认它们的格式是否正确并且/或尝试其它的作弊类型。</translation>
    </message>
</context>
<context>
    <name>QGBA::CoreController</name>
    <message>
        <location filename="../CoreController.cpp" line="106"/>
        <source>Reset r%1-%2 %3</source>
        <translation>重置 r%1-%2 %3</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="554"/>
        <location filename="../CoreController.cpp" line="571"/>
        <source>Rewinding not currently enabled</source>
        <translation>当前未开启倒带</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="610"/>
        <source>Reset the game?</source>
        <translation>要重置游戏吗?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="611"/>
        <source>Most games will require a reset to load the new save. Do you want to reset now?</source>
        <translation>大多数游戏需要重置才能加载新的存档。您要立即重启吗?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="829"/>
        <source>Failed to open save file: %1</source>
        <translation>打开存档失败: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="887"/>
        <source>Failed to open game file: %1</source>
        <translation>打开游戏文件失败: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="917"/>
        <source>Can&apos;t yank pack in unexpected platform!</source>
        <translation>无法在意外平台上抽出卡带！</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1032"/>
        <source>Failed to open snapshot file for reading: %1</source>
        <translation>读取快照文件失败: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1049"/>
        <source>Failed to open snapshot file for writing: %1</source>
        <translation>写入快照文件失败: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CoreManager</name>
    <message>
        <location filename="../CoreManager.cpp" line="58"/>
        <source>Failed to open game file: %1</source>
        <translation>打开游戏文件失败: %1</translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="105"/>
        <source>Temporary file loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="106"/>
        <source>The ROM appears to be loaded from a temporary directory, perhaps automatically extracted from an archive (e.g. a zip file).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="154"/>
        <source>Could not open save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="155"/>
        <source>Failed to open save file; in-game saves cannot be updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="228"/>
        <source>Would you like to copy the ROM to a different location? If you don&apos;t, this will likely lead to data loss (e.g. saves, screenshots, etc.).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="235"/>
        <source>Copy failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="235"/>
        <source>Failed to copy ROM. Do you want to try again?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="242"/>
        <source>New ROM location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="126"/>
        <source>Could not load game. Are you sure it&apos;s in the correct format?</source>
        <translation>无法载入游戏。请确认游戏格式是否正确？</translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsole</name>
    <message>
        <location filename="../DebuggerConsole.ui" line="14"/>
        <source>Debugger</source>
        <translation>调试器</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="27"/>
        <source>Enter command (try `help` for more info)</source>
        <translation>输入命令 (尝试输入 `help` 获取更多信息)</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="34"/>
        <source>Break</source>
        <translation>断点</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="44"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsoleController</name>
    <message>
        <location filename="../DebuggerConsoleController.cpp" line="190"/>
        <source>Could not open CLI history for writing</source>
        <translation>无法打开用于写入的 CLI 历史</translation>
    </message>
</context>
<context>
    <name>QGBA::DisplayGL</name>
    <message>
        <location filename="../DisplayGL.cpp" line="310"/>
        <source>Failed to create an OpenGL 3 context, trying old-style...</source>
        <translation>创建OpenGL3环境失败，请尝试旧形式...</translation>
    </message>
</context>
<context>
    <name>QGBA::DolphinConnector</name>
    <message>
        <location filename="../DolphinConnector.ui" line="14"/>
        <source>Connect to Dolphin</source>
        <translation>连接 Dolphin</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="23"/>
        <source>Local computer</source>
        <translation>本地电脑</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="36"/>
        <source>IP address</source>
        <translation>IP 地址</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="55"/>
        <source>Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="68"/>
        <source>Disconnect</source>
        <translation>断开连接</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="78"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="90"/>
        <source>Reset on connect</source>
        <translation>连接时重置</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="58"/>
        <source>Couldn&apos;t Connect</source>
        <translation>无法连接</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="59"/>
        <source>Could not connect to Dolphin.</source>
        <translation>无法连接到 Dolphin。</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator</name>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="84"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="86"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator3DS</name>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="30"/>
        <source>Icon</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="31"/>
        <source>Banner</source>
        <translation>横幅</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGeneratorVita</name>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="26"/>
        <source>Bubble</source>
        <translation>气泡</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="27"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="28"/>
        <source>Startup</source>
        <translation>启动</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderView</name>
    <message>
        <location filename="../ForwarderView.ui" line="14"/>
        <source>Create forwarder</source>
        <translation>创建转发器</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="20"/>
        <source>Files</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="26"/>
        <source>ROM file:</source>
        <translation>ROM 文件:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="36"/>
        <location filename="../ForwarderView.ui" line="53"/>
        <location filename="../ForwarderView.ui" line="112"/>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="43"/>
        <source>Output filename:</source>
        <translation>输出文件名:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="60"/>
        <source>Forwarder base:</source>
        <translation>转发器基础:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="74"/>
        <source>Latest stable version</source>
        <translation>最新稳定版本</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="79"/>
        <source>Latest development build</source>
        <translation>最新开发版本</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="84"/>
        <source>Specific file</source>
        <translation>指定文件</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="95"/>
        <source>Base file:</source>
        <translation>基础文件:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="135"/>
        <source>System</source>
        <translation>系统</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="141"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="151"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="174"/>
        <source>Presentation</source>
        <translation>介绍</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="182"/>
        <source>Title:</source>
        <translation>标题:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="195"/>
        <source>Images:</source>
        <translation>图像:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="215"/>
        <source>Use default image</source>
        <translation>使用默认图像</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="328"/>
        <source>Preferred size:</source>
        <translation>首选大小:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="395"/>
        <source>Select image file</source>
        <translation>选择图像文件</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="23"/>
        <source>Select ROM file</source>
        <translation>选择 ROM 文件</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="24"/>
        <source>Select output filename</source>
        <translation>选择输出文件名</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="25"/>
        <source>Select base file</source>
        <translation>选择基础文件</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="37"/>
        <source>Build finished</source>
        <translation>已完成构建</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="38"/>
        <source>Forwarder finished building</source>
        <translation>已完成构建转发器</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="45"/>
        <source>Build failed</source>
        <translation>构建失败</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="46"/>
        <source>Failed to build forwarder</source>
        <translation>构建转发器失败</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="177"/>
        <source>%1 installable package (*.%2)</source>
        <translation>%1 可安装数据包 (*.%2)</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="193"/>
        <source>Select an image</source>
        <translation>选择一个图像</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="193"/>
        <source>Image files (*.png *.jpg *.bmp)</source>
        <translation>图像文件 (*.png *.jpg *.bmp)</translation>
    </message>
</context>
<context>
    <name>QGBA::FrameView</name>
    <message>
        <location filename="../FrameView.ui" line="14"/>
        <source>Inspect frame</source>
        <translation>检查框架</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="41"/>
        <source>Magnification</source>
        <translation>缩放率</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="50"/>
        <source>Freeze frame</source>
        <translation>冻结框架</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="84"/>
        <source>Backdrop color</source>
        <translation>背幕颜色</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="132"/>
        <source>Disable scanline effects</source>
        <translation>禁用扫描线效果</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="145"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="152"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="592"/>
        <source>Export frame</source>
        <translation>导出框架</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="593"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>便携式网络图形 (*.png)</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="623"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="625"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="628"/>
        <source>Window</source>
        <translation>窗口</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="631"/>
        <source>Objwin</source>
        <translation>Objwin</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="636"/>
        <source>Sprite</source>
        <translation>精灵图</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="639"/>
        <source>Backdrop</source>
        <translation>背幕</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="642"/>
        <source>Frame</source>
        <translation>帧</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="648"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAApp</name>
    <message>
        <location filename="../GBAApp.cpp" line="84"/>
        <source>Enable Discord Rich Presence</source>
        <translation>启用 Discord Rich Presence</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAKeyEditor</name>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="70"/>
        <source>Clear Button</source>
        <translation>清除按键</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="82"/>
        <source>Clear Analog</source>
        <translation>清除模拟控制</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="93"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="103"/>
        <source>Set all</source>
        <translation>全部设置</translation>
    </message>
</context>
<context>
    <name>QGBA::GDBWindow</name>
    <message>
        <location filename="../GDBWindow.cpp" line="32"/>
        <source>Server settings</source>
        <translation>服务器设置</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="38"/>
        <source>Local port</source>
        <translation>本地端口</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="40"/>
        <source>Bind address</source>
        <translation>绑定地址</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="53"/>
        <source>Write watchpoints behavior</source>
        <translation>写入监视点行为</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="64"/>
        <source>Standard GDB</source>
        <translation>标准 GDB</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="69"/>
        <source>Internal change detection</source>
        <translation>内部改动检测</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="73"/>
        <source>Break on all writes</source>
        <translation>中断所有写入</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="83"/>
        <source>Break</source>
        <translation>断点</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="125"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="138"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="146"/>
        <source>Crash</source>
        <translation>崩溃</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="146"/>
        <source>Could not start GDB server</source>
        <translation>无法打开 GDB 服务器</translation>
    </message>
</context>
<context>
    <name>QGBA::GIFView</name>
    <message>
        <location filename="../GIFView.ui" line="14"/>
        <source>Record GIF/WebP/APNG</source>
        <translation>录制 GIF/WebP/APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="30"/>
        <source>Loop</source>
        <translation>循环</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="51"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="67"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="93"/>
        <source>Select File</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="112"/>
        <source>APNG</source>
        <translation>APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="122"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="135"/>
        <source>WebP</source>
        <translation>WebP</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="145"/>
        <source>Frameskip</source>
        <translation>跳帧</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="64"/>
        <source>Failed to open output file: %1</source>
        <translation>打开输出文件失败: %1</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="91"/>
        <source>Select output file</source>
        <translation>选择输出文件</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="91"/>
        <source>Graphics Interchange Format (*.gif);;WebP ( *.webp);;Animated Portable Network Graphics (*.png *.apng)</source>
        <translation>图形交换格式 (*.gif);;WebP ( *.webp);;动画便携式网络图形 (*.png *.apng)</translation>
    </message>
</context>
<context>
    <name>QGBA::GameBoy</name>
    <message>
        <location filename="../GameBoy.cpp" line="62"/>
        <location filename="../GameBoy.cpp" line="81"/>
        <source>Autodetect</source>
        <translation>自动检测</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="63"/>
        <source>Game Boy (DMG)</source>
        <translation>Game Boy (DMG)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="64"/>
        <source>Game Boy Pocket (MGB)</source>
        <translation>Game Boy Pocket (MGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="65"/>
        <source>Super Game Boy (SGB)</source>
        <translation>Super Game Boy (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="66"/>
        <source>Super Game Boy 2 (SGB)</source>
        <translation>Super Game Boy 2 (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="67"/>
        <source>Game Boy Color (CGB)</source>
        <translation>Game Boy Color (CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="68"/>
        <source>Game Boy Advance (AGB)</source>
        <translation>Game Boy Advance (AGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="69"/>
        <source>Super Game Boy Color (SGB + CGB)</source>
        <translation>Super Game Boy Color (SGB + CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="82"/>
        <source>ROM Only</source>
        <translation>仅 ROM</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="86"/>
        <source>%1 + RTC</source>
        <translation>%1 + RTC(实时时钟)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="88"/>
        <source>%1 + Rumble</source>
        <translation>%1 + Rumble(震动)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="90"/>
        <source>%1 (Tilt)</source>
        <translation>%1 (Tilt)(重力感应)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="98"/>
        <source>%1 (old 1)</source>
        <translation>%1 (旧 1)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="99"/>
        <source>%1 (old 2)</source>
        <translation>%1 (旧 2)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="100"/>
        <source>%1 (new)</source>
        <translation>%1 新)</translation>
    </message>
</context>
<context>
    <name>QGBA::IOViewer</name>
    <message>
        <location filename="../IOViewer.ui" line="14"/>
        <source>I/O Viewer</source>
        <translation>I/O 查看器</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="26"/>
        <source>0x0000</source>
        <translation>0x0000</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="367"/>
        <location filename="../IOViewer.cpp" line="871"/>
        <location filename="../IOViewer.cpp" line="884"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="40"/>
        <source>Background mode</source>
        <translation>后台模式</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="41"/>
        <source>Mode 0: 4 tile layers</source>
        <translation>模式 0: 4 个图块层</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="42"/>
        <source>Mode 1: 2 tile layers + 1 rotated/scaled tile layer</source>
        <translation>模式 1: 2 个图块层 + 1 个旋转/缩放图块层</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="43"/>
        <source>Mode 2: 2 rotated/scaled tile layers</source>
        <translation>模式 2: 2 个旋转/缩放图块层</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="44"/>
        <source>Mode 3: Full 15-bit bitmap</source>
        <translation>模式 3: 15 位完整位图</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="45"/>
        <source>Mode 4: Full 8-bit bitmap</source>
        <translation>模式 4: 8 位完整位图</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="46"/>
        <source>Mode 5: Small 15-bit bitmap</source>
        <translation>模式 5: 15 位小位图</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="50"/>
        <source>CGB Mode</source>
        <translation>CGB 模式</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="51"/>
        <source>Frame select</source>
        <translation>帧选取</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="52"/>
        <source>Unlocked HBlank</source>
        <translation>已解锁的 HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="53"/>
        <source>Linear OBJ tile mapping</source>
        <translation>线性 OBJ 图块映射</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="54"/>
        <source>Force blank screen</source>
        <translation>强制清屏</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="55"/>
        <source>Enable background 0</source>
        <translation>启用背景 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="56"/>
        <source>Enable background 1</source>
        <translation>启用背景 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="57"/>
        <source>Enable background 2</source>
        <translation>启用背景 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="58"/>
        <source>Enable background 3</source>
        <translation>启用背景 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="59"/>
        <source>Enable OBJ</source>
        <translation>启用 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="60"/>
        <source>Enable Window 0</source>
        <translation>启用窗口 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="61"/>
        <source>Enable Window 1</source>
        <translation>启用窗口 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="62"/>
        <source>Enable OBJ Window</source>
        <translation>启用 OBJ 窗口</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="66"/>
        <source>Swap green components</source>
        <translation>交换绿色组件</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="70"/>
        <source>Currently in VBlank</source>
        <translation>当前 (VBlank)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="71"/>
        <source>Currently in HBlank</source>
        <translation>当前 (HBlank)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="72"/>
        <source>Currently in VCounter</source>
        <translation>当前 (VCounter)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="73"/>
        <source>Enable VBlank IRQ generation</source>
        <translation>启用 VBlank IRQ 生成</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="74"/>
        <source>Enable HBlank IRQ generation</source>
        <translation>启用 HBlank IRQ 生成</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="75"/>
        <source>Enable VCounter IRQ generation</source>
        <translation>启用 VCounter IRQ 生成</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="76"/>
        <source>VCounter scanline</source>
        <translation>VCounter 扫描线</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="80"/>
        <source>Current scanline</source>
        <translation>当前扫描线</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="84"/>
        <location filename="../IOViewer.cpp" line="93"/>
        <location filename="../IOViewer.cpp" line="102"/>
        <location filename="../IOViewer.cpp" line="112"/>
        <source>Priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="85"/>
        <location filename="../IOViewer.cpp" line="94"/>
        <location filename="../IOViewer.cpp" line="103"/>
        <location filename="../IOViewer.cpp" line="113"/>
        <source>Tile data base (* 16kB)</source>
        <translation>图块数据基 (* 16kB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="86"/>
        <location filename="../IOViewer.cpp" line="95"/>
        <location filename="../IOViewer.cpp" line="104"/>
        <location filename="../IOViewer.cpp" line="114"/>
        <source>Enable mosaic</source>
        <translation>启用马赛克</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="87"/>
        <location filename="../IOViewer.cpp" line="96"/>
        <location filename="../IOViewer.cpp" line="105"/>
        <location filename="../IOViewer.cpp" line="115"/>
        <source>Enable 256-color</source>
        <translation>启用 256 色</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="88"/>
        <location filename="../IOViewer.cpp" line="97"/>
        <location filename="../IOViewer.cpp" line="106"/>
        <location filename="../IOViewer.cpp" line="116"/>
        <source>Tile map base (* 2kB)</source>
        <translation>图块映射基 (* 2kB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="89"/>
        <location filename="../IOViewer.cpp" line="98"/>
        <location filename="../IOViewer.cpp" line="108"/>
        <location filename="../IOViewer.cpp" line="118"/>
        <source>Background dimensions</source>
        <translation>背景维度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="107"/>
        <location filename="../IOViewer.cpp" line="117"/>
        <source>Overflow wraps</source>
        <translation>溢出包装</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="122"/>
        <location filename="../IOViewer.cpp" line="130"/>
        <location filename="../IOViewer.cpp" line="138"/>
        <location filename="../IOViewer.cpp" line="146"/>
        <location filename="../IOViewer.cpp" line="1365"/>
        <location filename="../IOViewer.cpp" line="1406"/>
        <source>Horizontal offset</source>
        <translation>水平偏移量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="126"/>
        <location filename="../IOViewer.cpp" line="134"/>
        <location filename="../IOViewer.cpp" line="142"/>
        <location filename="../IOViewer.cpp" line="150"/>
        <location filename="../IOViewer.cpp" line="1361"/>
        <location filename="../IOViewer.cpp" line="1402"/>
        <source>Vertical offset</source>
        <translation>垂直偏移量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="154"/>
        <location filename="../IOViewer.cpp" line="159"/>
        <location filename="../IOViewer.cpp" line="164"/>
        <location filename="../IOViewer.cpp" line="169"/>
        <location filename="../IOViewer.cpp" line="174"/>
        <location filename="../IOViewer.cpp" line="183"/>
        <location filename="../IOViewer.cpp" line="192"/>
        <location filename="../IOViewer.cpp" line="197"/>
        <location filename="../IOViewer.cpp" line="202"/>
        <location filename="../IOViewer.cpp" line="207"/>
        <location filename="../IOViewer.cpp" line="212"/>
        <location filename="../IOViewer.cpp" line="221"/>
        <source>Fractional part</source>
        <translation>分数部分</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="155"/>
        <location filename="../IOViewer.cpp" line="160"/>
        <location filename="../IOViewer.cpp" line="165"/>
        <location filename="../IOViewer.cpp" line="170"/>
        <location filename="../IOViewer.cpp" line="193"/>
        <location filename="../IOViewer.cpp" line="198"/>
        <location filename="../IOViewer.cpp" line="203"/>
        <location filename="../IOViewer.cpp" line="208"/>
        <source>Integer part</source>
        <translation>整数部分</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="175"/>
        <location filename="../IOViewer.cpp" line="184"/>
        <location filename="../IOViewer.cpp" line="213"/>
        <location filename="../IOViewer.cpp" line="222"/>
        <source>Integer part (low)</source>
        <translation>整数部分（低）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="179"/>
        <location filename="../IOViewer.cpp" line="188"/>
        <location filename="../IOViewer.cpp" line="217"/>
        <location filename="../IOViewer.cpp" line="226"/>
        <source>Integer part (high)</source>
        <translation>整数部分（高）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="230"/>
        <location filename="../IOViewer.cpp" line="235"/>
        <source>End x</source>
        <translation>结束 x 轴</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="231"/>
        <location filename="../IOViewer.cpp" line="236"/>
        <source>Start x</source>
        <translation>起始 x 轴</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="240"/>
        <location filename="../IOViewer.cpp" line="245"/>
        <source>End y</source>
        <translation>结束 y 轴</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="241"/>
        <location filename="../IOViewer.cpp" line="246"/>
        <source>Start y</source>
        <translation>起始 y 轴</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="250"/>
        <source>Window 0 enable BG 0</source>
        <translation>窗口 0 启用背景 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="251"/>
        <source>Window 0 enable BG 1</source>
        <translation>窗口 0 启用背景 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="252"/>
        <source>Window 0 enable BG 2</source>
        <translation>窗口 0 启用背景 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="253"/>
        <source>Window 0 enable BG 3</source>
        <translation>窗口 0 启用背景 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="254"/>
        <source>Window 0 enable OBJ</source>
        <translation>窗口 0 启用 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="255"/>
        <source>Window 0 enable blend</source>
        <translation>Windows 0 启用叠加</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="256"/>
        <source>Window 1 enable BG 0</source>
        <translation>窗口 1 启用背景 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="257"/>
        <source>Window 1 enable BG 1</source>
        <translation>窗口 1 启用背景 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="258"/>
        <source>Window 1 enable BG 2</source>
        <translation>窗口 1 启用背景 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="259"/>
        <source>Window 1 enable BG 3</source>
        <translation>窗口 1 启用背景 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="260"/>
        <source>Window 1 enable OBJ</source>
        <translation>窗口 1 启用 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="261"/>
        <source>Window 1 enable blend</source>
        <translation>窗口 1 启用叠加</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="265"/>
        <source>Outside window enable BG 0</source>
        <translation>外部窗口启用背景 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="266"/>
        <source>Outside window enable BG 1</source>
        <translation>外部窗口启用背景 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="267"/>
        <source>Outside window enable BG 2</source>
        <translation>外部窗口启用背景 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="268"/>
        <source>Outside window enable BG 3</source>
        <translation>外部窗口启用背景 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="269"/>
        <source>Outside window enable OBJ</source>
        <translation>外部窗口启用 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="270"/>
        <source>Outside window enable blend</source>
        <translation>外部窗口启用叠加</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="271"/>
        <source>OBJ window enable BG 0</source>
        <translation>OBJ 窗口启用背景 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="272"/>
        <source>OBJ window enable BG 1</source>
        <translation>OBJ 窗口启用背景 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="273"/>
        <source>OBJ window enable BG 2</source>
        <translation>OBJ 窗口启用背景 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="274"/>
        <source>OBJ window enable BG 3</source>
        <translation>OBJ 窗口启用背景 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="275"/>
        <source>OBJ window enable OBJ</source>
        <translation>OBJ 窗口启用 OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="276"/>
        <source>OBJ window enable blend</source>
        <translation>OBJ 窗口启用叠加</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="281"/>
        <source>Background mosaic size vertical</source>
        <translation>背景马赛克垂直大小</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="280"/>
        <source>Background mosaic size horizontal</source>
        <translation>背景马赛克水平大小</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="283"/>
        <source>Object mosaic size vertical</source>
        <translation>对象马赛克垂直大小</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="282"/>
        <source>Object mosaic size horizontal</source>
        <translation>对象马赛克水平大小</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="289"/>
        <source>BG 0 target 1</source>
        <translation>背景 0 目标 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="290"/>
        <source>BG 1 target 1</source>
        <translation>背景 1 目标 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="291"/>
        <source>BG 2 target 1</source>
        <translation>背景 2 目标 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="292"/>
        <source>BG 3 target 1</source>
        <translation>背景 3 目标 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="293"/>
        <source>OBJ target 1</source>
        <translation>OBJ 目标 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="294"/>
        <source>Backdrop target 1</source>
        <translation>背幕目标 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="295"/>
        <source>Blend mode</source>
        <translation>叠加模式</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="296"/>
        <source>Disabled</source>
        <translation>已禁用</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="297"/>
        <source>Additive blending</source>
        <translation>加性叠加</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="298"/>
        <source>Brighten</source>
        <translation>增加亮度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="299"/>
        <source>Darken</source>
        <translation>降低亮度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="301"/>
        <source>BG 0 target 2</source>
        <translation>背景 0 目标 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="302"/>
        <source>BG 1 target 2</source>
        <translation>背景 1 目标 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="303"/>
        <source>BG 2 target 2</source>
        <translation>背景 2 目标 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="304"/>
        <source>BG 3 target 2</source>
        <translation>背景 3 目标 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="305"/>
        <source>OBJ target 2</source>
        <translation>OBJ 目标 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="306"/>
        <source>Backdrop target 2</source>
        <translation>背幕目标 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="310"/>
        <source>Blend A (target 1)</source>
        <translation>叠加 A (目标 1)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="311"/>
        <source>Blend B (target 2)</source>
        <translation>叠加 B (目标 2)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="315"/>
        <source>Blend Y</source>
        <translation>叠加 Y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="329"/>
        <location filename="../IOViewer.cpp" line="1100"/>
        <source>Sweep shifts</source>
        <translation>扫描 shifts</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="330"/>
        <location filename="../IOViewer.cpp" line="1101"/>
        <source>Sweep subtract</source>
        <translation>扫描 subtract</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="331"/>
        <location filename="../IOViewer.cpp" line="1102"/>
        <source>Sweep time (in 1/128s)</source>
        <translation>扫描时间 (1/128 秒)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="335"/>
        <location filename="../IOViewer.cpp" line="351"/>
        <location filename="../IOViewer.cpp" line="375"/>
        <location filename="../IOViewer.cpp" line="397"/>
        <location filename="../IOViewer.cpp" line="1106"/>
        <location filename="../IOViewer.cpp" line="1129"/>
        <location filename="../IOViewer.cpp" line="1154"/>
        <location filename="../IOViewer.cpp" line="1179"/>
        <source>Sound length</source>
        <translation>声音长度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="336"/>
        <location filename="../IOViewer.cpp" line="352"/>
        <location filename="../IOViewer.cpp" line="1107"/>
        <location filename="../IOViewer.cpp" line="1130"/>
        <source>Duty cycle</source>
        <translation>占空比</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="337"/>
        <location filename="../IOViewer.cpp" line="353"/>
        <location filename="../IOViewer.cpp" line="398"/>
        <location filename="../IOViewer.cpp" line="1111"/>
        <location filename="../IOViewer.cpp" line="1134"/>
        <location filename="../IOViewer.cpp" line="1183"/>
        <source>Envelope step time</source>
        <translation>包络步进时间</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="338"/>
        <location filename="../IOViewer.cpp" line="354"/>
        <location filename="../IOViewer.cpp" line="399"/>
        <location filename="../IOViewer.cpp" line="1112"/>
        <location filename="../IOViewer.cpp" line="1135"/>
        <location filename="../IOViewer.cpp" line="1184"/>
        <source>Envelope increase</source>
        <translation>增加包络</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="339"/>
        <location filename="../IOViewer.cpp" line="355"/>
        <location filename="../IOViewer.cpp" line="400"/>
        <location filename="../IOViewer.cpp" line="1113"/>
        <location filename="../IOViewer.cpp" line="1136"/>
        <location filename="../IOViewer.cpp" line="1185"/>
        <source>Initial volume</source>
        <translation>音量初始化</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="343"/>
        <location filename="../IOViewer.cpp" line="361"/>
        <location filename="../IOViewer.cpp" line="389"/>
        <source>Sound frequency</source>
        <translation>音频频率</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="344"/>
        <location filename="../IOViewer.cpp" line="362"/>
        <location filename="../IOViewer.cpp" line="390"/>
        <location filename="../IOViewer.cpp" line="412"/>
        <location filename="../IOViewer.cpp" line="1122"/>
        <location filename="../IOViewer.cpp" line="1145"/>
        <location filename="../IOViewer.cpp" line="1172"/>
        <location filename="../IOViewer.cpp" line="1198"/>
        <source>Timed</source>
        <translation>已时控</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="345"/>
        <location filename="../IOViewer.cpp" line="363"/>
        <location filename="../IOViewer.cpp" line="391"/>
        <location filename="../IOViewer.cpp" line="413"/>
        <location filename="../IOViewer.cpp" line="1123"/>
        <location filename="../IOViewer.cpp" line="1146"/>
        <location filename="../IOViewer.cpp" line="1173"/>
        <location filename="../IOViewer.cpp" line="1199"/>
        <source>Reset</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="369"/>
        <source>Double-size wave table</source>
        <translation>双尺寸波形表</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="370"/>
        <source>Active wave table</source>
        <translation>激活波形表</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="371"/>
        <location filename="../IOViewer.cpp" line="1150"/>
        <source>Enable channel 3</source>
        <translation>启用通道 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="376"/>
        <location filename="../IOViewer.cpp" line="1158"/>
        <source>Volume</source>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="377"/>
        <location filename="../IOViewer.cpp" line="1159"/>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="378"/>
        <location filename="../IOViewer.cpp" line="435"/>
        <location filename="../IOViewer.cpp" line="1160"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="379"/>
        <location filename="../IOViewer.cpp" line="434"/>
        <location filename="../IOViewer.cpp" line="1161"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="380"/>
        <location filename="../IOViewer.cpp" line="433"/>
        <location filename="../IOViewer.cpp" line="1162"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="381"/>
        <location filename="../IOViewer.cpp" line="382"/>
        <location filename="../IOViewer.cpp" line="383"/>
        <location filename="../IOViewer.cpp" line="384"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="406"/>
        <location filename="../IOViewer.cpp" line="1189"/>
        <source>Clock divider</source>
        <translation>时钟分频器</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="407"/>
        <location filename="../IOViewer.cpp" line="1190"/>
        <source>Register stages</source>
        <translation>寄存器阶段</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="408"/>
        <location filename="../IOViewer.cpp" line="1191"/>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="409"/>
        <location filename="../IOViewer.cpp" line="1192"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="411"/>
        <location filename="../IOViewer.cpp" line="1194"/>
        <source>Shifter frequency</source>
        <translation>移位器频率</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="419"/>
        <source>PSG volume right</source>
        <translation>PSG 右侧音量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="420"/>
        <source>PSG volume left</source>
        <translation>PSG 左侧音量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="421"/>
        <location filename="../IOViewer.cpp" line="1210"/>
        <source>Enable channel 1 right</source>
        <translation>启用右侧通道 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="422"/>
        <location filename="../IOViewer.cpp" line="1211"/>
        <source>Enable channel 2 right</source>
        <translation>启用右侧通道 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="423"/>
        <location filename="../IOViewer.cpp" line="1212"/>
        <source>Enable channel 3 right</source>
        <translation>启用右侧通道 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="424"/>
        <location filename="../IOViewer.cpp" line="1213"/>
        <source>Enable channel 4 right</source>
        <translation>启用右侧通道 4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="425"/>
        <location filename="../IOViewer.cpp" line="1214"/>
        <source>Enable channel 1 left</source>
        <translation>启用左侧通道 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="426"/>
        <location filename="../IOViewer.cpp" line="1215"/>
        <source>Enable channel 2 left</source>
        <translation>启用左侧通道 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="427"/>
        <location filename="../IOViewer.cpp" line="1216"/>
        <source>Enable channel 3 left</source>
        <translation>启用左侧通道 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="428"/>
        <location filename="../IOViewer.cpp" line="1217"/>
        <source>Enable channel 4 left</source>
        <translation>启用左侧通道 4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="432"/>
        <source>PSG master volume</source>
        <translation>PSG 主音量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="438"/>
        <source>Loud channel A</source>
        <translation>响音通道 A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="439"/>
        <source>Loud channel B</source>
        <translation>响音通道 B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="440"/>
        <source>Enable channel A right</source>
        <translation>启用右侧通道 A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="441"/>
        <source>Enable channel A left</source>
        <translation>启用右侧通道 A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="442"/>
        <source>Channel A timer</source>
        <translation>通道 A 时控器</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="443"/>
        <location filename="../IOViewer.cpp" line="450"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="444"/>
        <location filename="../IOViewer.cpp" line="451"/>
        <location filename="../IOViewer.cpp" line="780"/>
        <location filename="../IOViewer.cpp" line="795"/>
        <location filename="../IOViewer.cpp" line="811"/>
        <location filename="../IOViewer.cpp" line="827"/>
        <location filename="../IOViewer.cpp" line="993"/>
        <location filename="../IOViewer.cpp" line="1003"/>
        <location filename="../IOViewer.cpp" line="1013"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="446"/>
        <source>Channel A reset</source>
        <translation>通道 A 重置</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="447"/>
        <source>Enable channel B right</source>
        <translation>启用右侧通道 B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="448"/>
        <source>Enable channel B left</source>
        <translation>启用左侧通道 B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="449"/>
        <source>Channel B timer</source>
        <translation>通道 B 时控器</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="453"/>
        <source>Channel B reset</source>
        <translation>通道 B 重置</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="457"/>
        <location filename="../IOViewer.cpp" line="1221"/>
        <source>Active channel 1</source>
        <translation>激活通道 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="458"/>
        <location filename="../IOViewer.cpp" line="1222"/>
        <source>Active channel 2</source>
        <translation>激活通道 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="459"/>
        <location filename="../IOViewer.cpp" line="1223"/>
        <source>Active channel 3</source>
        <translation>激活通道 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="460"/>
        <location filename="../IOViewer.cpp" line="1224"/>
        <source>Active channel 4</source>
        <translation>激活通道 4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="461"/>
        <location filename="../IOViewer.cpp" line="1225"/>
        <source>Enable audio</source>
        <translation>启用音频</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="467"/>
        <source>Bias</source>
        <translation>偏差</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="468"/>
        <source>Resolution</source>
        <translation>分辨率</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="478"/>
        <location filename="../IOViewer.cpp" line="479"/>
        <location filename="../IOViewer.cpp" line="480"/>
        <location filename="../IOViewer.cpp" line="481"/>
        <location filename="../IOViewer.cpp" line="485"/>
        <location filename="../IOViewer.cpp" line="486"/>
        <location filename="../IOViewer.cpp" line="487"/>
        <location filename="../IOViewer.cpp" line="488"/>
        <location filename="../IOViewer.cpp" line="492"/>
        <location filename="../IOViewer.cpp" line="493"/>
        <location filename="../IOViewer.cpp" line="494"/>
        <location filename="../IOViewer.cpp" line="495"/>
        <location filename="../IOViewer.cpp" line="499"/>
        <location filename="../IOViewer.cpp" line="500"/>
        <location filename="../IOViewer.cpp" line="501"/>
        <location filename="../IOViewer.cpp" line="502"/>
        <location filename="../IOViewer.cpp" line="506"/>
        <location filename="../IOViewer.cpp" line="507"/>
        <location filename="../IOViewer.cpp" line="508"/>
        <location filename="../IOViewer.cpp" line="509"/>
        <location filename="../IOViewer.cpp" line="513"/>
        <location filename="../IOViewer.cpp" line="514"/>
        <location filename="../IOViewer.cpp" line="515"/>
        <location filename="../IOViewer.cpp" line="516"/>
        <location filename="../IOViewer.cpp" line="520"/>
        <location filename="../IOViewer.cpp" line="521"/>
        <location filename="../IOViewer.cpp" line="522"/>
        <location filename="../IOViewer.cpp" line="523"/>
        <location filename="../IOViewer.cpp" line="527"/>
        <location filename="../IOViewer.cpp" line="528"/>
        <location filename="../IOViewer.cpp" line="529"/>
        <location filename="../IOViewer.cpp" line="530"/>
        <location filename="../IOViewer.cpp" line="534"/>
        <location filename="../IOViewer.cpp" line="535"/>
        <location filename="../IOViewer.cpp" line="539"/>
        <location filename="../IOViewer.cpp" line="540"/>
        <location filename="../IOViewer.cpp" line="544"/>
        <location filename="../IOViewer.cpp" line="545"/>
        <location filename="../IOViewer.cpp" line="549"/>
        <location filename="../IOViewer.cpp" line="550"/>
        <location filename="../IOViewer.cpp" line="1247"/>
        <location filename="../IOViewer.cpp" line="1248"/>
        <location filename="../IOViewer.cpp" line="1252"/>
        <location filename="../IOViewer.cpp" line="1253"/>
        <location filename="../IOViewer.cpp" line="1257"/>
        <location filename="../IOViewer.cpp" line="1258"/>
        <location filename="../IOViewer.cpp" line="1262"/>
        <location filename="../IOViewer.cpp" line="1263"/>
        <location filename="../IOViewer.cpp" line="1267"/>
        <location filename="../IOViewer.cpp" line="1268"/>
        <location filename="../IOViewer.cpp" line="1272"/>
        <location filename="../IOViewer.cpp" line="1273"/>
        <location filename="../IOViewer.cpp" line="1277"/>
        <location filename="../IOViewer.cpp" line="1278"/>
        <location filename="../IOViewer.cpp" line="1282"/>
        <location filename="../IOViewer.cpp" line="1283"/>
        <location filename="../IOViewer.cpp" line="1287"/>
        <location filename="../IOViewer.cpp" line="1288"/>
        <location filename="../IOViewer.cpp" line="1292"/>
        <location filename="../IOViewer.cpp" line="1293"/>
        <location filename="../IOViewer.cpp" line="1297"/>
        <location filename="../IOViewer.cpp" line="1298"/>
        <location filename="../IOViewer.cpp" line="1302"/>
        <location filename="../IOViewer.cpp" line="1303"/>
        <location filename="../IOViewer.cpp" line="1307"/>
        <location filename="../IOViewer.cpp" line="1308"/>
        <location filename="../IOViewer.cpp" line="1312"/>
        <location filename="../IOViewer.cpp" line="1313"/>
        <location filename="../IOViewer.cpp" line="1317"/>
        <location filename="../IOViewer.cpp" line="1318"/>
        <location filename="../IOViewer.cpp" line="1322"/>
        <location filename="../IOViewer.cpp" line="1323"/>
        <source>Sample</source>
        <translation>采样</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="562"/>
        <location filename="../IOViewer.cpp" line="570"/>
        <location filename="../IOViewer.cpp" line="607"/>
        <location filename="../IOViewer.cpp" line="615"/>
        <location filename="../IOViewer.cpp" line="652"/>
        <location filename="../IOViewer.cpp" line="660"/>
        <location filename="../IOViewer.cpp" line="697"/>
        <location filename="../IOViewer.cpp" line="705"/>
        <source>Address (low)</source>
        <translation>地址（低）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="566"/>
        <location filename="../IOViewer.cpp" line="574"/>
        <location filename="../IOViewer.cpp" line="611"/>
        <location filename="../IOViewer.cpp" line="619"/>
        <location filename="../IOViewer.cpp" line="656"/>
        <location filename="../IOViewer.cpp" line="664"/>
        <location filename="../IOViewer.cpp" line="701"/>
        <location filename="../IOViewer.cpp" line="709"/>
        <source>Address (high)</source>
        <translation>地址（高）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1117"/>
        <location filename="../IOViewer.cpp" line="1140"/>
        <location filename="../IOViewer.cpp" line="1167"/>
        <source>Sound frequency (low)</source>
        <translation>声音频率（低）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1121"/>
        <location filename="../IOViewer.cpp" line="1144"/>
        <location filename="../IOViewer.cpp" line="1171"/>
        <source>Sound frequency (high)</source>
        <translation>声音频率（高）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1425"/>
        <source>Source (high)</source>
        <translation>源（高）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1429"/>
        <source>Source (low)</source>
        <translation>源（低）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1433"/>
        <source>Destination (high)</source>
        <translation>目的地（高）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1437"/>
        <source>Destination (low)</source>
        <translation>目的地（低）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1500"/>
        <location filename="../IOViewer.cpp" line="1512"/>
        <source>Green (low)</source>
        <translation>绿色（低）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1501"/>
        <location filename="../IOViewer.cpp" line="1513"/>
        <source>Green (high)</source>
        <translation>绿色（高）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="578"/>
        <location filename="../IOViewer.cpp" line="623"/>
        <location filename="../IOViewer.cpp" line="668"/>
        <location filename="../IOViewer.cpp" line="713"/>
        <source>Word count</source>
        <translation>字数</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="582"/>
        <location filename="../IOViewer.cpp" line="627"/>
        <location filename="../IOViewer.cpp" line="672"/>
        <location filename="../IOViewer.cpp" line="717"/>
        <source>Destination offset</source>
        <translation>目标偏移</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="583"/>
        <location filename="../IOViewer.cpp" line="589"/>
        <location filename="../IOViewer.cpp" line="628"/>
        <location filename="../IOViewer.cpp" line="634"/>
        <location filename="../IOViewer.cpp" line="673"/>
        <location filename="../IOViewer.cpp" line="679"/>
        <location filename="../IOViewer.cpp" line="718"/>
        <location filename="../IOViewer.cpp" line="724"/>
        <source>Increment</source>
        <translation>增量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="584"/>
        <location filename="../IOViewer.cpp" line="590"/>
        <location filename="../IOViewer.cpp" line="629"/>
        <location filename="../IOViewer.cpp" line="635"/>
        <location filename="../IOViewer.cpp" line="674"/>
        <location filename="../IOViewer.cpp" line="680"/>
        <location filename="../IOViewer.cpp" line="719"/>
        <location filename="../IOViewer.cpp" line="725"/>
        <source>Decrement</source>
        <translation>减量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="585"/>
        <location filename="../IOViewer.cpp" line="591"/>
        <location filename="../IOViewer.cpp" line="630"/>
        <location filename="../IOViewer.cpp" line="636"/>
        <location filename="../IOViewer.cpp" line="675"/>
        <location filename="../IOViewer.cpp" line="681"/>
        <location filename="../IOViewer.cpp" line="720"/>
        <location filename="../IOViewer.cpp" line="726"/>
        <source>Fixed</source>
        <translation>固定</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="586"/>
        <location filename="../IOViewer.cpp" line="631"/>
        <location filename="../IOViewer.cpp" line="676"/>
        <location filename="../IOViewer.cpp" line="721"/>
        <source>Increment and reload</source>
        <translation>增量并重新载入</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="588"/>
        <location filename="../IOViewer.cpp" line="633"/>
        <location filename="../IOViewer.cpp" line="678"/>
        <location filename="../IOViewer.cpp" line="723"/>
        <source>Source offset</source>
        <translation>源偏移</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="594"/>
        <location filename="../IOViewer.cpp" line="639"/>
        <location filename="../IOViewer.cpp" line="684"/>
        <location filename="../IOViewer.cpp" line="730"/>
        <source>Repeat</source>
        <translation>重复</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="595"/>
        <location filename="../IOViewer.cpp" line="640"/>
        <location filename="../IOViewer.cpp" line="685"/>
        <location filename="../IOViewer.cpp" line="731"/>
        <source>32-bit</source>
        <translation>32 位</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="596"/>
        <location filename="../IOViewer.cpp" line="641"/>
        <location filename="../IOViewer.cpp" line="686"/>
        <location filename="../IOViewer.cpp" line="732"/>
        <source>Start timing</source>
        <translation>开始定时</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="597"/>
        <location filename="../IOViewer.cpp" line="642"/>
        <location filename="../IOViewer.cpp" line="687"/>
        <location filename="../IOViewer.cpp" line="733"/>
        <location filename="../IOViewer.cpp" line="1443"/>
        <source>Immediate</source>
        <translation>立即</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="598"/>
        <location filename="../IOViewer.cpp" line="643"/>
        <location filename="../IOViewer.cpp" line="688"/>
        <location filename="../IOViewer.cpp" line="734"/>
        <location filename="../IOViewer.cpp" line="945"/>
        <location filename="../IOViewer.cpp" line="962"/>
        <location filename="../IOViewer.cpp" line="1092"/>
        <location filename="../IOViewer.cpp" line="1553"/>
        <source>VBlank</source>
        <translation>VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="599"/>
        <location filename="../IOViewer.cpp" line="644"/>
        <location filename="../IOViewer.cpp" line="689"/>
        <location filename="../IOViewer.cpp" line="735"/>
        <location filename="../IOViewer.cpp" line="946"/>
        <location filename="../IOViewer.cpp" line="963"/>
        <location filename="../IOViewer.cpp" line="1444"/>
        <source>HBlank</source>
        <translation>HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="602"/>
        <location filename="../IOViewer.cpp" line="647"/>
        <location filename="../IOViewer.cpp" line="692"/>
        <location filename="../IOViewer.cpp" line="738"/>
        <location filename="../IOViewer.cpp" line="785"/>
        <location filename="../IOViewer.cpp" line="801"/>
        <location filename="../IOViewer.cpp" line="817"/>
        <location filename="../IOViewer.cpp" line="833"/>
        <location filename="../IOViewer.cpp" line="893"/>
        <source>IRQ</source>
        <translation>IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="603"/>
        <location filename="../IOViewer.cpp" line="648"/>
        <location filename="../IOViewer.cpp" line="693"/>
        <location filename="../IOViewer.cpp" line="739"/>
        <location filename="../IOViewer.cpp" line="786"/>
        <location filename="../IOViewer.cpp" line="802"/>
        <location filename="../IOViewer.cpp" line="818"/>
        <location filename="../IOViewer.cpp" line="834"/>
        <location filename="../IOViewer.cpp" line="1074"/>
        <location filename="../IOViewer.cpp" line="1451"/>
        <location filename="../IOViewer.cpp" line="1455"/>
        <source>Enable</source>
        <translation>启用</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="645"/>
        <location filename="../IOViewer.cpp" line="690"/>
        <location filename="../IOViewer.cpp" line="736"/>
        <source>Audio FIFO</source>
        <translation>音频 FIFO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="727"/>
        <source>Video Capture</source>
        <translation>视频截取</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="729"/>
        <source>DRQ</source>
        <translation>DRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="775"/>
        <location filename="../IOViewer.cpp" line="790"/>
        <location filename="../IOViewer.cpp" line="806"/>
        <location filename="../IOViewer.cpp" line="822"/>
        <location filename="../IOViewer.cpp" line="1044"/>
        <location filename="../IOViewer.cpp" line="1056"/>
        <location filename="../IOViewer.cpp" line="1060"/>
        <location filename="../IOViewer.cpp" line="1064"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="779"/>
        <location filename="../IOViewer.cpp" line="794"/>
        <location filename="../IOViewer.cpp" line="810"/>
        <location filename="../IOViewer.cpp" line="826"/>
        <source>Scale</source>
        <translation>比例</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="781"/>
        <location filename="../IOViewer.cpp" line="796"/>
        <location filename="../IOViewer.cpp" line="812"/>
        <location filename="../IOViewer.cpp" line="828"/>
        <location filename="../IOViewer.cpp" line="1071"/>
        <source>1/64</source>
        <translation>1/64</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="782"/>
        <location filename="../IOViewer.cpp" line="797"/>
        <location filename="../IOViewer.cpp" line="813"/>
        <location filename="../IOViewer.cpp" line="829"/>
        <location filename="../IOViewer.cpp" line="1072"/>
        <source>1/256</source>
        <translation>1/256</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="783"/>
        <location filename="../IOViewer.cpp" line="798"/>
        <location filename="../IOViewer.cpp" line="814"/>
        <location filename="../IOViewer.cpp" line="830"/>
        <location filename="../IOViewer.cpp" line="1069"/>
        <source>1/1024</source>
        <translation>1/1024</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="800"/>
        <location filename="../IOViewer.cpp" line="816"/>
        <location filename="../IOViewer.cpp" line="832"/>
        <source>Cascade</source>
        <translation>级联</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="870"/>
        <location filename="../IOViewer.cpp" line="883"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="872"/>
        <location filename="../IOViewer.cpp" line="885"/>
        <source>Select</source>
        <translation>Select</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="873"/>
        <location filename="../IOViewer.cpp" line="886"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="874"/>
        <location filename="../IOViewer.cpp" line="887"/>
        <source>Right</source>
        <translation>右</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="875"/>
        <location filename="../IOViewer.cpp" line="888"/>
        <source>Left</source>
        <translation>左</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="876"/>
        <location filename="../IOViewer.cpp" line="889"/>
        <source>Up</source>
        <translation>上</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="877"/>
        <location filename="../IOViewer.cpp" line="890"/>
        <source>Down</source>
        <translation>下</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="878"/>
        <location filename="../IOViewer.cpp" line="891"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="879"/>
        <location filename="../IOViewer.cpp" line="892"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="894"/>
        <source>Condition</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="898"/>
        <source>SC</source>
        <translation>SC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="899"/>
        <source>SD</source>
        <translation>SD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="900"/>
        <source>SI</source>
        <translation>SI</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="901"/>
        <source>SO</source>
        <translation>SO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="947"/>
        <location filename="../IOViewer.cpp" line="964"/>
        <source>VCounter</source>
        <translation>VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="948"/>
        <location filename="../IOViewer.cpp" line="965"/>
        <source>Timer 0</source>
        <translation>Timer 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="949"/>
        <location filename="../IOViewer.cpp" line="966"/>
        <source>Timer 1</source>
        <translation>Timer 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="950"/>
        <location filename="../IOViewer.cpp" line="967"/>
        <source>Timer 2</source>
        <translation>Timer 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="951"/>
        <location filename="../IOViewer.cpp" line="968"/>
        <source>Timer 3</source>
        <translation>Timer 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="952"/>
        <location filename="../IOViewer.cpp" line="969"/>
        <source>SIO</source>
        <translation>SIO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="953"/>
        <location filename="../IOViewer.cpp" line="970"/>
        <source>DMA 0</source>
        <translation>DMA 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="954"/>
        <location filename="../IOViewer.cpp" line="971"/>
        <source>DMA 1</source>
        <translation>DMA 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="955"/>
        <location filename="../IOViewer.cpp" line="972"/>
        <source>DMA 2</source>
        <translation>DMA 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="956"/>
        <location filename="../IOViewer.cpp" line="973"/>
        <source>DMA 3</source>
        <translation>DMA 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="957"/>
        <location filename="../IOViewer.cpp" line="974"/>
        <source>Keypad</source>
        <translation>键盘</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="958"/>
        <location filename="../IOViewer.cpp" line="975"/>
        <source>Gamepak</source>
        <translation>游戏卡带</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="979"/>
        <source>SRAM wait</source>
        <translation>SRAM 等待</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="980"/>
        <location filename="../IOViewer.cpp" line="986"/>
        <location filename="../IOViewer.cpp" line="996"/>
        <location filename="../IOViewer.cpp" line="1002"/>
        <location filename="../IOViewer.cpp" line="1006"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="981"/>
        <location filename="../IOViewer.cpp" line="987"/>
        <location filename="../IOViewer.cpp" line="997"/>
        <location filename="../IOViewer.cpp" line="1007"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="982"/>
        <location filename="../IOViewer.cpp" line="988"/>
        <location filename="../IOViewer.cpp" line="992"/>
        <location filename="../IOViewer.cpp" line="998"/>
        <location filename="../IOViewer.cpp" line="1008"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="983"/>
        <location filename="../IOViewer.cpp" line="989"/>
        <location filename="../IOViewer.cpp" line="999"/>
        <location filename="../IOViewer.cpp" line="1009"/>
        <location filename="../IOViewer.cpp" line="1012"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="985"/>
        <source>Cart 0 non-sequential</source>
        <translation>卡带 0 (非顺序)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="991"/>
        <source>Cart 0 sequential</source>
        <translation>卡带 0 (顺序)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="995"/>
        <source>Cart 1 non-sequential</source>
        <translation>卡带 1 (非顺序)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1001"/>
        <source>Cart 1 sequential</source>
        <translation>卡带 1 (顺序)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1005"/>
        <source>Cart 2 non-sequential</source>
        <translation>卡带 2 (非顺序)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1011"/>
        <source>Cart 2 sequential</source>
        <translation>卡带 2 (顺序)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1015"/>
        <source>PHI terminal</source>
        <translation>PHI 终端</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1016"/>
        <location filename="../IOViewer.cpp" line="1452"/>
        <source>Disable</source>
        <translation>禁用</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1017"/>
        <source>4.19MHz</source>
        <translation>4.19MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1018"/>
        <source>8.38MHz</source>
        <translation>8.38MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1019"/>
        <source>16.78MHz</source>
        <translation>16.78MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1021"/>
        <source>Gamepak prefetch</source>
        <translation>游戏卡带预读取</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1027"/>
        <source>Enable IRQs</source>
        <translation>启用 IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1035"/>
        <source>Right/A</source>
        <translation>右/A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1036"/>
        <source>Left/B</source>
        <translation>左/B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1037"/>
        <source>Up/Select</source>
        <translation>上/选择</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1038"/>
        <source>Down/Start</source>
        <translation>下/开始</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1039"/>
        <source>Active D-pad</source>
        <translation>活跃的方向键</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1040"/>
        <source>Active face buttons</source>
        <translation>活跃正面按钮</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1048"/>
        <source>Internal clock</source>
        <translation>内部时钟</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1049"/>
        <source>32× clocking (CGB only)</source>
        <translation>32× 时钟（CGB 特有）</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1050"/>
        <source>Transfer active</source>
        <translation>正在传输</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1068"/>
        <source>Divider</source>
        <translation>除数</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1070"/>
        <source>1/16</source>
        <translation>1/16</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1093"/>
        <location filename="../IOViewer.cpp" line="1554"/>
        <source>LCD STAT</source>
        <translation>LCD 统计</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1094"/>
        <location filename="../IOViewer.cpp" line="1555"/>
        <source>Timer</source>
        <translation>定时器</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1095"/>
        <location filename="../IOViewer.cpp" line="1556"/>
        <source>Serial</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1096"/>
        <location filename="../IOViewer.cpp" line="1557"/>
        <source>Joypad</source>
        <translation>手柄</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1203"/>
        <source>Volume right</source>
        <translation>右侧音量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1204"/>
        <source>Output right</source>
        <translation>右侧输出</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1205"/>
        <source>Volume left</source>
        <translation>左侧音量</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1206"/>
        <source>Output left</source>
        <translation>左侧输出</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1327"/>
        <source>Background enable/priority</source>
        <translation>后台启用/优先级</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1328"/>
        <source>Enable sprites</source>
        <translation>启用精灵</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1329"/>
        <source>Double-height sprites</source>
        <translation>二倍高度精灵</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1330"/>
        <source>Background tile map</source>
        <translation>背景图块集</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1331"/>
        <location filename="../IOViewer.cpp" line="1340"/>
        <source>0x9800 – 0x9BFF</source>
        <translation>0x9800 – 0x9BFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1332"/>
        <location filename="../IOViewer.cpp" line="1341"/>
        <source>0x9C00 – 0x9FFF</source>
        <translation>0x9C00 – 0x9FFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1334"/>
        <source>Background tile data</source>
        <translation>背景图块数据</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1335"/>
        <source>0x8800 – 0x87FF</source>
        <translation>0x8800 – 0x87FF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1336"/>
        <source>0x8000 – 0x8FFF</source>
        <translation>0x8000 – 0x8FFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1338"/>
        <source>Enable window</source>
        <translation>启用窗口</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1339"/>
        <source>Window tile map</source>
        <translation>窗口图块集</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1343"/>
        <source>Enable LCD</source>
        <translation>启用 LCD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1347"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1348"/>
        <source>0: HBlank</source>
        <translation>0：HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1349"/>
        <source>1: VBlank</source>
        <translation>1：VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1350"/>
        <source>2: OAM scan</source>
        <translation>2：OAM 扫描</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1351"/>
        <source>3: HDraw</source>
        <translation>3：HDraw</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1353"/>
        <source>In LYC</source>
        <translation>在 LYC 中</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1354"/>
        <source>Enable HBlank (mode 0) IRQ</source>
        <translation>启用 HBlank（模式 0）IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1355"/>
        <source>Enable VBlank (mode 1) IRQ</source>
        <translation>启用 VBlank（模式 1）IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1356"/>
        <source>Enable OAM (mode 2) IRQ</source>
        <translation>启用 OAM（模式 2）IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1357"/>
        <source>Enable LYC IRQ</source>
        <translation>启用 LYC IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1369"/>
        <source>Current Y coordinate</source>
        <translation>当前 Y 坐标</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1373"/>
        <source>Comparison Y coordinate</source>
        <translation>对比 Y 坐标</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1377"/>
        <source>Start upper byte</source>
        <translation>开始上部字节</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1381"/>
        <location filename="../IOViewer.cpp" line="1388"/>
        <location filename="../IOViewer.cpp" line="1395"/>
        <source>Color 0 shade</source>
        <translation>颜色 0 阴影</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1382"/>
        <location filename="../IOViewer.cpp" line="1389"/>
        <location filename="../IOViewer.cpp" line="1396"/>
        <source>Color 1 shade</source>
        <translation>颜色 1 阴影</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1383"/>
        <location filename="../IOViewer.cpp" line="1390"/>
        <location filename="../IOViewer.cpp" line="1397"/>
        <source>Color 2 shade</source>
        <translation>颜色 2 阴影</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1384"/>
        <location filename="../IOViewer.cpp" line="1391"/>
        <location filename="../IOViewer.cpp" line="1398"/>
        <source>Color 3 shade</source>
        <translation>颜色 3 阴影</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1412"/>
        <source>Prepare to switch speed</source>
        <translation>准备切换速度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1413"/>
        <source>Double speed</source>
        <translation>双倍速度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1419"/>
        <source>VRAM bank</source>
        <translation>显存库</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1441"/>
        <source>Length</source>
        <translation>长度</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1442"/>
        <source>Timing</source>
        <translation>定时</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1449"/>
        <source>Write bit</source>
        <translation>写位</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1450"/>
        <source>Read bit</source>
        <translation>读位</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1453"/>
        <location filename="../IOViewer.cpp" line="1454"/>
        <source>Unknown</source>
        <translation>未知</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1494"/>
        <location filename="../IOViewer.cpp" line="1506"/>
        <source>Current index</source>
        <translation>当前索引</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1495"/>
        <location filename="../IOViewer.cpp" line="1507"/>
        <source>Auto-increment</source>
        <translation>自动递增</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1499"/>
        <location filename="../IOViewer.cpp" line="1511"/>
        <source>Red</source>
        <translation>红</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1502"/>
        <location filename="../IOViewer.cpp" line="1514"/>
        <source>Blue</source>
        <translation>蓝</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1518"/>
        <source>Sprite ordering</source>
        <translation>精灵排序</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1519"/>
        <source>OAM order</source>
        <translation>OAM 顺序</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1520"/>
        <source>x coordinate sorting</source>
        <translation>x 坐标排序</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1531"/>
        <source>WRAM bank</source>
        <translation>内存库</translation>
    </message>
</context>
<context>
    <name>QGBA::InputController</name>
    <message>
        <location filename="../InputController.cpp" line="732"/>
        <location filename="../InputController.cpp" line="753"/>
        <source>Could not find a valid camera format!</source>
        <translation>无法找到一个有效的相机格式!</translation>
    </message>
    <message>
        <location filename="../InputController.cpp" line="734"/>
        <source>Camera supported format: %1</source>
        <translation>相机支持的格式: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::KeyEditor</name>
    <message>
        <location filename="../KeyEditor.cpp" line="46"/>
        <location filename="../KeyEditor.cpp" line="207"/>
        <source>---</source>
        <translation>---</translation>
    </message>
</context>
<context>
    <name>QGBA::LoadSaveState</name>
    <message>
        <location filename="../LoadSaveState.ui" line="14"/>
        <location filename="../LoadSaveState.ui" line="66"/>
        <source>%1 State</source>
        <translation>%1 即时存档</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="41"/>
        <location filename="../LoadSaveState.ui" line="85"/>
        <location filename="../LoadSaveState.ui" line="107"/>
        <location filename="../LoadSaveState.ui" line="129"/>
        <location filename="../LoadSaveState.ui" line="151"/>
        <location filename="../LoadSaveState.ui" line="173"/>
        <location filename="../LoadSaveState.ui" line="195"/>
        <location filename="../LoadSaveState.ui" line="217"/>
        <location filename="../LoadSaveState.ui" line="239"/>
        <source>No Save</source>
        <translation>不保存</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="50"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="94"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="116"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="138"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="160"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="182"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="204"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="226"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="248"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="261"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="76"/>
        <source>Load State</source>
        <translation>载入即时存档</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="76"/>
        <source>Save State</source>
        <translation>即时存档</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="185"/>
        <source>Empty</source>
        <translation>空</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="194"/>
        <source>Corrupted</source>
        <translation>已损坏</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="229"/>
        <source>Slot %1</source>
        <translation>插槽 %1</translation>
    </message>
</context>
<context>
    <name>QGBA::LogConfigModel</name>
    <message>
        <location filename="../LogConfigModel.cpp" line="91"/>
        <location filename="../LogConfigModel.cpp" line="112"/>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="93"/>
        <source>Fatal</source>
        <translation>致命错误</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="95"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="97"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="99"/>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="101"/>
        <source>Debug</source>
        <translation>调试</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="103"/>
        <source>Stub</source>
        <translation>桩位</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="105"/>
        <source>Game Error</source>
        <translation>游戏错误</translation>
    </message>
</context>
<context>
    <name>QGBA::LogController</name>
    <message>
        <location filename="../LogController.cpp" line="110"/>
        <source>[%1] %2: %3</source>
        <translation>[%1] %2: %3</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="121"/>
        <source>An error occurred</source>
        <translation>发生错误</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="193"/>
        <source>DEBUG</source>
        <translation>DEBUG</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="195"/>
        <source>STUB</source>
        <translation>STUB</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="197"/>
        <source>INFO</source>
        <translation>INFO</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="199"/>
        <source>WARN</source>
        <translation>WARN</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="201"/>
        <source>ERROR</source>
        <translation>ERROR</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="203"/>
        <source>FATAL</source>
        <translation>FATAL</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="205"/>
        <source>GAME ERROR</source>
        <translation>GAME ERROR</translation>
    </message>
</context>
<context>
    <name>QGBA::LogView</name>
    <message>
        <location filename="../LogView.ui" line="14"/>
        <source>Logs</source>
        <translation>日志</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="22"/>
        <source>Enabled Levels</source>
        <translation>启用级别</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="28"/>
        <source>Debug</source>
        <translation>调试</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="38"/>
        <source>Stub</source>
        <translation>桩件</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="48"/>
        <source>Info</source>
        <translation>信息</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="58"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="68"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="78"/>
        <source>Fatal</source>
        <translation>致命错误</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="95"/>
        <source>Game Error</source>
        <translation>游戏错误</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="108"/>
        <source>Advanced settings</source>
        <translation>高级设置</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="128"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="137"/>
        <source>Max Lines</source>
        <translation>最大行数</translation>
    </message>
</context>
<context>
    <name>QGBA::MapView</name>
    <message>
        <location filename="../MapView.ui" line="14"/>
        <source>Maps</source>
        <translation>贴图</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="43"/>
        <source>Magnification</source>
        <translation>缩放率</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="124"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="139"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="49"/>
        <source>Priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="50"/>
        <location filename="../MapView.cpp" line="63"/>
        <source>Map base</source>
        <translation>映射基</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="51"/>
        <location filename="../MapView.cpp" line="64"/>
        <source>Tile base</source>
        <translation>图块基</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="52"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="53"/>
        <location filename="../MapView.cpp" line="65"/>
        <source>Offset</source>
        <translation>偏移</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="54"/>
        <source>Xform</source>
        <translation>Xform</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="109"/>
        <source>Map Addr.</source>
        <translation>映射地址.</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="110"/>
        <source>Mirror</source>
        <translation>镜像</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="147"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="149"/>
        <source>Both</source>
        <translation>两者</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="151"/>
        <source>Horizontal</source>
        <translation>水平</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="153"/>
        <source>Vertical</source>
        <translation>垂直</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="184"/>
        <location filename="../MapView.cpp" line="185"/>
        <location filename="../MapView.cpp" line="240"/>
        <source>N/A</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="283"/>
        <source>Export map</source>
        <translation>导出映射</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="284"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>便携式网络图形 (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogController</name>
    <message>
        <location filename="../MemoryAccessLogController.cpp" line="118"/>
        <location filename="../MemoryAccessLogController.cpp" line="127"/>
        <source>Failed to open memory log file</source>
        <translation>打开内存日志文件失败</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogModel</name>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="68"/>
        <source>Data read</source>
        <translation>数据读取</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="70"/>
        <source>Data written</source>
        <translation>数据写入</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="72"/>
        <source>Code executed</source>
        <translation>代码执行</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="74"/>
        <source>Code aborted</source>
        <translation>代码已中止</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="76"/>
        <source>8-bit access</source>
        <translation>8 位访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="78"/>
        <source>16-bit access</source>
        <translation>16 位访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="80"/>
        <source>32-bit access</source>
        <translation>32 位访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="82"/>
        <source>64-bit access</source>
        <translation>64 位访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="96"/>
        <source>Accessed by instruction</source>
        <translation>通过指令访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="98"/>
        <source>Accessed by DMA</source>
        <translation>通过 DMA 访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="100"/>
        <source>Accessed by BIOS</source>
        <translation>通过 BIOS 访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="102"/>
        <source>Compressed data</source>
        <translation>压缩数据</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="104"/>
        <source>Accessed by memory copy</source>
        <translation>通过内存复制访问</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="106"/>
        <source>(Unknown extra bit 5)</source>
        <translation>（未知附加位 5）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="108"/>
        <source>(Unknown extra bit 6)</source>
        <translation>（未知附加位 6）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="110"/>
        <source>(Unknown extra bit 7)</source>
        <translation>（未知附加位 7）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="112"/>
        <source>Invalid instruction</source>
        <translation>指令无效</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="114"/>
        <source>Invalid read</source>
        <translation>读取无效</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="116"/>
        <source>Invalid write</source>
        <translation>写入无效</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="118"/>
        <source>Invalid executable address</source>
        <translation>无效的可执行地址</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="120"/>
        <source>(Private bit 0)</source>
        <translation>（私人位 0）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="122"/>
        <source>(Private bit 1)</source>
        <translation>（私人位 1）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="126"/>
        <source>ARM code</source>
        <translation>ARM 代码</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="128"/>
        <source>Instruction opcode</source>
        <translation>指令操作码</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="130"/>
        <source>(Private bit 2)</source>
        <translation>（私人位 2）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="135"/>
        <source>Thumb code</source>
        <translation>拇指代码</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="137"/>
        <source>Instruction operand</source>
        <translation>指令操作数</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="139"/>
        <source>(Private bit 3)</source>
        <translation>（私人位 3）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="147"/>
        <source>(Unknown)</source>
        <translation>（未知）</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogView</name>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="14"/>
        <source>Memory access logging</source>
        <translation>内存访问日志</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="23"/>
        <source>Log file</source>
        <translation>日志文件</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="32"/>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="39"/>
        <source>Log additional information (uses 3× space)</source>
        <translation>记录额外信息（使用 3x 空间）</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="46"/>
        <source>Load existing file if present</source>
        <translation>存在的情况下载入已有文件</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="56"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="66"/>
        <source>Unload</source>
        <translation>取消加载</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="76"/>
        <source>Regions</source>
        <translation>区域</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="87"/>
        <source>Export ROM snapshot</source>
        <translation>导出ROM快照</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="94"/>
        <source>Start</source>
        <translation>启动</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="104"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="97"/>
        <location filename="../MemoryAccessLogView.cpp" line="112"/>
        <source>Select access log file</source>
        <translation>选择访问日志文件</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="97"/>
        <source>Memory access logs (*.mal)</source>
        <translation>内存访问日志（*.mal）</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryDump</name>
    <message>
        <location filename="../MemoryDump.ui" line="14"/>
        <source>Save Memory Range</source>
        <translation>保存内存范围</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="20"/>
        <source>Start Address:</source>
        <translation>起始地址:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="76"/>
        <source>Byte Count:</source>
        <translation>字节数:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="108"/>
        <source>Dump across banks within region</source>
        <comment>Generate dump with bytes all within the same region of memory, even if it crosses the bank boundary</comment>
        <translation>区域内跨存储库转储</translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="25"/>
        <source>Save memory region</source>
        <translation>保存内存区域</translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="31"/>
        <source>Failed to open output file: %1</source>
        <translation>打开输出文件失败: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryModel</name>
    <message>
        <location filename="../MemoryModel.cpp" line="46"/>
        <source>Copy selection</source>
        <translation>复制所选</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="51"/>
        <source>Save selection</source>
        <translation>保存所选</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="56"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="61"/>
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="119"/>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="169"/>
        <source>Load TBL</source>
        <translation>载入 TBL</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="223"/>
        <source>Save selected memory</source>
        <translation>保存所选内存</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="229"/>
        <source>Failed to open output file: %1</source>
        <translation>打开输出文件失败: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="237"/>
        <source>Load memory</source>
        <translation>载入内存</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="243"/>
        <source>Failed to open input file: %1</source>
        <translation>打开输入文件失败: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="358"/>
        <source>ISO-8859-1</source>
        <translation>ISO-8859-1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemorySearch</name>
    <message>
        <location filename="../MemorySearch.ui" line="26"/>
        <source>Memory Search</source>
        <translation>内存查找</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="51"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="56"/>
        <source>Current Value</source>
        <translation>当前值</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="61"/>
        <location filename="../MemorySearch.ui" line="81"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="71"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="88"/>
        <source>Numeric</source>
        <translation>数字</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="101"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="118"/>
        <source>Width</source>
        <translation>位宽</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="125"/>
        <location filename="../MemorySearch.ui" line="185"/>
        <source>Guess</source>
        <translation>估计</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="138"/>
        <source>1 Byte (8-bit)</source>
        <translation>1 字节 (8 位)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="148"/>
        <source>2 Bytes (16-bit)</source>
        <translation>2 字节 (16 位)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="158"/>
        <source>4 Bytes (32-bit)</source>
        <translation>4 字节 (32 位)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="178"/>
        <source>Number type</source>
        <translation>数字进制</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="195"/>
        <source>Decimal</source>
        <translation>十进制</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="202"/>
        <source>Hexadecimal</source>
        <translation>十六进制</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="216"/>
        <source>Search type</source>
        <translation>搜索类型</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="223"/>
        <source>Equal to value</source>
        <translation>约等于下值</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="236"/>
        <source>Greater than value</source>
        <translation>大于下值</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="246"/>
        <source>Less than value</source>
        <translation>小于下值</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="256"/>
        <source>Unknown/changed</source>
        <translation>未知/已更改</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="269"/>
        <source>Changed by value</source>
        <translation>由下值更改</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="282"/>
        <source>Unchanged</source>
        <translation>无更改</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="295"/>
        <source>Increased</source>
        <translation>增加</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="308"/>
        <source>Decreased</source>
        <translation>减少</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="318"/>
        <source>Search ROM</source>
        <translation>查找 ROM</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="336"/>
        <source>New Search</source>
        <translation>新的查找</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="343"/>
        <source>Search Within</source>
        <translation>在结果中查找</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="350"/>
        <source>Open in Memory Viewer</source>
        <translation>在内存查看器中打开</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="357"/>
        <source>Refresh</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="224"/>
        <source> (%0/%1×)</source>
        <translation> (%0/%1×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="226"/>
        <source> (⅟%0×)</source>
        <translation> (⅟%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="229"/>
        <source> (%0×)</source>
        <translation> (%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="233"/>
        <source>%1 byte%2</source>
        <translation>%1 字节%2</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryView</name>
    <message>
        <location filename="../MemoryView.ui" line="14"/>
        <source>Memory</source>
        <translation>内存</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="192"/>
        <source>String:</source>
        <translation>字符串:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="205"/>
        <source>Load TBL</source>
        <translation>载入 TBL</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="233"/>
        <source>Copy Selection</source>
        <translation>复制所选</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="247"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="240"/>
        <source>Save Selection</source>
        <translation>保存所选</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="37"/>
        <source>Address:</source>
        <translation>地址：</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="106"/>
        <source>Alignment:</source>
        <translation>对齐：</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="120"/>
        <source>1 Byte</source>
        <translation>1 字节</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="125"/>
        <source>2 Bytes</source>
        <translation>2 字节</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="130"/>
        <source>4 Bytes</source>
        <translation>4 字节</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="152"/>
        <source>Signed:</source>
        <translation>签名：</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="172"/>
        <source>Unsigned:</source>
        <translation>未签名：</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="267"/>
        <source>Load</source>
        <translation>载入</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="282"/>
        <source>Selected address accesses</source>
        <translation>所选地址访问</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="304"/>
        <source>Logging configuration</source>
        <translation>日志配置</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="254"/>
        <source>Save Range</source>
        <translation>保存范围</translation>
    </message>
</context>
<context>
    <name>QGBA::MessagePainter</name>
    <message>
        <location filename="../MessagePainter.cpp" line="82"/>
        <source>Frame %1</source>
        <translation>帧 %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MultiplayerController</name>
    <message>
        <location filename="../MultiplayerController.cpp" line="314"/>
        <source>Couldn&apos;t find available save ID</source>
        <translation>无法找到有效的存档ID</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="368"/>
        <source>Trying to detach a multiplayer player that&apos;s not attached</source>
        <translation>尝试断开与未连接的多人玩家的连接</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="408"/>
        <source>Clearing invalid save ID</source>
        <translation>清理非法存档ID</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="417"/>
        <source>Clearing invalid preferred ID</source>
        <translation>清理非法优先ID</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="438"/>
        <source>Trying to get player ID for a multiplayer player that&apos;s not attached</source>
        <translation>尝试获取多人联机中未连接上的玩家ID</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="452"/>
        <source>Trying to get save ID for a multiplayer player that&apos;s not attached</source>
        <translation>尝试获取未连接的多人玩家的存档 ID</translation>
    </message>
</context>
<context>
    <name>QGBA::ObjView</name>
    <message>
        <location filename="../ObjView.ui" line="14"/>
        <source>Sprites</source>
        <translation>精灵图</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="72"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="94"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="122"/>
        <source>Magnification</source>
        <translation>缩放率</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="137"/>
        <source>Geometry</source>
        <translation>几何图</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="145"/>
        <source>Position</source>
        <translation>位置</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="224"/>
        <source>Dimensions</source>
        <translation>维度</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="316"/>
        <source>Matrix</source>
        <translation>矩阵</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="389"/>
        <source>Export</source>
        <translation>导出</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="402"/>
        <source>Attributes</source>
        <translation>属性</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="410"/>
        <source>Transform</source>
        <translation>变换</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="430"/>
        <location filename="../ObjView.cpp" line="182"/>
        <source>Off</source>
        <translation>关</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="444"/>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="481"/>
        <source>Double Size</source>
        <translation>双倍大小</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="548"/>
        <location filename="../ObjView.ui" line="561"/>
        <location filename="../ObjView.ui" line="632"/>
        <source>Return, Ctrl+R</source>
        <translation>回车键、Ctrl+R</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="522"/>
        <source>Flipped</source>
        <translation>已翻转</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="545"/>
        <source>H</source>
        <extracomment>Short for horizontal</extracomment>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="558"/>
        <source>V</source>
        <extracomment>Short for vertical</extracomment>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="572"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="592"/>
        <location filename="../ObjView.cpp" line="191"/>
        <source>Normal</source>
        <translation>普通</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="606"/>
        <source>Mosaic</source>
        <translation>马赛克</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="643"/>
        <source>Enabled</source>
        <translation>已启用</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="677"/>
        <source>Priority</source>
        <translation>优先级</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="715"/>
        <source>Tile</source>
        <translation>图块</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="161"/>
        <location filename="../ObjView.cpp" line="250"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="183"/>
        <location filename="../ObjView.cpp" line="184"/>
        <location filename="../ObjView.cpp" line="185"/>
        <location filename="../ObjView.cpp" line="186"/>
        <location filename="../ObjView.cpp" line="258"/>
        <location filename="../ObjView.cpp" line="259"/>
        <location filename="../ObjView.cpp" line="260"/>
        <location filename="../ObjView.cpp" line="261"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="194"/>
        <source>Trans</source>
        <translation>变换</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="197"/>
        <source>OBJWIN</source>
        <translation>OBJWIN</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="200"/>
        <source>Invalid</source>
        <translation>无效</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="257"/>
        <location filename="../ObjView.cpp" line="262"/>
        <source>N/A</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="288"/>
        <source>Export sprite</source>
        <translation>导出精灵图</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="289"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>便携式网络图形 (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::OverrideView</name>
    <message>
        <location filename="../OverrideView.ui" line="20"/>
        <source>Game Overrides</source>
        <translation>游戏替代</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="30"/>
        <source>Game Boy Advance</source>
        <translation>Game Boy Advance</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="42"/>
        <location filename="../OverrideView.ui" line="121"/>
        <location filename="../OverrideView.ui" line="241"/>
        <location filename="../OverrideView.ui" line="257"/>
        <source>Autodetect</source>
        <translation>自动检测</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="55"/>
        <source>Realtime clock</source>
        <translation>实时时钟</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="65"/>
        <source>Gyroscope</source>
        <translation>陀螺仪</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="75"/>
        <source>Tilt</source>
        <translation>图块</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="85"/>
        <source>Light sensor</source>
        <translation>光线传感器</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="95"/>
        <source>Rumble</source>
        <translation>振动</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="113"/>
        <source>Save type</source>
        <translation>保存类型</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="126"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="131"/>
        <source>SRAM</source>
        <translation>SRAM 32kB(/256kbit)</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="136"/>
        <source>Flash 512kb</source>
        <translation>Flash 512kb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="141"/>
        <source>Flash 1Mb</source>
        <translation>Flash 1Mb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="146"/>
        <source>EEPROM 8kB</source>
        <translation>EEPROM 8kB(/64kbit)</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="151"/>
        <source>EEPROM 512 bytes</source>
        <translation>EEPROM 512B(/4kbit)</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="156"/>
        <source>SRAM 64kB (bootlegs only)</source>
        <translation>SRAM 64kB(/512kbit)（盗版专用）</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="164"/>
        <source>Idle loop</source>
        <translation>空循环</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="190"/>
        <source>Game Boy Player features</source>
        <translation>Game Boy Player 功能</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="197"/>
        <source>VBA bug compatibility mode</source>
        <translation>VBA 错误兼容模式</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="227"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="233"/>
        <source>Game Boy model</source>
        <translation>Game Boy 型号</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="249"/>
        <source>Memory bank controller</source>
        <translation>内存 bank 控制器</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="265"/>
        <source>Background Colors</source>
        <translation>背景颜色</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="352"/>
        <source>Sprite Colors 1</source>
        <translation>精灵图颜色 1</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="359"/>
        <source>Sprite Colors 2</source>
        <translation>精灵图颜色 2</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="529"/>
        <source>Palette preset</source>
        <translation>调色板预设</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="68"/>
        <source>Official MBCs</source>
        <translation>官方 MBCs</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="72"/>
        <source>Licensed MBCs</source>
        <translation>授权 MBC</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="76"/>
        <source>Unlicensed MBCs</source>
        <translation>未授权 MBC</translation>
    </message>
</context>
<context>
    <name>QGBA::PaletteView</name>
    <message>
        <location filename="../PaletteView.ui" line="14"/>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="44"/>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="94"/>
        <source>Objects</source>
        <translation>对象</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="153"/>
        <source>Selection</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="184"/>
        <source>Red</source>
        <translation>红</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="191"/>
        <source>Green</source>
        <translation>绿</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="198"/>
        <source>Blue</source>
        <translation>蓝</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="253"/>
        <source>16-bit value</source>
        <translation>16 位值</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="260"/>
        <source>Hex code</source>
        <translation>十六进制代码</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="267"/>
        <source>Palette index</source>
        <translation>调色板索引</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="340"/>
        <source>Export BG</source>
        <translation>导出背景</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="360"/>
        <source>Export OBJ</source>
        <translation>导出 OBJ</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="119"/>
        <source>#%0</source>
        <translation>#%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="120"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="121"/>
        <location filename="../PaletteView.cpp" line="122"/>
        <location filename="../PaletteView.cpp" line="123"/>
        <location filename="../PaletteView.cpp" line="124"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="136"/>
        <source>Export palette</source>
        <translation>导出调色板</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="137"/>
        <source>Windows PAL (*.pal);;Adobe Color Table (*.act)</source>
        <translation>Windows 调色板 (*.pal);;Adobe 颜色表 (*.act)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="143"/>
        <source>Failed to open output palette file: %1</source>
        <translation>打开输出调色板文件失败: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::PlacementControl</name>
    <message>
        <location filename="../PlacementControl.ui" line="20"/>
        <source>Adjust placement</source>
        <translation>更改布局</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="26"/>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="65"/>
        <source>Offset</source>
        <translation>偏移</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="72"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="79"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
</context>
<context>
    <name>QGBA::PrinterView</name>
    <message>
        <location filename="../PrinterView.ui" line="14"/>
        <source>Game Boy Printer</source>
        <translation>Game Boy 打印机</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="130"/>
        <source>Hurry up!</source>
        <translation>快点！</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="137"/>
        <source>Tear off</source>
        <translation>剪下</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="180"/>
        <source>Magnification</source>
        <translation>缩放率</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="223"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="60"/>
        <source>Save Printout</source>
        <translation>保存打印输出</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="60"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>便携式网络图形 (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::ROMInfo</name>
    <message>
        <location filename="../ROMInfo.cpp" line="48"/>
        <location filename="../ROMInfo.cpp" line="62"/>
        <location filename="../ROMInfo.cpp" line="70"/>
        <location filename="../ROMInfo.cpp" line="78"/>
        <location filename="../ROMInfo.cpp" line="89"/>
        <location filename="../ROMInfo.cpp" line="102"/>
        <source>(unknown)</source>
        <translation>(未知)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="57"/>
        <source> bytes</source>
        <translation> 字节</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="92"/>
        <source>(no database present)</source>
        <translation>(无现存数据库)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="14"/>
        <source>ROM Info</source>
        <translation>ROM 信息</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="23"/>
        <source>File information</source>
        <translation>文件信息</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="29"/>
        <source>Game name:</source>
        <translation>游戏名称:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="83"/>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="100"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="134"/>
        <source>ROM header</source>
        <translation>ROM 头</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="140"/>
        <source>Internal name:</source>
        <translation>内部名称:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="157"/>
        <source>Game ID:</source>
        <translation>游戏 ID:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="174"/>
        <source>Maker Code:</source>
        <translation>创建者代码：</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="191"/>
        <source>Revision:</source>
        <translation>修订：</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="49"/>
        <source>File size:</source>
        <translation>文件大小:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="66"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="117"/>
        <source>Save file:</source>
        <translation>保存文件:</translation>
    </message>
</context>
<context>
    <name>QGBA::ReportView</name>
    <message>
        <location filename="../ReportView.cpp" line="436"/>
        <source>Bug report archive</source>
        <translation>错误报告存档</translation>
    </message>
    <message>
        <location filename="../ReportView.cpp" line="436"/>
        <source>ZIP archive (*.zip)</source>
        <translation>ZIP 存档 (*.zip)</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="14"/>
        <source>Generate Bug Report</source>
        <translation>生成错误报告</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="67"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To file a bug report, please first generate a report file to attach to the bug report you&apos;re about to file. It is recommended that you include the save files, as these often help with debugging issues. This will collect some information about the version of {projectName} you&apos;re running, your configuration, your computer, and the game you currently have open (if any). Once this collection is completed you can review all of the information gathered below and save it to a zip file. The collection will automatically attempt to redact any personal information, such as your username if it&apos;s in any of the paths gathered, but just in case you can edit it afterwards. After you have generated and saved it, please click the button below or go to &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt; to file the bug report on GitHub. Make sure to attach the report you generated!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;要提交错误报告，请先生成一个报告文件并将其附加到您即将提交的错误报告中。建议您包含存档文件，因为它们通常有助于调试问题。此文件将收集一些关于您正在运行的 {projectName} 版本、您的配置、您的计算机以及您当前打开的游戏（如有）的信息。收集完成后，您可以查看下方收集的所有信息并将其保存到 zip 文件中。收集过程会自动尝试删除任何个人信息，例如您的用户名（如果包含在任何收集到的路径中），但以防万一，您之后可以进行编辑。生成并保存后，请点击下方按钮或访问 &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt; 在 GitHub 上提交错误报告。请务必附加您生成的报告！&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="85"/>
        <source>Generate report</source>
        <translation>生成报告</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="99"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="113"/>
        <source>Open issue list in browser</source>
        <translation>在浏览器中打开问题列表</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="134"/>
        <source>Include save file</source>
        <translation>包含存档文件</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="150"/>
        <source>Create and include savestate</source>
        <translation>创建并包含即时存档</translation>
    </message>
</context>
<context>
    <name>QGBA::SaveConverter</name>
    <message>
        <location filename="../SaveConverter.cpp" line="39"/>
        <source>Save games and save states (%1)</source>
        <translation>保存游戏和即时存档 (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="40"/>
        <source>Select save game or save state</source>
        <translation>选择保存游戏或即时存档</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="52"/>
        <source>Save games (%1)</source>
        <translation>保存游戏 (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="53"/>
        <source>Select save game</source>
        <translation>选择保存游戏</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="74"/>
        <location filename="../SaveConverter.cpp" line="85"/>
        <source>Conversion failed</source>
        <translation>转换失败</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="74"/>
        <source>Failed to convert the save game. This is probably a bug.</source>
        <translation>未能转换保存游戏。这可能是一个错误。</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="85"/>
        <source>Failed to open output file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="96"/>
        <source>No file selected</source>
        <translation>未选择文件</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="103"/>
        <source>Could not open file</source>
        <translation>无法打开文件</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="118"/>
        <source>No valid formats found</source>
        <translation>未找到有效格式</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="126"/>
        <source>Please select a valid input file</source>
        <translation>请选择一个有效的输入文件</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="137"/>
        <source>No valid conversions found</source>
        <translation>未发现有效转换</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="666"/>
        <source>Cannot convert save games between platforms</source>
        <translation>无法在平台之间转换保存游戏</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="14"/>
        <source>Convert/Extract Save Game</source>
        <translation>转换或提取保存游戏</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="20"/>
        <source>Input file</source>
        <translation>输入文件</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="29"/>
        <location filename="../SaveConverter.ui" line="55"/>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="46"/>
        <source>Output file</source>
        <translation>输出文件</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="461"/>
        <source>%1 %2 save game</source>
        <translation>%1 %2 保存游戏</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="465"/>
        <source>little endian</source>
        <translation>小端</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="468"/>
        <source>big endian</source>
        <translation>大端</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="479"/>
        <source>SRAM</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="483"/>
        <source>%1 flash</source>
        <translation>%1 闪存</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="487"/>
        <source>%1 EEPROM</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="493"/>
        <source> + RTC</source>
        <translation> + RTC</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="502"/>
        <source>%1 SRAM + RTC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="504"/>
        <source>%1 SRAM</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="509"/>
        <source>packed MBC2</source>
        <translation>包装的 MBC2</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="511"/>
        <source>unpacked MBC2</source>
        <translation>未包装的 MBC2</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="516"/>
        <source>MBC6 flash</source>
        <translation>MBC6 闪存</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="518"/>
        <source>MBC6 combined SRAM + flash</source>
        <translation>MBC6 组合 SRAM + 闪存</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="520"/>
        <source>MBC6 SRAM</source>
        <translation>MBC6 SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="524"/>
        <source>TAMA5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="536"/>
        <source>%1 (%2)</source>
        <translation>%1（%2）</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="540"/>
        <source>%1 save state with embedded %2 save game</source>
        <translation>带嵌入的 %2 保存游戏的 %1 保存状态</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="543"/>
        <source>%1 SharkPort %2 save game</source>
        <translation>%1 SharkPort %2 存档</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="546"/>
        <source>%1 GameShark Advance SP %2 save game</source>
        <translation>%1 GameShark Advance SP %2 存档</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingController</name>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="281"/>
        <source>Lua scripts (*.lua)</source>
        <translation>Lua 脚本 (*.lua)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="283"/>
        <source>All files (*.*)</source>
        <translation>所有文件 (*.*)</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingTextBuffer</name>
    <message>
        <location filename="../scripting/ScriptingTextBuffer.cpp" line="45"/>
        <source>Untitled buffer</source>
        <translation>无标题缓存</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingView</name>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="14"/>
        <source>Scripting</source>
        <translation>脚本</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="71"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="92"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="96"/>
        <source>Load recent script</source>
        <translation>载入历史脚本</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="108"/>
        <source>View</source>
        <translation>查看</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="118"/>
        <source>Load script...</source>
        <translation>载入脚本...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="123"/>
        <source>&amp;Load most recent</source>
        <translation>载入最近的(&amp;L)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="128"/>
        <source>&amp;Reset</source>
        <translation>重置(&amp;R)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="133"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="138"/>
        <source>Edit autorun scripts...</source>
        <translation>编辑自动运行脚本...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="143"/>
        <source>Clear console</source>
        <translation>清除控制台</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.cpp" line="67"/>
        <source>Select script to load</source>
        <translation>选择要载入的脚本</translation>
    </message>
</context>
<context>
    <name>QGBA::SensorView</name>
    <message>
        <location filename="../SensorView.ui" line="20"/>
        <source>Sensors</source>
        <translation>传感器</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="31"/>
        <source>Realtime clock</source>
        <translation>实时时钟</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="50"/>
        <source>Fixed time</source>
        <translation>定时</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="37"/>
        <source>System time</source>
        <translation>系统时间</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="96"/>
        <source>Start time at</source>
        <translation>开始时间</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="60"/>
        <source>Now</source>
        <translation>现在</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="67"/>
        <source>Offset time</source>
        <translation>偏移时间</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="80"/>
        <source> sec</source>
        <translation> 秒</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="126"/>
        <source>MM/dd/yy hh:mm:ss AP</source>
        <translation>yyyy/MM/dd HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="136"/>
        <source>Light sensor</source>
        <translation>光线传感器</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="142"/>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="179"/>
        <source>Tilt sensor</source>
        <translation>倾斜传感器</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="187"/>
        <location filename="../SensorView.ui" line="276"/>
        <source>Set Y</source>
        <translation>设定 Y 轴</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="197"/>
        <location filename="../SensorView.ui" line="286"/>
        <source>Set X</source>
        <translation>设定 X 轴</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="268"/>
        <source>Gyroscope</source>
        <translation>陀螺仪</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="296"/>
        <source>Sensitivity</source>
        <translation>灵敏度</translation>
    </message>
</context>
<context>
    <name>QGBA::SettingsView</name>
    <message>
        <location filename="../SettingsView.cpp" line="158"/>
        <location filename="../SettingsView.cpp" line="233"/>
        <source>Qt Multimedia</source>
        <translation>Qt Multimedia</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="165"/>
        <source>SDL</source>
        <translation>SDL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="173"/>
        <source>Software (Qt)</source>
        <translation>软件渲染 (Qt)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1315"/>
        <location filename="../SettingsView.cpp" line="179"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="186"/>
        <source>OpenGL (force version 1.x)</source>
        <translation>OpenGL (强制版本 1.x)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="219"/>
        <source>None</source>
        <translation>无</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="226"/>
        <source>None (Still Image)</source>
        <translation>无 (静止图像)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="335"/>
        <source>Keyboard</source>
        <translation>键盘</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="347"/>
        <source>Controllers</source>
        <translation>控制器</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="412"/>
        <source>Shortcuts</source>
        <translation>快捷键</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="415"/>
        <source>Shaders are not supported when the display driver is not OpenGL.

If it is set to OpenGL and you still see this, your graphics card or drivers may be too old.</source>
        <translation>当显示驱动程序不是 OpenGL 时，不支持着色器。

如果设置为 OpenGL 并且您仍然看到此信息，则您的显卡或驱动程序可能太旧了。</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="419"/>
        <location filename="../SettingsView.cpp" line="433"/>
        <location filename="../SettingsView.cpp" line="446"/>
        <location filename="../SettingsView.cpp" line="448"/>
        <source>Shaders</source>
        <translation>着色器</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="469"/>
        <source>Select BIOS</source>
        <translation>选择 BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="476"/>
        <source>Select directory</source>
        <translation>选择目录</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="484"/>
        <source>Select image</source>
        <translation>选择图片</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="484"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>图像文件（*.png *.jpg *.jpeg）</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="878"/>
        <source>(%1×%2)</source>
        <translation>(%1×%2)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="896"/>
        <source>Never</source>
        <translation>从不</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="901"/>
        <source>Just now</source>
        <translation>刚刚</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="905"/>
        <source>Less than an hour ago</source>
        <translation>不到一小时前</translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="910"/>
        <source>%n hour(s) ago</source>
        <translation>
            <numerusform>%n 小时前</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="914"/>
        <source>%n day(s) ago</source>
        <translation>
            <numerusform>%n 天前</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="20"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="45"/>
        <source>Audio/Video</source>
        <translation>音频/视频</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="50"/>
        <source>Gameplay</source>
        <translation>游玩设置</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="55"/>
        <source>Interface</source>
        <translation>用户界面</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="60"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="65"/>
        <source>Emulation</source>
        <translation>模拟器</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="70"/>
        <source>Enhancements</source>
        <translation>增强</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="75"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="80"/>
        <source>Paths</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="85"/>
        <source>Logging</source>
        <translation>日志记录</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="90"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="111"/>
        <source>Audio driver:</source>
        <translation>音频驱动程序:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="128"/>
        <source>Audio buffer:</source>
        <translation>音频缓冲:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="140"/>
        <location filename="../SettingsView.ui" line="162"/>
        <source>1536</source>
        <translation>1536</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="147"/>
        <source>512</source>
        <translation>512</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="152"/>
        <source>768</source>
        <translation>768</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="157"/>
        <source>1024</source>
        <translation>1024</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="167"/>
        <source>2048</source>
        <translation>2048</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="172"/>
        <source>3072</source>
        <translation>3072</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="177"/>
        <source>4096</source>
        <translation>4096</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="185"/>
        <source>samples</source>
        <translation>采样</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="194"/>
        <source>Sample rate:</source>
        <translation>采样率:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="206"/>
        <location filename="../SettingsView.ui" line="223"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="213"/>
        <source>22050</source>
        <translation>22050</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="218"/>
        <source>32000</source>
        <translation>32000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="228"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="236"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="245"/>
        <source>Volume:</source>
        <translation>音量:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="276"/>
        <location filename="../SettingsView.ui" line="316"/>
        <location filename="../SettingsView.ui" line="811"/>
        <location filename="../SettingsView.ui" line="836"/>
        <source>Mute</source>
        <translation>静音</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="285"/>
        <source>Fast forward volume:</source>
        <translation>快进音量:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="325"/>
        <source>Audio in multiplayer:</source>
        <translation>多人游戏中的音频：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="332"/>
        <source>All windows</source>
        <translation>所有窗口</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="345"/>
        <source>Player 1 window only</source>
        <translation>仅 P1 窗口</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="355"/>
        <source>Currently active player window</source>
        <translation>当前活跃的玩家窗口</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="388"/>
        <source>Display driver:</source>
        <translation>显示驱动程序:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="405"/>
        <source>Frameskip:</source>
        <translation>跳帧:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="414"/>
        <source>Skip every</source>
        <translation>每间隔</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="424"/>
        <location filename="../SettingsView.ui" line="1199"/>
        <source>frames</source>
        <translation>帧</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="475"/>
        <source>FPS target:</source>
        <translation>目标 FPS:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="500"/>
        <source>frames per second</source>
        <translation>帧每秒</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="516"/>
        <source>Sync:</source>
        <translation>同步:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="382"/>
        <location filename="../SettingsView.ui" line="525"/>
        <source>Video</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="105"/>
        <location filename="../SettingsView.ui" line="532"/>
        <source>Audio</source>
        <translation>音频</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="433"/>
        <source>Lock aspect ratio</source>
        <translation>锁定纵横比</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="440"/>
        <source>Force integer scaling</source>
        <translation>强制整数缩放</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="454"/>
        <source>Bilinear filtering</source>
        <translation>双线性过滤</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="757"/>
        <source>Show filename instead of ROM name in library view</source>
        <translation>库视图中显示文件名替代 ROM 名</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="804"/>
        <location filename="../SettingsView.ui" line="829"/>
        <source>Pause</source>
        <translation>暂停</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="795"/>
        <source>When inactive:</source>
        <translation>不活跃时：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="548"/>
        <source>On loading a game:</source>
        <translation>在加载游戏时:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="555"/>
        <source>Load last state</source>
        <translation>加载最后的即时存档</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="565"/>
        <source>Load cheats</source>
        <translation>加载作弊</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="599"/>
        <source>Save entered cheats</source>
        <translation>保存已输入的作弊码</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="820"/>
        <source>When minimized:</source>
        <translation>最小化时：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="959"/>
        <source>Current channel:</source>
        <translation>当前通道：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="973"/>
        <source>Current version:</source>
        <translation>当前版本：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="997"/>
        <source>Update channel:</source>
        <translation>更新通道：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1007"/>
        <source>Available version:</source>
        <translation>可用版本：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1014"/>
        <source>(Unknown)</source>
        <translation>(未知)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1024"/>
        <source>Last checked:</source>
        <translation>上次检查更新时间：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1045"/>
        <source>Automatically check on start</source>
        <translation>启动时自动检查</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1052"/>
        <source>Check now</source>
        <translation>立即检查更新</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2174"/>
        <source>Default color palette only</source>
        <translation>只使用默认调色板</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2167"/>
        <source>SGB color palette if available</source>
        <translation>可用时使用 SGB 调色板</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2181"/>
        <source>GBC color palette if available</source>
        <translation>可用时使用 GBC 调色板</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2188"/>
        <source>SGB (preferred) or GBC color palette if available</source>
        <translation>可用时使用 SGB（首选）或 GBC 调色板</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2200"/>
        <source>Game Boy Camera</source>
        <translation>Game Boy Camera</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2206"/>
        <source>Driver:</source>
        <translation>驱动：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2223"/>
        <source>Source:</source>
        <translation>来源：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="509"/>
        <source>Native (59.7275)</source>
        <translation>原生 (59.7275)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="447"/>
        <source>Interframe blending</source>
        <translation>帧间混合</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="709"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="726"/>
        <source>Library:</source>
        <translation>库:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="734"/>
        <source>List view</source>
        <translation>列表视图</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="739"/>
        <source>Tree view</source>
        <translation>树状视图</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="747"/>
        <source>Show when no game open</source>
        <translation>未打开游戏时显示</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="764"/>
        <source>Clear cache</source>
        <translation>清除缓存</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="778"/>
        <source>Allow opposing input directions</source>
        <translation>允许相对方向输入</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="785"/>
        <source>Suspend screensaver</source>
        <translation>停用屏幕保护程序</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="852"/>
        <source>Dynamically update window title</source>
        <translation>动态更新窗口标题</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="872"/>
        <source>Show filename instead of ROM name in title bar</source>
        <translation>标题栏显示文件名而不显示 ROM 名称</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="889"/>
        <source>Show OSD messages</source>
        <translation>显示 OSD 信息</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="698"/>
        <source>Enable Discord Rich Presence</source>
        <translation>启用 Discord Rich Presence</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="575"/>
        <source>Edit autorun scripts</source>
        <translation>编辑自动运行脚本</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="589"/>
        <source>Periodically autosave state</source>
        <translation>定时自动即时存档</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="862"/>
        <source>Show FPS in title bar</source>
        <translation>在标题栏显示 FPS</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="904"/>
        <source>Show frame count in OSD</source>
        <translation>OSD 中显示帧数</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="911"/>
        <source>Show emulation info on reset</source>
        <translation>重置时显示模拟信息</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="948"/>
        <source>Custom border:</source>
        <translation>自定义边框:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1066"/>
        <source>Fast forward speed:</source>
        <translation>快进速度:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1097"/>
        <location filename="../SettingsView.ui" line="1140"/>
        <source>Unbounded</source>
        <translation>不限制</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1109"/>
        <source>Fast forward (held) speed:</source>
        <translation>快进 (按住) 速度:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1152"/>
        <source>Autofire interval:</source>
        <translation>连发间隔:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1176"/>
        <source>Enable rewind</source>
        <translation>启用倒带</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1183"/>
        <source>Rewind history:</source>
        <translation>倒带历史:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1208"/>
        <source>Rewind speed:</source>
        <translation>倒带速度:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1245"/>
        <source>Idle loops:</source>
        <translation>空循环:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1253"/>
        <source>Run all</source>
        <translation>全部运行</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1258"/>
        <source>Remove known</source>
        <translation>移除已知</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1263"/>
        <source>Detect and remove</source>
        <translation>检测并移除</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1271"/>
        <source>Preload entire ROM into memory</source>
        <translation>将整个 ROM 预载到内存中</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="616"/>
        <source>Save state extra data:</source>
        <translation>保存存档附加数据：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="633"/>
        <location filename="../SettingsView.ui" line="677"/>
        <source>Save game</source>
        <translation>保存游戏</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="660"/>
        <source>Load state extra data:</source>
        <translation>载入存档附加数据：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1815"/>
        <source>Models</source>
        <translation>型号</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1821"/>
        <source>GB only:</source>
        <translation>仅 GB：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1831"/>
        <source>SGB compatible:</source>
        <translation>兼容 SGB：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1841"/>
        <source>GBC only:</source>
        <translation>仅 GBC：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1851"/>
        <source>GBC compatible:</source>
        <translation>兼容 GBC：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1861"/>
        <source>SGB and GBC compatible:</source>
        <translation>兼容 SGB 和 GBC：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1881"/>
        <source>Game Boy palette</source>
        <translation>Game Boy 调色板</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1887"/>
        <source>Preset:</source>
        <translation>预设：</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="623"/>
        <location filename="../SettingsView.ui" line="667"/>
        <source>Screenshot</source>
        <translation>截图</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="643"/>
        <location filename="../SettingsView.ui" line="684"/>
        <source>Cheat codes</source>
        <translation>作弊码</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1281"/>
        <source>Enable Game Boy Player features by default</source>
        <translation>默认启用 Game Boy Player 功能</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1288"/>
        <source>Enable VBA bug compatibility in ROM hacks</source>
        <translation>启用用于改版的 VBA 漏洞兼容模式</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1302"/>
        <source>Video renderer:</source>
        <translation>视频渲染器:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1310"/>
        <source>Software</source>
        <translation>软件</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1323"/>
        <source>OpenGL enhancements</source>
        <translation>OpenGL 增强</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1329"/>
        <source>High-resolution scale:</source>
        <translation>高分辨率比例:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1367"/>
        <source>(240×160)</source>
        <translation>(240×160)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1396"/>
        <source>GB BIOS file:</source>
        <translation>GB BIOS 文件:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="932"/>
        <location filename="../SettingsView.ui" line="1415"/>
        <location filename="../SettingsView.ui" line="1443"/>
        <location filename="../SettingsView.ui" line="1471"/>
        <location filename="../SettingsView.ui" line="1499"/>
        <location filename="../SettingsView.ui" line="1557"/>
        <location filename="../SettingsView.ui" line="1605"/>
        <location filename="../SettingsView.ui" line="1653"/>
        <location filename="../SettingsView.ui" line="1701"/>
        <location filename="../SettingsView.ui" line="1749"/>
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1508"/>
        <source>Use BIOS file if found</source>
        <translation>当可用时使用 BIOS 文件</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1518"/>
        <source>Skip BIOS intro</source>
        <translation>跳过 BIOS 启动画面</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1480"/>
        <source>GBA BIOS file:</source>
        <translation>GBA BIOS 文件:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1452"/>
        <source>GBC BIOS file:</source>
        <translation>GBC BIOS 文件:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1424"/>
        <source>SGB BIOS file:</source>
        <translation>SGB BIOS 文件:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1532"/>
        <source>Save games</source>
        <translation>游戏存档</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1566"/>
        <location filename="../SettingsView.ui" line="1614"/>
        <location filename="../SettingsView.ui" line="1662"/>
        <location filename="../SettingsView.ui" line="1710"/>
        <location filename="../SettingsView.ui" line="1758"/>
        <source>Same directory as the ROM</source>
        <translation>与 ROM 所在目录相同</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1580"/>
        <source>Save states</source>
        <translation>即时存档</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1628"/>
        <source>Screenshots</source>
        <translation>截图</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1676"/>
        <source>Patches</source>
        <translation>补丁</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1724"/>
        <source>Cheats</source>
        <translation>作弊码</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1781"/>
        <source>Log to file</source>
        <translation>记录日志到文件</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1788"/>
        <source>Log to console</source>
        <translation>记录日志到控制台</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1802"/>
        <source>Select Log File</source>
        <translation>选择日志文件</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1897"/>
        <source>Default BG colors:</source>
        <translation>默认背景色:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1984"/>
        <source>Default sprite colors 1:</source>
        <translation>默认精灵图颜色 1:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2071"/>
        <source>Default sprite colors 2:</source>
        <translation>默认精灵图颜色 2:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1871"/>
        <source>Super Game Boy borders</source>
        <translation>Super Game Boy 边框</translation>
    </message>
</context>
<context>
    <name>QGBA::ShaderSelector</name>
    <message>
        <location filename="../ShaderSelector.cpp" line="78"/>
        <source>No shader active</source>
        <translation>无激活的着色器</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="92"/>
        <location filename="../ShaderSelector.cpp" line="95"/>
        <source>Load shader</source>
        <translation>载入着色器</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="94"/>
        <source>mGBA Shaders</source>
        <translation>mGBA 着色器</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="125"/>
        <source>Error loading shader</source>
        <translation>加载着色器时出错</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="125"/>
        <source>The shader &quot;%1&quot; could not be loaded successfully.</source>
        <translation>着色器“%1”无法成功加载。</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="147"/>
        <source>No shader loaded</source>
        <translation>不载入着色器</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="155"/>
        <source>by %1</source>
        <translation>由 %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="166"/>
        <source>Preprocessing</source>
        <translation>预处理</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="173"/>
        <source>Pass %1</source>
        <translation>通道 %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="14"/>
        <source>Shaders</source>
        <translation>着色器</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="28"/>
        <source>Active Shader:</source>
        <translation>激活着色器:</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="35"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="45"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="62"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="88"/>
        <source>Unload Shader</source>
        <translation>卸载着色器</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="95"/>
        <source>Load New Shader</source>
        <translation>载入新着色器</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutModel</name>
    <message>
        <location filename="../ShortcutModel.cpp" line="68"/>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="70"/>
        <source>Keyboard</source>
        <translation>键盘</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="72"/>
        <source>Gamepad</source>
        <translation>游戏手柄</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutView</name>
    <message>
        <location filename="../ShortcutView.ui" line="14"/>
        <source>Edit Shortcuts</source>
        <translation>编辑快捷键</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="32"/>
        <source>Keyboard</source>
        <translation>键盘</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="42"/>
        <source>Gamepad</source>
        <translation>游戏手柄</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="49"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
</context>
<context>
    <name>QGBA::TileView</name>
    <message>
        <location filename="../TileView.cpp" line="227"/>
        <source>Export tiles</source>
        <translation>导出图块</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="228"/>
        <location filename="../TileView.cpp" line="240"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>便携式网络图形 (*.png)</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="239"/>
        <source>Export tile</source>
        <translation>导出图块</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="14"/>
        <source>Tiles</source>
        <translation>图块</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="170"/>
        <source>Export Selected</source>
        <translation>导出所选</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="184"/>
        <source>Export All</source>
        <translation>全部导出</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="40"/>
        <source>256 colors</source>
        <translation>256 色</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="33"/>
        <source>Palette</source>
        <translation>调色板</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="73"/>
        <source>Magnification</source>
        <translation>缩放率</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="96"/>
        <source>Tiles per row</source>
        <translation>每行图块</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="103"/>
        <source>Fit to window</source>
        <translation>自适应窗口</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="119"/>
        <source>Displayed tiles</source>
        <translation>已显示的图块</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="125"/>
        <source>Only BG tiles</source>
        <translation>仅 BG 图块</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="135"/>
        <source>Only OBJ tiles</source>
        <translation>仅 OBJ 图块</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="145"/>
        <source>Both</source>
        <translation>两者</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="163"/>
        <source>Copy Selected</source>
        <translation>复制所选</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="177"/>
        <source>Copy All</source>
        <translation>全部复制</translation>
    </message>
</context>
<context>
    <name>QGBA::VideoView</name>
    <message>
        <location filename="../VideoView.cpp" line="224"/>
        <source>Failed to open output video file: %1</source>
        <translation>打开输出视频文件失败: %1</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="245"/>
        <source>Native (%0x%1)</source>
        <translation>原生 (%0x%1)</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="260"/>
        <source>Select output file</source>
        <translation>选择输出文件</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="20"/>
        <source>Record Video</source>
        <translation>录制视频</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="40"/>
        <source>Start</source>
        <translation>开始</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="56"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="69"/>
        <source>Select File</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="101"/>
        <source>Presets</source>
        <translation>预置</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="109"/>
        <source>High &amp;Quality</source>
        <translation>高质量(&amp;Q)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="119"/>
        <source>&amp;YouTube</source>
        <translation>YouTube(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="129"/>
        <source>WebM</source>
        <translation>WebM</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="139"/>
        <source>MP4</source>
        <translation>MP4</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="146"/>
        <source>&amp;Lossless</source>
        <translation>无损(&amp;L)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="167"/>
        <source>4K</source>
        <translation>4K</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="174"/>
        <source>&amp;1080p</source>
        <translation>1080p(&amp;1)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="184"/>
        <source>&amp;720p</source>
        <translation>720p(&amp;7)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="194"/>
        <source>&amp;480p</source>
        <translation>480p(&amp;4)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="207"/>
        <source>&amp;Native</source>
        <translation>原生(&amp;N)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="240"/>
        <source>Format</source>
        <translation>格式</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="375"/>
        <source> Bitrate (kbps)</source>
        <translation> 比特率 (kbps)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="420"/>
        <source>ABR</source>
        <translation>ABR</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="465"/>
        <source>VBR</source>
        <translation>VBR</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="478"/>
        <source>CRF</source>
        <translation>CRF</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="494"/>
        <source>Dimensions</source>
        <translation>维度</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="560"/>
        <source>Lock aspect ratio</source>
        <translation>锁定纵横比</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="575"/>
        <source>Show advanced</source>
        <translation>显示高级选项</translation>
    </message>
</context>
<context>
    <name>QGBA::Window</name>
    <message>
        <location filename="../Window.cpp" line="354"/>
        <source>Archives (%1)</source>
        <translation>压缩文件 (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="359"/>
        <location filename="../Window.cpp" line="375"/>
        <location filename="../Window.cpp" line="402"/>
        <source>Select ROM</source>
        <translation>选择 ROM</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="393"/>
        <source>Select folder</source>
        <translation>选择文件夹</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="537"/>
        <location filename="../Window.cpp" line="544"/>
        <source>Select save</source>
        <translation>选择存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="449"/>
        <source>Select patch</source>
        <translation>选择补丁</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="449"/>
        <source>Patches (*.ips *.ups *.bps)</source>
        <translation>补丁 (*.ips *.ups *.bps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="460"/>
        <source>Select e-Reader dotcode</source>
        <translation>选择 e-Reader 点码</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="460"/>
        <source>e-Reader card (*.raw *.bin *.bmp)</source>
        <translation>e-Reader 卡 (*.raw *.bin *.bmp)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="530"/>
        <source>Select image</source>
        <translation>选择图片</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="530"/>
        <source>Image file (*.png *.gif *.jpg *.jpeg);;All files (*)</source>
        <translation>图像文件 (*.png *.gif *.jpg *.jpeg);;所有文件 (*)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="544"/>
        <source>GameShark saves (*.sps *.xps)</source>
        <translation>GameShark 存档 (*.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="583"/>
        <source>Select video log</source>
        <translation>选择视频日志</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="583"/>
        <source>Video logs (*.mvl)</source>
        <translation>视频日志文件 (*.mvl)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1040"/>
        <source>Crash</source>
        <translation>崩溃</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1041"/>
        <source>The game has crashed with the following error:

%1</source>
        <translation>游戏因以下错误而崩溃:

%1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1048"/>
        <source>Couldn&apos;t Start</source>
        <translation>无法启动</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1049"/>
        <source>Could not start game.</source>
        <translation>无法启动游戏。</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1063"/>
        <source>Unimplemented BIOS call</source>
        <translation>未实现的 BIOS 调用</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1064"/>
        <source>This game uses a BIOS call that is not implemented. Please use the official BIOS for best experience.</source>
        <translation>此游戏使用尚未实现的 BIOS 调用。请使用官方 BIOS 以获得最佳体验。</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1086"/>
        <source>Failed to create an appropriate display device, falling back to software display. Games may run slowly, especially with larger windows.</source>
        <translation>无法创建适合的显示设备，正在回滚到软件显示。游戏的运行速度（特别在大窗口的情况下）可能会变慢。</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1187"/>
        <source>Really make portable?</source>
        <translation>确定进行程序便携化？</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1188"/>
        <source>This will make the emulator load its configuration from the same directory as the executable. Do you want to continue?</source>
        <translation>进行此操作后，模拟器将从其可执行文件所在目录中载入模拟器配置。您想继续吗？</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1200"/>
        <source>Restart needed</source>
        <translation>需要重新启动</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1201"/>
        <source>Some changes will not take effect until the emulator is restarted.</source>
        <translation>更改将在模拟器下次重新启动时生效。</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1252"/>
        <source> -  Player %1 of %2</source>
        <translation> -  玩家 %1 共 %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1263"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1265"/>
        <source>%1 - %2 - %3</source>
        <translation>%1 - %2 - %3</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1267"/>
        <source>%1 - %2 (%3 fps) - %4</source>
        <translation>%1 - %2 (%3 fps) - %4</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1331"/>
        <source>&amp;File</source>
        <translation>文件(&amp;F)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1333"/>
        <source>Load &amp;ROM...</source>
        <translation>载入 ROM(&amp;R)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1336"/>
        <source>Load ROM in archive...</source>
        <translation>从压缩文件中载入 ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1337"/>
        <source>Add folder to library...</source>
        <translation>将文件夹添加到库中...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="410"/>
        <source>Save games (%1)</source>
        <translation>保存游戏 (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="411"/>
        <source>Select save game</source>
        <translation>选择保存游戏</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="419"/>
        <source>mGBA save state files (%1)</source>
        <translation>mGBA 即时存档文件 (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="421"/>
        <location filename="../Window.cpp" line="426"/>
        <source>Select save state</source>
        <translation>选择即时存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="468"/>
        <source>Select e-Reader card images</source>
        <translation>选择 e-Reader 卡片图像</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="468"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>图像文件（*.png *.jpg *.jpeg）</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="469"/>
        <source>Conversion finished</source>
        <translation>转换完成</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="510"/>
        <source>%1 of %2 e-Reader cards converted successfully.</source>
        <translation>成功转换了 %1 张（共 %2 张）e-Reader 卡片。</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1341"/>
        <source>Load alternate save game...</source>
        <translation>加载备用保存游戏...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1344"/>
        <source>Load temporary save game...</source>
        <translation>加载临时保存游戏...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1377"/>
        <source>Load &amp;patch...</source>
        <translation>载入补丁(&amp;P)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1380"/>
        <source>Boot BIOS</source>
        <translation>引导 BIOS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1474"/>
        <source>Replace ROM...</source>
        <translation>替换 ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1384"/>
        <source>Scan e-Reader dotcodes...</source>
        <translation>扫描 e-Reader 点码...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1825"/>
        <source>Convert e-Reader card image to raw...</source>
        <translation>将 e-Reader 卡片图像转换为原始数据...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1388"/>
        <source>ROM &amp;info...</source>
        <translation>ROM 信息(&amp;I)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1390"/>
        <source>Recent</source>
        <translation>最近打开</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1790"/>
        <source>Make portable</source>
        <translation>程序便携化</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1393"/>
        <source>&amp;Load state</source>
        <translation>载入即时存档(&amp;L)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1398"/>
        <source>Load state file...</source>
        <translation>载入即时存档文件...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1403"/>
        <source>&amp;Save state</source>
        <translation>保存即时存档(&amp;S)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1408"/>
        <source>Save state file...</source>
        <translation>保存即时存档文件...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1413"/>
        <source>Quick load</source>
        <translation>快速读档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1414"/>
        <source>Quick save</source>
        <translation>快速存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1416"/>
        <source>Load recent</source>
        <translation>载入最近存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1421"/>
        <source>Save recent</source>
        <translation>保存最近存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1429"/>
        <source>Undo load state</source>
        <translation>撤消读档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1432"/>
        <source>Undo save state</source>
        <translation>撤消存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1439"/>
        <location filename="../Window.cpp" line="1444"/>
        <source>State &amp;%1</source>
        <translation>即时存档 (&amp;%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1570"/>
        <source>Load camera image...</source>
        <translation>载入相机图片...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1350"/>
        <source>Convert save game...</source>
        <translation>转换保存游戏...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="537"/>
        <source>GameShark saves (*.gsv *.sps *.xps)</source>
        <translation>GameShark 存档 (*.gsv *.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1159"/>
        <source>Failed to start audio processor</source>
        <translation>启动音频处理器失败</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1212"/>
        <source>Reset needed</source>
        <translation>需要重启</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1213"/>
        <source>Some changes will not take effect until the game is reset.</source>
        <translation>某些改动需要重新启动才会生效。</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1340"/>
        <source>Save games</source>
        <translation>游戏存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1353"/>
        <source>Import GameShark Save...</source>
        <translation>导入 GameShark 存档...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1356"/>
        <source>Export GameShark Save...</source>
        <translation>导出 GameShark 存档...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1363"/>
        <source>Automatically determine</source>
        <translation>自动终止</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1367"/>
        <source>Use player %0 save game</source>
        <translation>使用玩家 %0 存档</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1451"/>
        <source>New multiplayer window</source>
        <translation>新建多人游戏窗口</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1454"/>
        <source>Connect to Dolphin...</source>
        <translation>连接到 Dolphin...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1460"/>
        <source>Report bug...</source>
        <translation>报告错误...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1466"/>
        <source>About...</source>
        <translation>关于...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1467"/>
        <source>E&amp;xit</source>
        <translation>退出(&amp;X)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1469"/>
        <source>&amp;Emulation</source>
        <translation>模拟(&amp;E)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1470"/>
        <source>&amp;Reset</source>
        <translation>重置(&amp;R)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1471"/>
        <source>Sh&amp;utdown</source>
        <translation>关机(&amp;U)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1475"/>
        <source>Yank game pak</source>
        <translation>快速抽出游戏卡带</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1478"/>
        <source>&amp;Pause</source>
        <translation>暂停(&amp;P)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1487"/>
        <source>&amp;Next frame</source>
        <translation>下一帧(&amp;N)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1491"/>
        <source>Fast forward (held)</source>
        <translation>快进 (长按)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1497"/>
        <source>&amp;Fast forward</source>
        <translation>快进(&amp;F)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1501"/>
        <source>Fast forward speed</source>
        <translation>快进速度</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1506"/>
        <source>Unbounded</source>
        <translation>不限制</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1510"/>
        <source>%0x</source>
        <translation>%0x</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1514"/>
        <source>Increase fast forward speed</source>
        <translation>加快快进速度</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1521"/>
        <source>Decrease fast forward speed</source>
        <translation>降低快进速度</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1528"/>
        <source>Rewind (held)</source>
        <translation>倒带 (长按)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1540"/>
        <source>Re&amp;wind</source>
        <translation>倒带(&amp;W)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1545"/>
        <source>Step backwards</source>
        <translation>步退</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1552"/>
        <source>Solar sensor</source>
        <translation>太阳光传感器</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1553"/>
        <source>Increase solar level</source>
        <translation>增加太阳光等级</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1554"/>
        <source>Decrease solar level</source>
        <translation>降低太阳光等级</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1555"/>
        <source>Brightest solar level</source>
        <translation>太阳光等级为最亮</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1558"/>
        <source>Darkest solar level</source>
        <translation>太阳光等级为最暗</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1564"/>
        <source>Brightness %1</source>
        <translation>亮度 %1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1572"/>
        <source>Game Boy Printer...</source>
        <translation>Game Boy 打印机...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1581"/>
        <source>BattleChip Gate...</source>
        <translation>BattleChip Gate...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1585"/>
        <source>Audio/&amp;Video</source>
        <translation>音频/视频(&amp;V)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1586"/>
        <source>Frame size</source>
        <translation>画面大小</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1588"/>
        <source>%1×</source>
        <translation>%1×</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1629"/>
        <source>Toggle fullscreen</source>
        <translation>切换全屏</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1632"/>
        <source>&amp;Lock frame size</source>
        <translation>锁定帧大小(&amp;L)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1645"/>
        <source>Lock aspect ratio</source>
        <translation>锁定纵横比</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1657"/>
        <source>Force integer scaling</source>
        <translation>强制整数缩放</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1669"/>
        <source>Interframe blending</source>
        <translation>帧间混合</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1678"/>
        <source>Bilinear filtering</source>
        <translation>双线性过滤</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1686"/>
        <source>Frame&amp;skip</source>
        <translation>跳帧(&amp;S)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1699"/>
        <source>Mute</source>
        <translation>静音</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1706"/>
        <source>FPS target</source>
        <translation>目标 FPS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1714"/>
        <source>Native (59.7275)</source>
        <translation>原生 (59.7275)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1729"/>
        <source>Take &amp;screenshot</source>
        <translation>截图(&amp;S)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1731"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1735"/>
        <source>Record A/V...</source>
        <translation>录制音频/视频...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1736"/>
        <source>Record GIF/WebP/APNG...</source>
        <translation>录制 GIF/WebP/APNG...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1740"/>
        <source>Video layers</source>
        <translation>视频图层</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1741"/>
        <source>Audio channels</source>
        <translation>音频声道</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1743"/>
        <source>Adjust layer placement...</source>
        <translation>调整图层布局...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1747"/>
        <source>Hide &amp;menu</source>
        <translation>隐藏 &amp;菜单</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1752"/>
        <source>&amp;Tools</source>
        <translation>工具(&amp;T)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1753"/>
        <source>View &amp;logs...</source>
        <translation>查看日志(&amp;L)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1755"/>
        <source>Game &amp;overrides...</source>
        <translation>覆写游戏(&amp;O)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1768"/>
        <source>Game Pak sensors...</source>
        <translation>游戏卡带传感器...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1781"/>
        <source>&amp;Cheats...</source>
        <translation>作弊码(&amp;C)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1786"/>
        <source>Create forwarder...</source>
        <translation>创建转发器...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1789"/>
        <source>Settings...</source>
        <translation>设置...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1794"/>
        <source>Open debugger console...</source>
        <translation>打开调试器控制台...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1796"/>
        <source>Start &amp;GDB server...</source>
        <translation>打开 GDB 服务器(&amp;G)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1783"/>
        <source>Scripting...</source>
        <translation>脚本...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1804"/>
        <source>Game state views</source>
        <translation>游戏状态视图</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1805"/>
        <source>View &amp;palette...</source>
        <translation>查看调色板(&amp;P)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1806"/>
        <source>View &amp;sprites...</source>
        <translation>查看精灵图(&amp;S)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1807"/>
        <source>View &amp;tiles...</source>
        <translation>查看图块(&amp;T)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1808"/>
        <source>View &amp;map...</source>
        <translation>查看映射(&amp;M)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1809"/>
        <source>&amp;Frame inspector...</source>
        <translation>帧检查器(&amp;F)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1810"/>
        <source>View memory...</source>
        <translation>查看内存...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1811"/>
        <source>Search memory...</source>
        <translation>搜索内存...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1812"/>
        <source>View &amp;I/O registers...</source>
        <translation>查看 I/O 寄存器(&amp;I)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1815"/>
        <source>Log memory &amp;accesses...</source>
        <translation>记录内存访问(&amp;a)...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1829"/>
        <source>Record debug video log...</source>
        <translation>记录调试视频日志...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1830"/>
        <source>Stop debug video log</source>
        <translation>停止记录调试视频日志</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1834"/>
        <source>Exit fullscreen</source>
        <translation>退出全屏</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1836"/>
        <source>GameShark Button (held)</source>
        <translation>GameShark 键 (长按)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1842"/>
        <source>Autofire</source>
        <translation>连发</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1843"/>
        <source>Autofire A</source>
        <translation>连发 A</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1848"/>
        <source>Autofire B</source>
        <translation>连发 B</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1853"/>
        <source>Autofire L</source>
        <translation>连发 L</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1858"/>
        <source>Autofire R</source>
        <translation>连发 R</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1863"/>
        <source>Autofire Start</source>
        <translation>连发 Start</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1868"/>
        <source>Autofire Select</source>
        <translation>连发 Select</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1873"/>
        <source>Autofire Up</source>
        <translation>连发 上</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1878"/>
        <source>Autofire Right</source>
        <translation>连发 右</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1883"/>
        <source>Autofire Down</source>
        <translation>连发 下</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1888"/>
        <source>Autofire Left</source>
        <translation>连发 左</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="2093"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../utils.cpp" line="26"/>
        <source>%1 byte</source>
        <translation>%1字节</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="29"/>
        <source>%1 kiB</source>
        <translation>%1 千字节</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="33"/>
        <source>%1 MiB</source>
        <translation>%1 兆字节</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="183"/>
        <source>Super (L)</source>
        <translation>Super (L)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="185"/>
        <source>Super (R)</source>
        <translation>Super (R)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="187"/>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../utils.cpp" line="174"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="176"/>
        <source>Control</source>
        <translation>Control</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="178"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="180"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
</context>
</TS>
