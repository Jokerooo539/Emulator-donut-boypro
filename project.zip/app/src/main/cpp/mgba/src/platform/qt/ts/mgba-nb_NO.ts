<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nb_NO" sourcelanguage="en_US">
<context>
    <name>LibraryTree</name>
    <message>
        <location filename="../library/LibraryModel.cpp" line="428"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="430"/>
        <source>Location</source>
        <translation>Sted</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="432"/>
        <source>Platform</source>
        <translation>Plattform</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="434"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="436"/>
        <source>CRC32</source>
        <translation>CRC32</translation>
    </message>
</context>
<context>
    <name>QGBA</name>
    <message>
        <location filename="../utils.cpp" line="109"/>
        <source>Game Boy Advance ROMs (%1)</source>
        <translation>Game Boy Advance ROM-filer (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="135"/>
        <source>Game Boy ROMs (%1)</source>
        <translation>Game Boy ROM-filer (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="140"/>
        <source>All ROMs (%1)</source>
        <translation>Alle ROM-filer (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="142"/>
        <source>%1 Video Logs (*.mvl)</source>
        <translation>%1-videologger (*.mvl)</translation>
    </message>
</context>
<context>
    <name>QGBA::AboutScreen</name>
    <message>
        <location filename="../AboutScreen.ui" line="14"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="23"/>
        <source>&lt;a href=&quot;http://mgba.io/&quot;&gt;Website&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Forums / Support&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Donate&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Source&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;https://mgba.io/&quot;&gt;Nettside&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Forum / støtte&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Doner&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Kildekode&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="41"/>
        <source>Branch: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revision: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</source>
        <translation>Gren: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revisjon: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="86"/>
        <source>© 2013 – {year} Jeffrey Pfau, licensed under the Mozilla Public License, version 2.0
Game Boy Advance is a registered trademark of Nintendo Co., Ltd.</source>
        <translation>© 2013 – {year} Jeffrey Pfau, lisensiert Mozilla Public License, versjon 2.0
Game Boy Advance er et registrert varemerke tilhørende Nintendo Co., Ltd.</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="68"/>
        <source>{projectName} would like to thank the following patrons from Patreon:</source>
        <translation>{projectName} takker følgende kronerullere fra Patreon:</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="177"/>
        <source>{projectName} is an open-source Game Boy Advance emulator</source>
        <translation>{projectName} er en fri Game Boy Advance-emulator</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdatePrompt</name>
    <message>
        <location filename="../ApplicationUpdatePrompt.ui" line="14"/>
        <source>An update is available</source>
        <translation>En oppdatering er tilgjengelig</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="27"/>
        <source>An update to %1 is available.
</source>
        <translation>En oppdatering til %1 er tilgjengelig.
</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="39"/>
        <source>
Do you want to download and install it now? You will need to restart the emulator when the download is complete.</source>
        <translation>
Vil du laste ned og installere den nå? Du vil måtte starte emulatoren på nytt når nedlastingen er fullført.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="42"/>
        <source>
Auto-update is not available on this platform. If you wish to update you will need to do it manually.</source>
        <translation>
Automatiske oppdateringer er ikke tilgjengelig på denne plattformen. Hvis du ønsker å oppdatere, må du gjøre det manuelt.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="46"/>
        <source>Current version: %1
New version: %2
Download size: %3</source>
        <translation>Nåværende versjon: %1
Ny versjon: %2
Nedlastningsstørrelse: %3</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="64"/>
        <source>Downloading update...</source>
        <translation>Laster ned oppdatering …</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="78"/>
        <source>Verifying download failed. Please update manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="82"/>
        <source>Downloading failed. Please update manually.</source>
        <translation>Nedlastingen mislyktes. Vennligst oppdater manuelt.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="84"/>
        <source>Downloading done. Press OK to restart %1 and install the update.</source>
        <translation>Nedlastingen er fullført. Trykk OK for å starte %1 på nytt og installere oppdateringen.</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdater</name>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="95"/>
        <source>Stable</source>
        <translation>Stabil</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="98"/>
        <source>Development</source>
        <translation>Utvikling</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="100"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="246"/>
        <source>(None)</source>
        <translation>(Ingen)</translation>
    </message>
</context>
<context>
    <name>QGBA::ArchiveInspector</name>
    <message>
        <location filename="../ArchiveInspector.ui" line="14"/>
        <source>Open in archive...</source>
        <translation>Åpne i arkiv …</translation>
    </message>
    <message>
        <location filename="../ArchiveInspector.ui" line="20"/>
        <source>Loading...</source>
        <translation>Laster inn ...</translation>
    </message>
</context>
<context>
    <name>QGBA::AssetTile</name>
    <message>
        <location filename="../AssetTile.ui" line="41"/>
        <source>Tile #</source>
        <translation>Tittel #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="65"/>
        <source>Palette #</source>
        <translation>Palett #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="89"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="138"/>
        <source>Red</source>
        <translation>Rød</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="145"/>
        <source>Green</source>
        <translation>Grønn</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="152"/>
        <source>Blue</source>
        <translation>Blå</translation>
    </message>
    <message>
        <location filename="../AssetTile.cpp" line="144"/>
        <location filename="../AssetTile.cpp" line="145"/>
        <location filename="../AssetTile.cpp" line="146"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioDevice</name>
    <message>
        <location filename="../AudioDevice.cpp" line="36"/>
        <source>Can&apos;t set format of context-less audio device</source>
        <translation>Kan ikke angi formatet til en kontekstløs lydenhet</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="57"/>
        <source>Audio device is missing its core</source>
        <translation>Lydenheten mangler kjernen sin</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="85"/>
        <source>Writing data to read-only audio device</source>
        <translation>Skriver data til skrivebeskyttet lydenhet</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorDummy</name>
    <message>
        <location filename="../AudioProcessorDummy.cpp" line="31"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation type="unfinished">Kan ikke starte en lydprosessor uten inndata</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorQt</name>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="57"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>Kan ikke starte en lydprosessor uten inndata</translation>
    </message>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="82"/>
        <source>Audio outputting to %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorSDL</name>
    <message>
        <location filename="../AudioProcessorSDL.cpp" line="35"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>Kan ikke starte en lydprosessor uten inndata</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptModel</name>
    <message>
        <location filename="../scripting/AutorunScriptModel.cpp" line="32"/>
        <source>Could not load autorun script settings: unknown script info format %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptView</name>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="14"/>
        <source>Autorun scripts</source>
        <translation>Autokjør skripter</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="20"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="30"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="53"/>
        <source>Move up</source>
        <translation>Flytt oppover</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="63"/>
        <source>Move down</source>
        <translation>Flytt nedover</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="73"/>
        <source>Run scripts when starting a game</source>
        <translation>Kjør skripter når du starter et spill</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.cpp" line="29"/>
        <source>Select a script</source>
        <translation>Velg et skript</translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipModel</name>
    <message>
        <location filename="../BattleChipModel.cpp" line="113"/>
        <source>Failed to open chip names list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipView</name>
    <message>
        <location filename="../BattleChipView.ui" line="14"/>
        <source>BattleChip Gate</source>
        <translation>BattleChip Gate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="67"/>
        <source>Chip name</source>
        <translation>Kretsnavn</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="76"/>
        <source>Insert</source>
        <translation>Sett inn</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="87"/>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="94"/>
        <source>Load</source>
        <translation>Last inn</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="114"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="121"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="138"/>
        <source>Gate type</source>
        <translation>Gate-type</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="180"/>
        <source>Inserted</source>
        <translation>Satt inn</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="194"/>
        <source>Chip ID</source>
        <translation>Krets-ID</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="207"/>
        <source>Update Chip data</source>
        <translation>Oppdater krets-data</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="219"/>
        <source>Show advanced</source>
        <translation>Vis avanserte innstillinger</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="112"/>
        <source>BattleChip data missing</source>
        <translation>BattleChip-data mangler</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="113"/>
        <source>BattleChip data is missing. BattleChip Gates will still work, but some graphics will be missing. Would you like to download the data now?</source>
        <translation>BattleChip-data mangler. BattleChip Gates vil fortsatt fungere, men noe grafikk vil mangle. Vil du laste ned dataene nå?</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="179"/>
        <location filename="../BattleChipView.cpp" line="198"/>
        <source>Select deck file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="210"/>
        <source>Incompatible deck</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="211"/>
        <source>The selected deck is not compatible with this Chip Gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsModel</name>
    <message>
        <location filename="../CheatsModel.cpp" line="54"/>
        <source>(untitled)</source>
        <translation>(uten tittel)</translation>
    </message>
    <message>
        <location filename="../CheatsModel.cpp" line="212"/>
        <source>Failed to open cheats file: %1</source>
        <translation>Mislyktes i å åpne juksekodefil: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsView</name>
    <message>
        <location filename="../CheatsView.ui" line="14"/>
        <source>Cheats</source>
        <translation>Juks</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="39"/>
        <source>Add New Code</source>
        <translation>Legg til ny kode</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="60"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="93"/>
        <source>Add Lines</source>
        <translation>Legg til linjer</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="100"/>
        <source>Code type</source>
        <translation>Kodetype</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="53"/>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="46"/>
        <source>Load</source>
        <translation>Last inn</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="86"/>
        <source>Enter codes here...</source>
        <translation>Skriv inn koder her …</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="50"/>
        <location filename="../CheatsView.cpp" line="58"/>
        <source>Autodetect (recommended)</source>
        <translation>Auto-oppdag (anbefales)</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="88"/>
        <location filename="../CheatsView.cpp" line="95"/>
        <source>Select cheats file</source>
        <translation>Velg juksekodefil</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="187"/>
        <source>Some cheats could not be added. Please ensure they&apos;re formatted correctly and/or try other cheat types.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::CoreController</name>
    <message>
        <location filename="../CoreController.cpp" line="106"/>
        <source>Reset r%1-%2 %3</source>
        <translation>Start r%1-%2 %3 på nyy</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="554"/>
        <location filename="../CoreController.cpp" line="571"/>
        <source>Rewinding not currently enabled</source>
        <translation>Tilbakespoling er ikke aktivert for øyeblikket</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="610"/>
        <source>Reset the game?</source>
        <translation>Vil du starte spillet på nytt?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="611"/>
        <source>Most games will require a reset to load the new save. Do you want to reset now?</source>
        <translation>De fleste spill vil kreve en omstart for å laste inn den nye lagringen. Vil du starte på nytt nå?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="829"/>
        <source>Failed to open save file: %1</source>
        <translation>Mislyktes i å åpne lagrefil: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="887"/>
        <source>Failed to open game file: %1</source>
        <translation>Klarte ikke å åpne spillfil: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="917"/>
        <source>Can&apos;t yank pack in unexpected platform!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1032"/>
        <source>Failed to open snapshot file for reading: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1049"/>
        <source>Failed to open snapshot file for writing: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::CoreManager</name>
    <message>
        <location filename="../CoreManager.cpp" line="58"/>
        <source>Failed to open game file: %1</source>
        <translation>Klarte ikke å åpne spillfil: %1</translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="105"/>
        <source>Temporary file loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="106"/>
        <source>The ROM appears to be loaded from a temporary directory, perhaps automatically extracted from an archive (e.g. a zip file).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="154"/>
        <source>Could not open save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="155"/>
        <source>Failed to open save file; in-game saves cannot be updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="228"/>
        <source>Would you like to copy the ROM to a different location? If you don&apos;t, this will likely lead to data loss (e.g. saves, screenshots, etc.).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="235"/>
        <source>Copy failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="235"/>
        <source>Failed to copy ROM. Do you want to try again?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="242"/>
        <source>New ROM location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="126"/>
        <source>Could not load game. Are you sure it&apos;s in the correct format?</source>
        <translation>Klarte ikke å laste inn spillet. Er du sikker på at det er i riktig format?</translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsole</name>
    <message>
        <location filename="../DebuggerConsole.ui" line="14"/>
        <source>Debugger</source>
        <translation>Avluser</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="27"/>
        <source>Enter command (try `help` for more info)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="34"/>
        <source>Break</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="44"/>
        <source>Continue</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsoleController</name>
    <message>
        <location filename="../DebuggerConsoleController.cpp" line="190"/>
        <source>Could not open CLI history for writing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::DisplayGL</name>
    <message>
        <location filename="../DisplayGL.cpp" line="310"/>
        <source>Failed to create an OpenGL 3 context, trying old-style...</source>
        <translation>Mislyktes i å opprette en OpenGL 3-kontekst. Prøver det på gamlemåten ...</translation>
    </message>
</context>
<context>
    <name>QGBA::DolphinConnector</name>
    <message>
        <location filename="../DolphinConnector.ui" line="14"/>
        <source>Connect to Dolphin</source>
        <translation>Koble til Dolphin</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="23"/>
        <source>Local computer</source>
        <translation>Lokal datamaskin</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="36"/>
        <source>IP address</source>
        <translation>IP-adresse</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="55"/>
        <source>Connect</source>
        <translation>Koble til</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="68"/>
        <source>Disconnect</source>
        <translation>Koble fra</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="78"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="90"/>
        <source>Reset on connect</source>
        <translation>Start på nytt ved tilkobling</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="58"/>
        <source>Couldn&apos;t Connect</source>
        <translation>Kunne ikke koble til</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="59"/>
        <source>Could not connect to Dolphin.</source>
        <translation>Klarte ikke å koble til Dolphin.</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator</name>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="84"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="86"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator3DS</name>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="30"/>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="31"/>
        <source>Banner</source>
        <translation>Plakat</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGeneratorVita</name>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="26"/>
        <source>Bubble</source>
        <translation>Boble</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="27"/>
        <source>Background</source>
        <translation>Bakgrunn</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="28"/>
        <source>Startup</source>
        <translation>Oppstart</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderView</name>
    <message>
        <location filename="../ForwarderView.ui" line="14"/>
        <source>Create forwarder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="20"/>
        <source>Files</source>
        <translation>Filer</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="26"/>
        <source>ROM file:</source>
        <translation>ROM-fil:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="36"/>
        <location filename="../ForwarderView.ui" line="53"/>
        <location filename="../ForwarderView.ui" line="112"/>
        <source>Browse</source>
        <translation>Bla</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="43"/>
        <source>Output filename:</source>
        <translation>Utdata-filnavn:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="60"/>
        <source>Forwarder base:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="74"/>
        <source>Latest stable version</source>
        <translation>Nyeste stabile versjon</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="79"/>
        <source>Latest development build</source>
        <translation>Nyeste utviklingsversjon</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="84"/>
        <source>Specific file</source>
        <translation>Spesifikk fil</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="95"/>
        <source>Base file:</source>
        <translation>Grunnfil:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="135"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="141"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="151"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="174"/>
        <source>Presentation</source>
        <translation>Presentasjon</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="182"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="195"/>
        <source>Images:</source>
        <translation>Bilder:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="215"/>
        <source>Use default image</source>
        <translation>Bruk standardbilde</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="328"/>
        <source>Preferred size:</source>
        <translation>Ønsket størrelse:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="395"/>
        <source>Select image file</source>
        <translation>Velg bildefil</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="23"/>
        <source>Select ROM file</source>
        <translation>Velg ROM-fil</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="24"/>
        <source>Select output filename</source>
        <translation>Velg utdatafilnavn</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="25"/>
        <source>Select base file</source>
        <translation>Velg grunnfil</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="37"/>
        <source>Build finished</source>
        <translation>Byggingen er ferdig</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="38"/>
        <source>Forwarder finished building</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="45"/>
        <source>Build failed</source>
        <translation>Byggingen mislyktes</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="46"/>
        <source>Failed to build forwarder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="177"/>
        <source>%1 installable package (*.%2)</source>
        <translation>%1 installerbar pakke (*.%2)</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="193"/>
        <source>Select an image</source>
        <translation>Velg et bilde</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="193"/>
        <source>Image files (*.png *.jpg *.bmp)</source>
        <translation>Bildefiler (*.png *.jpg *.bmp)</translation>
    </message>
</context>
<context>
    <name>QGBA::FrameView</name>
    <message>
        <location filename="../FrameView.ui" line="14"/>
        <source>Inspect frame</source>
        <translation>Inspiser ramme</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="41"/>
        <source>Magnification</source>
        <translation>Forstørrelse</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="50"/>
        <source>Freeze frame</source>
        <translation>Frys rammen</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="84"/>
        <source>Backdrop color</source>
        <translation>Bakgrunnsfarge</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="132"/>
        <source>Disable scanline effects</source>
        <translation>Skru av skannelinjeeffekter</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="145"/>
        <source>Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="152"/>
        <source>Reset</source>
        <translation>Tilbakestill</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="592"/>
        <source>Export frame</source>
        <translation>Eksporter ramme</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="593"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="623"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="625"/>
        <source>Background</source>
        <translation>Bakgrunn</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="628"/>
        <source>Window</source>
        <translation>Vindu</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="631"/>
        <source>Objwin</source>
        <translation>Objwin</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="636"/>
        <source>Sprite</source>
        <translation>Figur</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="639"/>
        <source>Backdrop</source>
        <translation>Bakgrunn</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="642"/>
        <source>Frame</source>
        <translation>Ramme</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="648"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAApp</name>
    <message>
        <location filename="../GBAApp.cpp" line="84"/>
        <source>Enable Discord Rich Presence</source>
        <translation>Skru på Discord Rich Presence</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAKeyEditor</name>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="70"/>
        <source>Clear Button</source>
        <translation>Tøm knapper</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="82"/>
        <source>Clear Analog</source>
        <translation>Tøm analoge</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="93"/>
        <source>Refresh</source>
        <translation>Gjenoppfrisk</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="103"/>
        <source>Set all</source>
        <translation>Sett alle</translation>
    </message>
</context>
<context>
    <name>QGBA::GDBWindow</name>
    <message>
        <location filename="../GDBWindow.cpp" line="32"/>
        <source>Server settings</source>
        <translation>Tjenerinnstillinger</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="38"/>
        <source>Local port</source>
        <translation>Lokal port</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="40"/>
        <source>Bind address</source>
        <translation>Bindingsadresse</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="53"/>
        <source>Write watchpoints behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="64"/>
        <source>Standard GDB</source>
        <translation>Standard GDB</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="69"/>
        <source>Internal change detection</source>
        <translation>Oppdaging av interne endringer</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="73"/>
        <source>Break on all writes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="83"/>
        <source>Break</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="125"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="138"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="146"/>
        <source>Crash</source>
        <translation>Krasj</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="146"/>
        <source>Could not start GDB server</source>
        <translation>Kunne ikke starte GDB-tjener</translation>
    </message>
</context>
<context>
    <name>QGBA::GIFView</name>
    <message>
        <location filename="../GIFView.ui" line="14"/>
        <source>Record GIF/WebP/APNG</source>
        <translation>Ta opp GIF/WebP/APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="30"/>
        <source>Loop</source>
        <translation>Gjenta</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="51"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="67"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="93"/>
        <source>Select File</source>
        <translation>Velg fil</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="112"/>
        <source>APNG</source>
        <translation>APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="122"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="135"/>
        <source>WebP</source>
        <translation>WebP</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="145"/>
        <source>Frameskip</source>
        <translation>Rammehopp</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="64"/>
        <source>Failed to open output file: %1</source>
        <translation>Klarte ikke å åpne utdatafil: %1</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="91"/>
        <source>Select output file</source>
        <translation>Velg utdatafil</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="91"/>
        <source>Graphics Interchange Format (*.gif);;WebP ( *.webp);;Animated Portable Network Graphics (*.png *.apng)</source>
        <translation>Graphics Interchange Format (*.gif);;WebP ( *.webp);;Animated Portable Network Graphics (*.png *.apng)</translation>
    </message>
</context>
<context>
    <name>QGBA::GameBoy</name>
    <message>
        <location filename="../GameBoy.cpp" line="62"/>
        <location filename="../GameBoy.cpp" line="81"/>
        <source>Autodetect</source>
        <translation>Auto-oppdag</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="63"/>
        <source>Game Boy (DMG)</source>
        <translation>Game Boy (DMG)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="64"/>
        <source>Game Boy Pocket (MGB)</source>
        <translation>Game Boy Pocket (MGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="65"/>
        <source>Super Game Boy (SGB)</source>
        <translation>Super Game Boy (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="66"/>
        <source>Super Game Boy 2 (SGB)</source>
        <translation>Super Game Boy 2 (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="67"/>
        <source>Game Boy Color (CGB)</source>
        <translation>Game Boy Color (CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="68"/>
        <source>Game Boy Advance (AGB)</source>
        <translation>Game Boy Advance (AGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="69"/>
        <source>Super Game Boy Color (SGB + CGB)</source>
        <translation>Super Game Boy Color (SGB + CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="82"/>
        <source>ROM Only</source>
        <translation>Kun ROM</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="86"/>
        <source>%1 + RTC</source>
        <translation>%1 + sanntidsklokke</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="88"/>
        <source>%1 + Rumble</source>
        <translation>%1 + Risting</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="90"/>
        <source>%1 (Tilt)</source>
        <translation>%1 (Tilt)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="98"/>
        <source>%1 (old 1)</source>
        <translation>%1 (gammel 1)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="99"/>
        <source>%1 (old 2)</source>
        <translation>%1 (gammel 2)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="100"/>
        <source>%1 (new)</source>
        <translation>%1 (ny)</translation>
    </message>
</context>
<context>
    <name>QGBA::IOViewer</name>
    <message>
        <location filename="../IOViewer.ui" line="14"/>
        <source>I/O Viewer</source>
        <translation>I/O-visning</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="26"/>
        <source>0x0000</source>
        <translation>0x0000</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="367"/>
        <location filename="../IOViewer.cpp" line="871"/>
        <location filename="../IOViewer.cpp" line="884"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="40"/>
        <source>Background mode</source>
        <translation>Bakgrunnsmodus</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="41"/>
        <source>Mode 0: 4 tile layers</source>
        <translation>Modus 0: 4 fliselag</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="42"/>
        <source>Mode 1: 2 tile layers + 1 rotated/scaled tile layer</source>
        <translation>Modus 1: 2 fliselag + 1 rotert/skalert fliselag</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="43"/>
        <source>Mode 2: 2 rotated/scaled tile layers</source>
        <translation>Modus 2: 2 roterte/skalerte fliselag</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="44"/>
        <source>Mode 3: Full 15-bit bitmap</source>
        <translation>Modus 3: Full 15-biters bitmap</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="45"/>
        <source>Mode 4: Full 8-bit bitmap</source>
        <translation>Modus 4: Full 8-biters bitmap</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="46"/>
        <source>Mode 5: Small 15-bit bitmap</source>
        <translation>Modus 5: Liten 15-biters bitmap</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="50"/>
        <source>CGB Mode</source>
        <translation>CGB-modus</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="51"/>
        <source>Frame select</source>
        <translation>Rammevalg</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="52"/>
        <source>Unlocked HBlank</source>
        <translation>Ulåst HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="53"/>
        <source>Linear OBJ tile mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="54"/>
        <source>Force blank screen</source>
        <translation>Tving blank skjerm</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="55"/>
        <source>Enable background 0</source>
        <translation>Skru på bakgrunn 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="56"/>
        <source>Enable background 1</source>
        <translation>Skru på bakgrunn 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="57"/>
        <source>Enable background 2</source>
        <translation>Skru på bakgrunn 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="58"/>
        <source>Enable background 3</source>
        <translation>Skru på bakgrunn 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="59"/>
        <source>Enable OBJ</source>
        <translation>Skru på OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="60"/>
        <source>Enable Window 0</source>
        <translation>Skru på vindu 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="61"/>
        <source>Enable Window 1</source>
        <translation>Skru på vindu 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="62"/>
        <source>Enable OBJ Window</source>
        <translation>Skru på OBJ-vindu</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="70"/>
        <source>Currently in VBlank</source>
        <translation>For øyeblikket i VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="71"/>
        <source>Currently in HBlank</source>
        <translation>For øyeblikket i HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="72"/>
        <source>Currently in VCounter</source>
        <translation>For øyeblikket i VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="73"/>
        <source>Enable VBlank IRQ generation</source>
        <translation>Skru på VBlank IRQ-generering</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="74"/>
        <source>Enable HBlank IRQ generation</source>
        <translation>Skru på HBlank IRQ-generering</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="75"/>
        <source>Enable VCounter IRQ generation</source>
        <translation>Skru på VCounter IRQ-generering</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="76"/>
        <source>VCounter scanline</source>
        <translation>VCounter-skannelinje</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="80"/>
        <source>Current scanline</source>
        <translation>Gjeldende skannelinje</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="84"/>
        <location filename="../IOViewer.cpp" line="93"/>
        <location filename="../IOViewer.cpp" line="102"/>
        <location filename="../IOViewer.cpp" line="112"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="85"/>
        <location filename="../IOViewer.cpp" line="94"/>
        <location filename="../IOViewer.cpp" line="103"/>
        <location filename="../IOViewer.cpp" line="113"/>
        <source>Tile data base (* 16kB)</source>
        <translation>Flisedatabase (* 16 kB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="86"/>
        <location filename="../IOViewer.cpp" line="95"/>
        <location filename="../IOViewer.cpp" line="104"/>
        <location filename="../IOViewer.cpp" line="114"/>
        <source>Enable mosaic</source>
        <translation>Skru på flislegging</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="87"/>
        <location filename="../IOViewer.cpp" line="96"/>
        <location filename="../IOViewer.cpp" line="105"/>
        <location filename="../IOViewer.cpp" line="115"/>
        <source>Enable 256-color</source>
        <translation>Skru på 256-fargemodus</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="88"/>
        <location filename="../IOViewer.cpp" line="97"/>
        <location filename="../IOViewer.cpp" line="106"/>
        <location filename="../IOViewer.cpp" line="116"/>
        <source>Tile map base (* 2kB)</source>
        <translation>Flisekartbase (* 2 kB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="89"/>
        <location filename="../IOViewer.cpp" line="98"/>
        <location filename="../IOViewer.cpp" line="108"/>
        <location filename="../IOViewer.cpp" line="118"/>
        <source>Background dimensions</source>
        <translation>Bakgrunnsdimensjoner</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="107"/>
        <location filename="../IOViewer.cpp" line="117"/>
        <source>Overflow wraps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="122"/>
        <location filename="../IOViewer.cpp" line="130"/>
        <location filename="../IOViewer.cpp" line="138"/>
        <location filename="../IOViewer.cpp" line="146"/>
        <location filename="../IOViewer.cpp" line="1365"/>
        <location filename="../IOViewer.cpp" line="1406"/>
        <source>Horizontal offset</source>
        <translation>Vannrett forskyvning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="126"/>
        <location filename="../IOViewer.cpp" line="134"/>
        <location filename="../IOViewer.cpp" line="142"/>
        <location filename="../IOViewer.cpp" line="150"/>
        <location filename="../IOViewer.cpp" line="1361"/>
        <location filename="../IOViewer.cpp" line="1402"/>
        <source>Vertical offset</source>
        <translation>Loddrett forskyvning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="154"/>
        <location filename="../IOViewer.cpp" line="159"/>
        <location filename="../IOViewer.cpp" line="164"/>
        <location filename="../IOViewer.cpp" line="169"/>
        <location filename="../IOViewer.cpp" line="174"/>
        <location filename="../IOViewer.cpp" line="183"/>
        <location filename="../IOViewer.cpp" line="192"/>
        <location filename="../IOViewer.cpp" line="197"/>
        <location filename="../IOViewer.cpp" line="202"/>
        <location filename="../IOViewer.cpp" line="207"/>
        <location filename="../IOViewer.cpp" line="212"/>
        <location filename="../IOViewer.cpp" line="221"/>
        <source>Fractional part</source>
        <translation>Brøkdel</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="155"/>
        <location filename="../IOViewer.cpp" line="160"/>
        <location filename="../IOViewer.cpp" line="165"/>
        <location filename="../IOViewer.cpp" line="170"/>
        <location filename="../IOViewer.cpp" line="193"/>
        <location filename="../IOViewer.cpp" line="198"/>
        <location filename="../IOViewer.cpp" line="203"/>
        <location filename="../IOViewer.cpp" line="208"/>
        <source>Integer part</source>
        <translation>Heltallsdel</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="230"/>
        <location filename="../IOViewer.cpp" line="235"/>
        <source>End x</source>
        <translation>Slutt x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="231"/>
        <location filename="../IOViewer.cpp" line="236"/>
        <source>Start x</source>
        <translation>Start x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="240"/>
        <location filename="../IOViewer.cpp" line="245"/>
        <source>End y</source>
        <translation>Slutt y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="241"/>
        <location filename="../IOViewer.cpp" line="246"/>
        <source>Start y</source>
        <translation>Start y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="250"/>
        <source>Window 0 enable BG 0</source>
        <translation>Vindu 0, skru på BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="251"/>
        <source>Window 0 enable BG 1</source>
        <translation>Vindu 0, skru på BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="252"/>
        <source>Window 0 enable BG 2</source>
        <translation>Vindu 0, skru på BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="253"/>
        <source>Window 0 enable BG 3</source>
        <translation>Vindu 0, skru på BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="254"/>
        <source>Window 0 enable OBJ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="255"/>
        <source>Window 0 enable blend</source>
        <translation>Vindu 0, aktiverer blending</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="256"/>
        <source>Window 1 enable BG 0</source>
        <translation>Vindu 1, skru på BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="257"/>
        <source>Window 1 enable BG 1</source>
        <translation>Vindu 1, skru på BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="258"/>
        <source>Window 1 enable BG 2</source>
        <translation>Vindu 1, skru på BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="259"/>
        <source>Window 1 enable BG 3</source>
        <translation>Vindu 1, skru på BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="260"/>
        <source>Window 1 enable OBJ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="261"/>
        <source>Window 1 enable blend</source>
        <translation>Vindu 1, aktiverer blending</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="265"/>
        <source>Outside window enable BG 0</source>
        <translation>Utvendig vindu, skru på BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="266"/>
        <source>Outside window enable BG 1</source>
        <translation>Utvendig vindu, skru på BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="267"/>
        <source>Outside window enable BG 2</source>
        <translation>Utvendig vindu, skru på BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="268"/>
        <source>Outside window enable BG 3</source>
        <translation>Utvendig vindu, skru på BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="269"/>
        <source>Outside window enable OBJ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="270"/>
        <source>Outside window enable blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="271"/>
        <source>OBJ window enable BG 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="272"/>
        <source>OBJ window enable BG 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="273"/>
        <source>OBJ window enable BG 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="274"/>
        <source>OBJ window enable BG 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="275"/>
        <source>OBJ window enable OBJ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="276"/>
        <source>OBJ window enable blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="281"/>
        <source>Background mosaic size vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="280"/>
        <source>Background mosaic size horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="283"/>
        <source>Object mosaic size vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="282"/>
        <source>Object mosaic size horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="66"/>
        <source>Swap green components</source>
        <translation>Bytt om grønne komponenter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="175"/>
        <location filename="../IOViewer.cpp" line="184"/>
        <location filename="../IOViewer.cpp" line="213"/>
        <location filename="../IOViewer.cpp" line="222"/>
        <source>Integer part (low)</source>
        <translation>Heltallsdel (lav)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="179"/>
        <location filename="../IOViewer.cpp" line="188"/>
        <location filename="../IOViewer.cpp" line="217"/>
        <location filename="../IOViewer.cpp" line="226"/>
        <source>Integer part (high)</source>
        <translation>Heltallsdel (høy)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="289"/>
        <source>BG 0 target 1</source>
        <translation>BG 0, mål 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="290"/>
        <source>BG 1 target 1</source>
        <translation>BG 1, mål 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="291"/>
        <source>BG 2 target 1</source>
        <translation>BG 2, mål 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="292"/>
        <source>BG 3 target 1</source>
        <translation>BG 3 ,mål 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="293"/>
        <source>OBJ target 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="294"/>
        <source>Backdrop target 1</source>
        <translation>Bakteppe-mål 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="295"/>
        <source>Blend mode</source>
        <translation>Blendmodus</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="296"/>
        <source>Disabled</source>
        <translation>Avskrudd</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="297"/>
        <source>Additive blending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="298"/>
        <source>Brighten</source>
        <translation>Lysne</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="299"/>
        <source>Darken</source>
        <translation>Formørk</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="301"/>
        <source>BG 0 target 2</source>
        <translation>BG 0, mål 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="302"/>
        <source>BG 1 target 2</source>
        <translation>BG 1, mål 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="303"/>
        <source>BG 2 target 2</source>
        <translation>BG 2, mål 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="304"/>
        <source>BG 3 target 2</source>
        <translation>BG 3, mål 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="305"/>
        <source>OBJ target 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="306"/>
        <source>Backdrop target 2</source>
        <translation>Bakteppe-mål 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="310"/>
        <source>Blend A (target 1)</source>
        <translation>Blend A (mål 1)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="311"/>
        <source>Blend B (target 2)</source>
        <translation>Blend B (mål 2)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="315"/>
        <source>Blend Y</source>
        <translation>Blend Y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="329"/>
        <location filename="../IOViewer.cpp" line="1100"/>
        <source>Sweep shifts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="330"/>
        <location filename="../IOViewer.cpp" line="1101"/>
        <source>Sweep subtract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="331"/>
        <location filename="../IOViewer.cpp" line="1102"/>
        <source>Sweep time (in 1/128s)</source>
        <translation>Sveipetid (i 1/128-dels sek.)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="335"/>
        <location filename="../IOViewer.cpp" line="351"/>
        <location filename="../IOViewer.cpp" line="375"/>
        <location filename="../IOViewer.cpp" line="397"/>
        <location filename="../IOViewer.cpp" line="1106"/>
        <location filename="../IOViewer.cpp" line="1129"/>
        <location filename="../IOViewer.cpp" line="1154"/>
        <location filename="../IOViewer.cpp" line="1179"/>
        <source>Sound length</source>
        <translation>Lydlengde</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="336"/>
        <location filename="../IOViewer.cpp" line="352"/>
        <location filename="../IOViewer.cpp" line="1107"/>
        <location filename="../IOViewer.cpp" line="1130"/>
        <source>Duty cycle</source>
        <translation>Driftssyklus</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="337"/>
        <location filename="../IOViewer.cpp" line="353"/>
        <location filename="../IOViewer.cpp" line="398"/>
        <location filename="../IOViewer.cpp" line="1111"/>
        <location filename="../IOViewer.cpp" line="1134"/>
        <location filename="../IOViewer.cpp" line="1183"/>
        <source>Envelope step time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="338"/>
        <location filename="../IOViewer.cpp" line="354"/>
        <location filename="../IOViewer.cpp" line="399"/>
        <location filename="../IOViewer.cpp" line="1112"/>
        <location filename="../IOViewer.cpp" line="1135"/>
        <location filename="../IOViewer.cpp" line="1184"/>
        <source>Envelope increase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="339"/>
        <location filename="../IOViewer.cpp" line="355"/>
        <location filename="../IOViewer.cpp" line="400"/>
        <location filename="../IOViewer.cpp" line="1113"/>
        <location filename="../IOViewer.cpp" line="1136"/>
        <location filename="../IOViewer.cpp" line="1185"/>
        <source>Initial volume</source>
        <translation>Volum ved begynnelse</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="343"/>
        <location filename="../IOViewer.cpp" line="361"/>
        <location filename="../IOViewer.cpp" line="389"/>
        <source>Sound frequency</source>
        <translation>Lydfrekvens</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="344"/>
        <location filename="../IOViewer.cpp" line="362"/>
        <location filename="../IOViewer.cpp" line="390"/>
        <location filename="../IOViewer.cpp" line="412"/>
        <location filename="../IOViewer.cpp" line="1122"/>
        <location filename="../IOViewer.cpp" line="1145"/>
        <location filename="../IOViewer.cpp" line="1172"/>
        <location filename="../IOViewer.cpp" line="1198"/>
        <source>Timed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="345"/>
        <location filename="../IOViewer.cpp" line="363"/>
        <location filename="../IOViewer.cpp" line="391"/>
        <location filename="../IOViewer.cpp" line="413"/>
        <location filename="../IOViewer.cpp" line="1123"/>
        <location filename="../IOViewer.cpp" line="1146"/>
        <location filename="../IOViewer.cpp" line="1173"/>
        <location filename="../IOViewer.cpp" line="1199"/>
        <source>Reset</source>
        <translation>Tilbakestill</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="369"/>
        <source>Double-size wave table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="370"/>
        <source>Active wave table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="371"/>
        <location filename="../IOViewer.cpp" line="1150"/>
        <source>Enable channel 3</source>
        <translation>Skru på kanal 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="376"/>
        <location filename="../IOViewer.cpp" line="1158"/>
        <source>Volume</source>
        <translation>Lydstyrke</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="377"/>
        <location filename="../IOViewer.cpp" line="1159"/>
        <source>0%</source>
        <translation>0 %</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="378"/>
        <location filename="../IOViewer.cpp" line="435"/>
        <location filename="../IOViewer.cpp" line="1160"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="379"/>
        <location filename="../IOViewer.cpp" line="434"/>
        <location filename="../IOViewer.cpp" line="1161"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="380"/>
        <location filename="../IOViewer.cpp" line="433"/>
        <location filename="../IOViewer.cpp" line="1162"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="381"/>
        <location filename="../IOViewer.cpp" line="382"/>
        <location filename="../IOViewer.cpp" line="383"/>
        <location filename="../IOViewer.cpp" line="384"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="406"/>
        <location filename="../IOViewer.cpp" line="1189"/>
        <source>Clock divider</source>
        <translation>Klokke-oppdeler</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="407"/>
        <location filename="../IOViewer.cpp" line="1190"/>
        <source>Register stages</source>
        <translation>Registrer trinn</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="408"/>
        <location filename="../IOViewer.cpp" line="1191"/>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="409"/>
        <location filename="../IOViewer.cpp" line="1192"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="411"/>
        <location filename="../IOViewer.cpp" line="1194"/>
        <source>Shifter frequency</source>
        <translation>Skifterens frekvens</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="419"/>
        <source>PSG volume right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="420"/>
        <source>PSG volume left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="421"/>
        <location filename="../IOViewer.cpp" line="1210"/>
        <source>Enable channel 1 right</source>
        <translation>Skru på kanal 1 høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="422"/>
        <location filename="../IOViewer.cpp" line="1211"/>
        <source>Enable channel 2 right</source>
        <translation>Skru på kanal 2 høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="423"/>
        <location filename="../IOViewer.cpp" line="1212"/>
        <source>Enable channel 3 right</source>
        <translation>Skru på kanal 3 høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="424"/>
        <location filename="../IOViewer.cpp" line="1213"/>
        <source>Enable channel 4 right</source>
        <translation>Skru på kanal 4 høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="425"/>
        <location filename="../IOViewer.cpp" line="1214"/>
        <source>Enable channel 1 left</source>
        <translation>Skru på kanal 1 venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="426"/>
        <location filename="../IOViewer.cpp" line="1215"/>
        <source>Enable channel 2 left</source>
        <translation>Skru på kanal 2 venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="427"/>
        <location filename="../IOViewer.cpp" line="1216"/>
        <source>Enable channel 3 left</source>
        <translation>Skru på kanal 3 venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="428"/>
        <location filename="../IOViewer.cpp" line="1217"/>
        <source>Enable channel 4 left</source>
        <translation>Skru på kanal 4 venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="432"/>
        <source>PSG master volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="438"/>
        <source>Loud channel A</source>
        <translation>Høykanal A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="439"/>
        <source>Loud channel B</source>
        <translation>Høykanal B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="440"/>
        <source>Enable channel A right</source>
        <translation>Skru på kanal A høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="441"/>
        <source>Enable channel A left</source>
        <translation>Skru på kanal A venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="442"/>
        <source>Channel A timer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="443"/>
        <location filename="../IOViewer.cpp" line="450"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="444"/>
        <location filename="../IOViewer.cpp" line="451"/>
        <location filename="../IOViewer.cpp" line="780"/>
        <location filename="../IOViewer.cpp" line="795"/>
        <location filename="../IOViewer.cpp" line="811"/>
        <location filename="../IOViewer.cpp" line="827"/>
        <location filename="../IOViewer.cpp" line="993"/>
        <location filename="../IOViewer.cpp" line="1003"/>
        <location filename="../IOViewer.cpp" line="1013"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="446"/>
        <source>Channel A reset</source>
        <translation>Kanal A tilbakestill</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="447"/>
        <source>Enable channel B right</source>
        <translation>Skru på kanal B høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="448"/>
        <source>Enable channel B left</source>
        <translation>Skru på kanal B venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="449"/>
        <source>Channel B timer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="453"/>
        <source>Channel B reset</source>
        <translation>Kanal B tilbakestill</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="457"/>
        <location filename="../IOViewer.cpp" line="1221"/>
        <source>Active channel 1</source>
        <translation>Aktiv kanal 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="458"/>
        <location filename="../IOViewer.cpp" line="1222"/>
        <source>Active channel 2</source>
        <translation>Aktiv kanal 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="459"/>
        <location filename="../IOViewer.cpp" line="1223"/>
        <source>Active channel 3</source>
        <translation>Aktiv kanal 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="460"/>
        <location filename="../IOViewer.cpp" line="1224"/>
        <source>Active channel 4</source>
        <translation>Aktiv kanal 4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="461"/>
        <location filename="../IOViewer.cpp" line="1225"/>
        <source>Enable audio</source>
        <translation>Skru på lyd</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="467"/>
        <source>Bias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="468"/>
        <source>Resolution</source>
        <translation>Oppløsning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="478"/>
        <location filename="../IOViewer.cpp" line="479"/>
        <location filename="../IOViewer.cpp" line="480"/>
        <location filename="../IOViewer.cpp" line="481"/>
        <location filename="../IOViewer.cpp" line="485"/>
        <location filename="../IOViewer.cpp" line="486"/>
        <location filename="../IOViewer.cpp" line="487"/>
        <location filename="../IOViewer.cpp" line="488"/>
        <location filename="../IOViewer.cpp" line="492"/>
        <location filename="../IOViewer.cpp" line="493"/>
        <location filename="../IOViewer.cpp" line="494"/>
        <location filename="../IOViewer.cpp" line="495"/>
        <location filename="../IOViewer.cpp" line="499"/>
        <location filename="../IOViewer.cpp" line="500"/>
        <location filename="../IOViewer.cpp" line="501"/>
        <location filename="../IOViewer.cpp" line="502"/>
        <location filename="../IOViewer.cpp" line="506"/>
        <location filename="../IOViewer.cpp" line="507"/>
        <location filename="../IOViewer.cpp" line="508"/>
        <location filename="../IOViewer.cpp" line="509"/>
        <location filename="../IOViewer.cpp" line="513"/>
        <location filename="../IOViewer.cpp" line="514"/>
        <location filename="../IOViewer.cpp" line="515"/>
        <location filename="../IOViewer.cpp" line="516"/>
        <location filename="../IOViewer.cpp" line="520"/>
        <location filename="../IOViewer.cpp" line="521"/>
        <location filename="../IOViewer.cpp" line="522"/>
        <location filename="../IOViewer.cpp" line="523"/>
        <location filename="../IOViewer.cpp" line="527"/>
        <location filename="../IOViewer.cpp" line="528"/>
        <location filename="../IOViewer.cpp" line="529"/>
        <location filename="../IOViewer.cpp" line="530"/>
        <location filename="../IOViewer.cpp" line="534"/>
        <location filename="../IOViewer.cpp" line="535"/>
        <location filename="../IOViewer.cpp" line="539"/>
        <location filename="../IOViewer.cpp" line="540"/>
        <location filename="../IOViewer.cpp" line="544"/>
        <location filename="../IOViewer.cpp" line="545"/>
        <location filename="../IOViewer.cpp" line="549"/>
        <location filename="../IOViewer.cpp" line="550"/>
        <location filename="../IOViewer.cpp" line="1247"/>
        <location filename="../IOViewer.cpp" line="1248"/>
        <location filename="../IOViewer.cpp" line="1252"/>
        <location filename="../IOViewer.cpp" line="1253"/>
        <location filename="../IOViewer.cpp" line="1257"/>
        <location filename="../IOViewer.cpp" line="1258"/>
        <location filename="../IOViewer.cpp" line="1262"/>
        <location filename="../IOViewer.cpp" line="1263"/>
        <location filename="../IOViewer.cpp" line="1267"/>
        <location filename="../IOViewer.cpp" line="1268"/>
        <location filename="../IOViewer.cpp" line="1272"/>
        <location filename="../IOViewer.cpp" line="1273"/>
        <location filename="../IOViewer.cpp" line="1277"/>
        <location filename="../IOViewer.cpp" line="1278"/>
        <location filename="../IOViewer.cpp" line="1282"/>
        <location filename="../IOViewer.cpp" line="1283"/>
        <location filename="../IOViewer.cpp" line="1287"/>
        <location filename="../IOViewer.cpp" line="1288"/>
        <location filename="../IOViewer.cpp" line="1292"/>
        <location filename="../IOViewer.cpp" line="1293"/>
        <location filename="../IOViewer.cpp" line="1297"/>
        <location filename="../IOViewer.cpp" line="1298"/>
        <location filename="../IOViewer.cpp" line="1302"/>
        <location filename="../IOViewer.cpp" line="1303"/>
        <location filename="../IOViewer.cpp" line="1307"/>
        <location filename="../IOViewer.cpp" line="1308"/>
        <location filename="../IOViewer.cpp" line="1312"/>
        <location filename="../IOViewer.cpp" line="1313"/>
        <location filename="../IOViewer.cpp" line="1317"/>
        <location filename="../IOViewer.cpp" line="1318"/>
        <location filename="../IOViewer.cpp" line="1322"/>
        <location filename="../IOViewer.cpp" line="1323"/>
        <source>Sample</source>
        <translation>Sampling</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="562"/>
        <location filename="../IOViewer.cpp" line="570"/>
        <location filename="../IOViewer.cpp" line="607"/>
        <location filename="../IOViewer.cpp" line="615"/>
        <location filename="../IOViewer.cpp" line="652"/>
        <location filename="../IOViewer.cpp" line="660"/>
        <location filename="../IOViewer.cpp" line="697"/>
        <location filename="../IOViewer.cpp" line="705"/>
        <source>Address (low)</source>
        <translation>Adresse (lav)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="566"/>
        <location filename="../IOViewer.cpp" line="574"/>
        <location filename="../IOViewer.cpp" line="611"/>
        <location filename="../IOViewer.cpp" line="619"/>
        <location filename="../IOViewer.cpp" line="656"/>
        <location filename="../IOViewer.cpp" line="664"/>
        <location filename="../IOViewer.cpp" line="701"/>
        <location filename="../IOViewer.cpp" line="709"/>
        <source>Address (high)</source>
        <translation>Adresse (høy)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1035"/>
        <source>Right/A</source>
        <translation>Høyre/A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1036"/>
        <source>Left/B</source>
        <translation>Venstre/B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1037"/>
        <source>Up/Select</source>
        <translation>Opp/Select</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1038"/>
        <source>Down/Start</source>
        <translation>Ned/Start</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1039"/>
        <source>Active D-pad</source>
        <translation>Aktiv D-pad</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1040"/>
        <source>Active face buttons</source>
        <translation>Skru på hovedknappene</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1048"/>
        <source>Internal clock</source>
        <translation>Internklokke</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1049"/>
        <source>32× clocking (CGB only)</source>
        <translation>32× klokking (kun CGB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1050"/>
        <source>Transfer active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1068"/>
        <source>Divider</source>
        <translation>Skillelinje</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1070"/>
        <source>1/16</source>
        <translation>1/16</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1093"/>
        <location filename="../IOViewer.cpp" line="1554"/>
        <source>LCD STAT</source>
        <translation>LCD-status</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1094"/>
        <location filename="../IOViewer.cpp" line="1555"/>
        <source>Timer</source>
        <translation>Tidtaker</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1095"/>
        <location filename="../IOViewer.cpp" line="1556"/>
        <source>Serial</source>
        <translation>Seriell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1096"/>
        <location filename="../IOViewer.cpp" line="1557"/>
        <source>Joypad</source>
        <translation>Kontroller</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1117"/>
        <location filename="../IOViewer.cpp" line="1140"/>
        <location filename="../IOViewer.cpp" line="1167"/>
        <source>Sound frequency (low)</source>
        <translation>Lydfrekvens (lav)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1121"/>
        <location filename="../IOViewer.cpp" line="1144"/>
        <location filename="../IOViewer.cpp" line="1171"/>
        <source>Sound frequency (high)</source>
        <translation>Lydfrekvens (høy)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1203"/>
        <source>Volume right</source>
        <translation>Lydstyrke høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1204"/>
        <source>Output right</source>
        <translation>Utgang høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1205"/>
        <source>Volume left</source>
        <translation>Lydstyrke venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1206"/>
        <source>Output left</source>
        <translation>Utgang venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1327"/>
        <source>Background enable/priority</source>
        <translation>Bakgrunnsaktivering/-prioritet</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1328"/>
        <source>Enable sprites</source>
        <translation>Skru på figurer</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1329"/>
        <source>Double-height sprites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1330"/>
        <source>Background tile map</source>
        <translation>Bakgrunnsflis-kart</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1331"/>
        <location filename="../IOViewer.cpp" line="1340"/>
        <source>0x9800 – 0x9BFF</source>
        <translation>0x9800 – 0x9BFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1332"/>
        <location filename="../IOViewer.cpp" line="1341"/>
        <source>0x9C00 – 0x9FFF</source>
        <translation>0x9C00 – 0x9FFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1334"/>
        <source>Background tile data</source>
        <translation>Bakgrunnsflis-kart</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1335"/>
        <source>0x8800 – 0x87FF</source>
        <translation>0x8800 – 0x87FF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1336"/>
        <source>0x8000 – 0x8FFF</source>
        <translation>0x8000 – 0x8FFF</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1338"/>
        <source>Enable window</source>
        <translation>Aktiver vindu</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1339"/>
        <source>Window tile map</source>
        <translation>Vindusflis-kart</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1343"/>
        <source>Enable LCD</source>
        <translation>Aktiver LCD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1347"/>
        <source>Mode</source>
        <translation>Modus</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1348"/>
        <source>0: HBlank</source>
        <translation>0: HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1349"/>
        <source>1: VBlank</source>
        <translation>1: VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1350"/>
        <source>2: OAM scan</source>
        <translation>2: OAM-skanning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1351"/>
        <source>3: HDraw</source>
        <translation>3: HDraw</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1353"/>
        <source>In LYC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1354"/>
        <source>Enable HBlank (mode 0) IRQ</source>
        <translation>Skru på HBlank (modus 0) IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1355"/>
        <source>Enable VBlank (mode 1) IRQ</source>
        <translation>Skru på VBlank (modus 1) IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1356"/>
        <source>Enable OAM (mode 2) IRQ</source>
        <translation>Skru på OAM (modus 2) IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1357"/>
        <source>Enable LYC IRQ</source>
        <translation>Skru på LYC IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1369"/>
        <source>Current Y coordinate</source>
        <translation>Gjeldende Y-koordinat</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1373"/>
        <source>Comparison Y coordinate</source>
        <translation>Sammenlignings-Y-koordinat</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1377"/>
        <source>Start upper byte</source>
        <translation>Start øvre byte</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1381"/>
        <location filename="../IOViewer.cpp" line="1388"/>
        <location filename="../IOViewer.cpp" line="1395"/>
        <source>Color 0 shade</source>
        <translation>Farge 0 sin skygge</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1382"/>
        <location filename="../IOViewer.cpp" line="1389"/>
        <location filename="../IOViewer.cpp" line="1396"/>
        <source>Color 1 shade</source>
        <translation>Farge 1 sin skygge</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1383"/>
        <location filename="../IOViewer.cpp" line="1390"/>
        <location filename="../IOViewer.cpp" line="1397"/>
        <source>Color 2 shade</source>
        <translation>Farge 2 sin skygge</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1384"/>
        <location filename="../IOViewer.cpp" line="1391"/>
        <location filename="../IOViewer.cpp" line="1398"/>
        <source>Color 3 shade</source>
        <translation>Farge 3 sin skygge</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1412"/>
        <source>Prepare to switch speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1413"/>
        <source>Double speed</source>
        <translation>Dobbel hastighet</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1419"/>
        <source>VRAM bank</source>
        <translation>VRAM-blanking</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1425"/>
        <source>Source (high)</source>
        <translation>Kilde (høy)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1429"/>
        <source>Source (low)</source>
        <translation>Kilde (lav)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1433"/>
        <source>Destination (high)</source>
        <translation>Mål (høy)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1437"/>
        <source>Destination (low)</source>
        <translation>Mål (lav)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1441"/>
        <source>Length</source>
        <translation>Lengde</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1442"/>
        <source>Timing</source>
        <translation>Timing</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1449"/>
        <source>Write bit</source>
        <translation>Skriv bit</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1450"/>
        <source>Read bit</source>
        <translation>Les bit</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1453"/>
        <location filename="../IOViewer.cpp" line="1454"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1494"/>
        <location filename="../IOViewer.cpp" line="1506"/>
        <source>Current index</source>
        <translation>Nåværende indeks</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1495"/>
        <location filename="../IOViewer.cpp" line="1507"/>
        <source>Auto-increment</source>
        <translation>Automatisk økning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1499"/>
        <location filename="../IOViewer.cpp" line="1511"/>
        <source>Red</source>
        <translation>Rød</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1500"/>
        <location filename="../IOViewer.cpp" line="1512"/>
        <source>Green (low)</source>
        <translation>Grønn (lav)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1501"/>
        <location filename="../IOViewer.cpp" line="1513"/>
        <source>Green (high)</source>
        <translation>Grønn (høy)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1502"/>
        <location filename="../IOViewer.cpp" line="1514"/>
        <source>Blue</source>
        <translation>Blå</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1518"/>
        <source>Sprite ordering</source>
        <translation>Figur-sortering</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1519"/>
        <source>OAM order</source>
        <translation>OAM-rekkefølge</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1520"/>
        <source>x coordinate sorting</source>
        <translation>x-koordinatsortering</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1531"/>
        <source>WRAM bank</source>
        <translation>WRAM-bank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="578"/>
        <location filename="../IOViewer.cpp" line="623"/>
        <location filename="../IOViewer.cpp" line="668"/>
        <location filename="../IOViewer.cpp" line="713"/>
        <source>Word count</source>
        <translation>Antall ord</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="582"/>
        <location filename="../IOViewer.cpp" line="627"/>
        <location filename="../IOViewer.cpp" line="672"/>
        <location filename="../IOViewer.cpp" line="717"/>
        <source>Destination offset</source>
        <translation>Mål-forskyvning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="583"/>
        <location filename="../IOViewer.cpp" line="589"/>
        <location filename="../IOViewer.cpp" line="628"/>
        <location filename="../IOViewer.cpp" line="634"/>
        <location filename="../IOViewer.cpp" line="673"/>
        <location filename="../IOViewer.cpp" line="679"/>
        <location filename="../IOViewer.cpp" line="718"/>
        <location filename="../IOViewer.cpp" line="724"/>
        <source>Increment</source>
        <translation>Øk</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="584"/>
        <location filename="../IOViewer.cpp" line="590"/>
        <location filename="../IOViewer.cpp" line="629"/>
        <location filename="../IOViewer.cpp" line="635"/>
        <location filename="../IOViewer.cpp" line="674"/>
        <location filename="../IOViewer.cpp" line="680"/>
        <location filename="../IOViewer.cpp" line="719"/>
        <location filename="../IOViewer.cpp" line="725"/>
        <source>Decrement</source>
        <translation>Reduser</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="585"/>
        <location filename="../IOViewer.cpp" line="591"/>
        <location filename="../IOViewer.cpp" line="630"/>
        <location filename="../IOViewer.cpp" line="636"/>
        <location filename="../IOViewer.cpp" line="675"/>
        <location filename="../IOViewer.cpp" line="681"/>
        <location filename="../IOViewer.cpp" line="720"/>
        <location filename="../IOViewer.cpp" line="726"/>
        <source>Fixed</source>
        <translation>Fastsatt</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="586"/>
        <location filename="../IOViewer.cpp" line="631"/>
        <location filename="../IOViewer.cpp" line="676"/>
        <location filename="../IOViewer.cpp" line="721"/>
        <source>Increment and reload</source>
        <translation>Øk og last inn på nytt</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="588"/>
        <location filename="../IOViewer.cpp" line="633"/>
        <location filename="../IOViewer.cpp" line="678"/>
        <location filename="../IOViewer.cpp" line="723"/>
        <source>Source offset</source>
        <translation>Kilde-forskyvning</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="594"/>
        <location filename="../IOViewer.cpp" line="639"/>
        <location filename="../IOViewer.cpp" line="684"/>
        <location filename="../IOViewer.cpp" line="730"/>
        <source>Repeat</source>
        <translation>Gjentagelse</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="595"/>
        <location filename="../IOViewer.cpp" line="640"/>
        <location filename="../IOViewer.cpp" line="685"/>
        <location filename="../IOViewer.cpp" line="731"/>
        <source>32-bit</source>
        <translation>32-biter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="596"/>
        <location filename="../IOViewer.cpp" line="641"/>
        <location filename="../IOViewer.cpp" line="686"/>
        <location filename="../IOViewer.cpp" line="732"/>
        <source>Start timing</source>
        <translation>Start klokken</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="597"/>
        <location filename="../IOViewer.cpp" line="642"/>
        <location filename="../IOViewer.cpp" line="687"/>
        <location filename="../IOViewer.cpp" line="733"/>
        <location filename="../IOViewer.cpp" line="1443"/>
        <source>Immediate</source>
        <translation>Umiddelbart</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="598"/>
        <location filename="../IOViewer.cpp" line="643"/>
        <location filename="../IOViewer.cpp" line="688"/>
        <location filename="../IOViewer.cpp" line="734"/>
        <location filename="../IOViewer.cpp" line="945"/>
        <location filename="../IOViewer.cpp" line="962"/>
        <location filename="../IOViewer.cpp" line="1092"/>
        <location filename="../IOViewer.cpp" line="1553"/>
        <source>VBlank</source>
        <translation>VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="599"/>
        <location filename="../IOViewer.cpp" line="644"/>
        <location filename="../IOViewer.cpp" line="689"/>
        <location filename="../IOViewer.cpp" line="735"/>
        <location filename="../IOViewer.cpp" line="946"/>
        <location filename="../IOViewer.cpp" line="963"/>
        <location filename="../IOViewer.cpp" line="1444"/>
        <source>HBlank</source>
        <translation>HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="602"/>
        <location filename="../IOViewer.cpp" line="647"/>
        <location filename="../IOViewer.cpp" line="692"/>
        <location filename="../IOViewer.cpp" line="738"/>
        <location filename="../IOViewer.cpp" line="785"/>
        <location filename="../IOViewer.cpp" line="801"/>
        <location filename="../IOViewer.cpp" line="817"/>
        <location filename="../IOViewer.cpp" line="833"/>
        <location filename="../IOViewer.cpp" line="893"/>
        <source>IRQ</source>
        <translation>IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="603"/>
        <location filename="../IOViewer.cpp" line="648"/>
        <location filename="../IOViewer.cpp" line="693"/>
        <location filename="../IOViewer.cpp" line="739"/>
        <location filename="../IOViewer.cpp" line="786"/>
        <location filename="../IOViewer.cpp" line="802"/>
        <location filename="../IOViewer.cpp" line="818"/>
        <location filename="../IOViewer.cpp" line="834"/>
        <location filename="../IOViewer.cpp" line="1074"/>
        <location filename="../IOViewer.cpp" line="1451"/>
        <location filename="../IOViewer.cpp" line="1455"/>
        <source>Enable</source>
        <translation>Skru på</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="645"/>
        <location filename="../IOViewer.cpp" line="690"/>
        <location filename="../IOViewer.cpp" line="736"/>
        <source>Audio FIFO</source>
        <translation>Lyd-FIFO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="727"/>
        <source>Video Capture</source>
        <translation>Videoopptak</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="729"/>
        <source>DRQ</source>
        <translation>DRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="775"/>
        <location filename="../IOViewer.cpp" line="790"/>
        <location filename="../IOViewer.cpp" line="806"/>
        <location filename="../IOViewer.cpp" line="822"/>
        <location filename="../IOViewer.cpp" line="1044"/>
        <location filename="../IOViewer.cpp" line="1056"/>
        <location filename="../IOViewer.cpp" line="1060"/>
        <location filename="../IOViewer.cpp" line="1064"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="779"/>
        <location filename="../IOViewer.cpp" line="794"/>
        <location filename="../IOViewer.cpp" line="810"/>
        <location filename="../IOViewer.cpp" line="826"/>
        <source>Scale</source>
        <translation>Skala</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="781"/>
        <location filename="../IOViewer.cpp" line="796"/>
        <location filename="../IOViewer.cpp" line="812"/>
        <location filename="../IOViewer.cpp" line="828"/>
        <location filename="../IOViewer.cpp" line="1071"/>
        <source>1/64</source>
        <translation>1/64</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="782"/>
        <location filename="../IOViewer.cpp" line="797"/>
        <location filename="../IOViewer.cpp" line="813"/>
        <location filename="../IOViewer.cpp" line="829"/>
        <location filename="../IOViewer.cpp" line="1072"/>
        <source>1/256</source>
        <translation>1/256</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="783"/>
        <location filename="../IOViewer.cpp" line="798"/>
        <location filename="../IOViewer.cpp" line="814"/>
        <location filename="../IOViewer.cpp" line="830"/>
        <location filename="../IOViewer.cpp" line="1069"/>
        <source>1/1024</source>
        <translation>1/1024</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="800"/>
        <location filename="../IOViewer.cpp" line="816"/>
        <location filename="../IOViewer.cpp" line="832"/>
        <source>Cascade</source>
        <translation>Cascade</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="870"/>
        <location filename="../IOViewer.cpp" line="883"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="872"/>
        <location filename="../IOViewer.cpp" line="885"/>
        <source>Select</source>
        <translation>Velg</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="873"/>
        <location filename="../IOViewer.cpp" line="886"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="874"/>
        <location filename="../IOViewer.cpp" line="887"/>
        <source>Right</source>
        <translation>Høyre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="875"/>
        <location filename="../IOViewer.cpp" line="888"/>
        <source>Left</source>
        <translation>Venstre</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="876"/>
        <location filename="../IOViewer.cpp" line="889"/>
        <source>Up</source>
        <translation>Oppover</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="877"/>
        <location filename="../IOViewer.cpp" line="890"/>
        <source>Down</source>
        <translation>Nedover</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="878"/>
        <location filename="../IOViewer.cpp" line="891"/>
        <source>R</source>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="879"/>
        <location filename="../IOViewer.cpp" line="892"/>
        <source>L</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="894"/>
        <source>Condition</source>
        <translation>Tilstand</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="898"/>
        <source>SC</source>
        <translation>SC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="899"/>
        <source>SD</source>
        <translation>SD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="900"/>
        <source>SI</source>
        <translation>SI</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="901"/>
        <source>SO</source>
        <translation>SO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="947"/>
        <location filename="../IOViewer.cpp" line="964"/>
        <source>VCounter</source>
        <translation>VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="948"/>
        <location filename="../IOViewer.cpp" line="965"/>
        <source>Timer 0</source>
        <translation>Tidtaker 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="949"/>
        <location filename="../IOViewer.cpp" line="966"/>
        <source>Timer 1</source>
        <translation>Tidtaker 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="950"/>
        <location filename="../IOViewer.cpp" line="967"/>
        <source>Timer 2</source>
        <translation>Tidtaker 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="951"/>
        <location filename="../IOViewer.cpp" line="968"/>
        <source>Timer 3</source>
        <translation>Tidtaker 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="952"/>
        <location filename="../IOViewer.cpp" line="969"/>
        <source>SIO</source>
        <translation>SIO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="953"/>
        <location filename="../IOViewer.cpp" line="970"/>
        <source>DMA 0</source>
        <translation>DMA 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="954"/>
        <location filename="../IOViewer.cpp" line="971"/>
        <source>DMA 1</source>
        <translation>DMA 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="955"/>
        <location filename="../IOViewer.cpp" line="972"/>
        <source>DMA 2</source>
        <translation>DMA 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="956"/>
        <location filename="../IOViewer.cpp" line="973"/>
        <source>DMA 3</source>
        <translation>DMA 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="957"/>
        <location filename="../IOViewer.cpp" line="974"/>
        <source>Keypad</source>
        <translation>Talltastatur</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="958"/>
        <location filename="../IOViewer.cpp" line="975"/>
        <source>Gamepak</source>
        <translation>Spillkassett</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="979"/>
        <source>SRAM wait</source>
        <translation>SRAM-venting</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="980"/>
        <location filename="../IOViewer.cpp" line="986"/>
        <location filename="../IOViewer.cpp" line="996"/>
        <location filename="../IOViewer.cpp" line="1002"/>
        <location filename="../IOViewer.cpp" line="1006"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="981"/>
        <location filename="../IOViewer.cpp" line="987"/>
        <location filename="../IOViewer.cpp" line="997"/>
        <location filename="../IOViewer.cpp" line="1007"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="982"/>
        <location filename="../IOViewer.cpp" line="988"/>
        <location filename="../IOViewer.cpp" line="992"/>
        <location filename="../IOViewer.cpp" line="998"/>
        <location filename="../IOViewer.cpp" line="1008"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="983"/>
        <location filename="../IOViewer.cpp" line="989"/>
        <location filename="../IOViewer.cpp" line="999"/>
        <location filename="../IOViewer.cpp" line="1009"/>
        <location filename="../IOViewer.cpp" line="1012"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="985"/>
        <source>Cart 0 non-sequential</source>
        <translation>Kassett 0 ikke-sekvensiell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="991"/>
        <source>Cart 0 sequential</source>
        <translation>Kassett 0 sekvensiell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="995"/>
        <source>Cart 1 non-sequential</source>
        <translation>Kassett 1 ikke-sekvensiell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1001"/>
        <source>Cart 1 sequential</source>
        <translation>Kassett 1 sekvensiell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1005"/>
        <source>Cart 2 non-sequential</source>
        <translation>Kassett 2 ikke-sekvensiell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1011"/>
        <source>Cart 2 sequential</source>
        <translation>Kassett 2 sekvensiell</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1015"/>
        <source>PHI terminal</source>
        <translation>PHI-terminal</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1016"/>
        <location filename="../IOViewer.cpp" line="1452"/>
        <source>Disable</source>
        <translation>Skru av</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1017"/>
        <source>4.19MHz</source>
        <translation>4,19MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1018"/>
        <source>8.38MHz</source>
        <translation>8,38MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1019"/>
        <source>16.78MHz</source>
        <translation>16,78MHz</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1021"/>
        <source>Gamepak prefetch</source>
        <translation>Gamepak-forhåndshenting</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1027"/>
        <source>Enable IRQs</source>
        <translation>Skru på IRQ-er</translation>
    </message>
</context>
<context>
    <name>QGBA::InputController</name>
    <message>
        <location filename="../InputController.cpp" line="732"/>
        <location filename="../InputController.cpp" line="753"/>
        <source>Could not find a valid camera format!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../InputController.cpp" line="734"/>
        <source>Camera supported format: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::KeyEditor</name>
    <message>
        <location filename="../KeyEditor.cpp" line="46"/>
        <location filename="../KeyEditor.cpp" line="207"/>
        <source>---</source>
        <translation>---</translation>
    </message>
</context>
<context>
    <name>QGBA::LoadSaveState</name>
    <message>
        <location filename="../LoadSaveState.ui" line="14"/>
        <location filename="../LoadSaveState.ui" line="66"/>
        <source>%1 State</source>
        <translation>%1 tilstand</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="41"/>
        <location filename="../LoadSaveState.ui" line="85"/>
        <location filename="../LoadSaveState.ui" line="107"/>
        <location filename="../LoadSaveState.ui" line="129"/>
        <location filename="../LoadSaveState.ui" line="151"/>
        <location filename="../LoadSaveState.ui" line="173"/>
        <location filename="../LoadSaveState.ui" line="195"/>
        <location filename="../LoadSaveState.ui" line="217"/>
        <location filename="../LoadSaveState.ui" line="239"/>
        <source>No Save</source>
        <translation>Ingen lagrefil</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="50"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="94"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="116"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="138"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="160"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="182"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="204"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="226"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="248"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="261"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="76"/>
        <source>Load State</source>
        <translation>Last inn tilstand</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="76"/>
        <source>Save State</source>
        <translation>Lagre tilstand</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="185"/>
        <source>Empty</source>
        <translation>Tom</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="194"/>
        <source>Corrupted</source>
        <translation>Skadet</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="229"/>
        <source>Slot %1</source>
        <translation>Plass %1</translation>
    </message>
</context>
<context>
    <name>QGBA::LogConfigModel</name>
    <message>
        <location filename="../LogConfigModel.cpp" line="91"/>
        <location filename="../LogConfigModel.cpp" line="112"/>
        <source>Default</source>
        <translation>Forvalg</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="93"/>
        <source>Fatal</source>
        <translation>Kritisk</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="95"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="97"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="99"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="101"/>
        <source>Debug</source>
        <translation>Avlusing</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="103"/>
        <source>Stub</source>
        <translation>Stump</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="105"/>
        <source>Game Error</source>
        <translation>Spillfeil</translation>
    </message>
</context>
<context>
    <name>QGBA::LogController</name>
    <message>
        <location filename="../LogController.cpp" line="110"/>
        <source>[%1] %2: %3</source>
        <translation>[%1] %2: %3</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="121"/>
        <source>An error occurred</source>
        <translation>En feil inntraff</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="193"/>
        <source>DEBUG</source>
        <translation>AVLUSING</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="195"/>
        <source>STUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="197"/>
        <source>INFO</source>
        <translation>INFO</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="199"/>
        <source>WARN</source>
        <translation>ADVARSEL</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="201"/>
        <source>ERROR</source>
        <translation>FEIL</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="203"/>
        <source>FATAL</source>
        <translation>KRITISK</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="205"/>
        <source>GAME ERROR</source>
        <translation>SPILLFEIL</translation>
    </message>
</context>
<context>
    <name>QGBA::LogView</name>
    <message>
        <location filename="../LogView.ui" line="14"/>
        <source>Logs</source>
        <translation>Logger</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="22"/>
        <source>Enabled Levels</source>
        <translation>Påskrudde nivåer</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="28"/>
        <source>Debug</source>
        <translation>Avlusing</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="38"/>
        <source>Stub</source>
        <translation>Stump</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="48"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="58"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="68"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="78"/>
        <source>Fatal</source>
        <translation>Kritisk</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="95"/>
        <source>Game Error</source>
        <translation>Spillfeil</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="108"/>
        <source>Advanced settings</source>
        <translation>Avanserte innstillinger</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="128"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="137"/>
        <source>Max Lines</source>
        <translation>Maks antall linjer</translation>
    </message>
</context>
<context>
    <name>QGBA::MapView</name>
    <message>
        <location filename="../MapView.ui" line="14"/>
        <source>Maps</source>
        <translation>Kart</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="43"/>
        <source>Magnification</source>
        <translation>Forstørrelse</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="124"/>
        <source>Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="139"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="49"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="50"/>
        <location filename="../MapView.cpp" line="63"/>
        <source>Map base</source>
        <translation>Kartgrrunnlag</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="51"/>
        <location filename="../MapView.cpp" line="64"/>
        <source>Tile base</source>
        <translation>Flisgrunnlag</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="52"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="53"/>
        <location filename="../MapView.cpp" line="65"/>
        <source>Offset</source>
        <translation>Forskyvning</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="54"/>
        <source>Xform</source>
        <translation>Xform</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="109"/>
        <source>Map Addr.</source>
        <translation>Kartadresse</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="110"/>
        <source>Mirror</source>
        <translation>Speilvend</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="147"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="149"/>
        <source>Both</source>
        <translation>Begge</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="151"/>
        <source>Horizontal</source>
        <translation>Horisontal</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="153"/>
        <source>Vertical</source>
        <translation>Vertikal</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="184"/>
        <location filename="../MapView.cpp" line="185"/>
        <location filename="../MapView.cpp" line="240"/>
        <source>N/A</source>
        <translation>I/T</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="283"/>
        <source>Export map</source>
        <translation>Eksporter kart</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="284"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogController</name>
    <message>
        <location filename="../MemoryAccessLogController.cpp" line="118"/>
        <location filename="../MemoryAccessLogController.cpp" line="127"/>
        <source>Failed to open memory log file</source>
        <translation>Mislyktes i å åpne minneloggføringsfilen</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogModel</name>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="68"/>
        <source>Data read</source>
        <translation>Data lest</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="70"/>
        <source>Data written</source>
        <translation>Data lagret</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="72"/>
        <source>Code executed</source>
        <translation>Kode kjørt</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="74"/>
        <source>Code aborted</source>
        <translation>Kode avbrutt</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="76"/>
        <source>8-bit access</source>
        <translation>8-bittilgang</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="78"/>
        <source>16-bit access</source>
        <translation>16-bittilgang</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="80"/>
        <source>32-bit access</source>
        <translation>32-bittilgang</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="82"/>
        <source>64-bit access</source>
        <translation>64-bittilgang</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="96"/>
        <source>Accessed by instruction</source>
        <translation>Entret av instruksjon</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="98"/>
        <source>Accessed by DMA</source>
        <translation>Entret av DMS</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="100"/>
        <source>Accessed by BIOS</source>
        <translation>Entret av BIOS</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="102"/>
        <source>Compressed data</source>
        <translation>Komprimerte data</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="104"/>
        <source>Accessed by memory copy</source>
        <translation>Entret av minnekopi</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="106"/>
        <source>(Unknown extra bit 5)</source>
        <translation>(Ukjent ekstra bit 5)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="108"/>
        <source>(Unknown extra bit 6)</source>
        <translation>(Ukjent ekstra bit 6)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="110"/>
        <source>(Unknown extra bit 7)</source>
        <translation>(Ukjent ekstra bit 7)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="112"/>
        <source>Invalid instruction</source>
        <translation>Ugyldig instruksjon</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="114"/>
        <source>Invalid read</source>
        <translation>Ugyldig lesing</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="116"/>
        <source>Invalid write</source>
        <translation>Ugyldig skriving</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="118"/>
        <source>Invalid executable address</source>
        <translation>Ugyldig kjørbar adresse</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="120"/>
        <source>(Private bit 0)</source>
        <translation>(Privat bit 0)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="122"/>
        <source>(Private bit 1)</source>
        <translation>(Privat bit 1)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="126"/>
        <source>ARM code</source>
        <translation>ARM-kode</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="128"/>
        <source>Instruction opcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="130"/>
        <source>(Private bit 2)</source>
        <translation>(Privat bit 2)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="135"/>
        <source>Thumb code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="137"/>
        <source>Instruction operand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="139"/>
        <source>(Private bit 3)</source>
        <translation>(Privat bit 3)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="147"/>
        <source>(Unknown)</source>
        <translation>(Ukjent)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogView</name>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="14"/>
        <source>Memory access logging</source>
        <translation>Loggføring av minnetilgang</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="23"/>
        <source>Log file</source>
        <translation>Loggfil</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="32"/>
        <source>Browse</source>
        <translation>Bla rundt</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="39"/>
        <source>Log additional information (uses 3× space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="46"/>
        <source>Load existing file if present</source>
        <translation>Last inn eksisterende fil hvis den finnes</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="56"/>
        <source>Load</source>
        <translation>Last inn</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="66"/>
        <source>Unload</source>
        <translation>Last ut</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="76"/>
        <source>Regions</source>
        <translation>Regioner</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="87"/>
        <source>Export ROM snapshot</source>
        <translation>Eksporter ROM-øyeblikksbilde</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="94"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="104"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="97"/>
        <location filename="../MemoryAccessLogView.cpp" line="112"/>
        <source>Select access log file</source>
        <translation>Velg tilgangsloggfil</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="97"/>
        <source>Memory access logs (*.mal)</source>
        <translation>Minnetilgangsloggføringer (*.mal)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryDump</name>
    <message>
        <location filename="../MemoryDump.ui" line="14"/>
        <source>Save Memory Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="20"/>
        <source>Start Address:</source>
        <translation>Startadresse:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="76"/>
        <source>Byte Count:</source>
        <translation>Antall byte:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="108"/>
        <source>Dump across banks within region</source>
        <comment>Generate dump with bytes all within the same region of memory, even if it crosses the bank boundary</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="25"/>
        <source>Save memory region</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="31"/>
        <source>Failed to open output file: %1</source>
        <translation>Klarte ikke å åpne utdatafil: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryModel</name>
    <message>
        <location filename="../MemoryModel.cpp" line="46"/>
        <source>Copy selection</source>
        <translation>Kopier utvalg</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="51"/>
        <source>Save selection</source>
        <translation>Lagre utvalg</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="56"/>
        <source>Paste</source>
        <translation>Lim inn</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="61"/>
        <source>Load</source>
        <translation>Last inn</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="119"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="169"/>
        <source>Load TBL</source>
        <translation>Last inn TBL</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="223"/>
        <source>Save selected memory</source>
        <translation>Lagre valgt minne</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="229"/>
        <source>Failed to open output file: %1</source>
        <translation>Klarte ikke å åpne utdatafil: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="237"/>
        <source>Load memory</source>
        <translation>Last inn minne</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="243"/>
        <source>Failed to open input file: %1</source>
        <translation>Klarte ikke å åpne inndatafil: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="358"/>
        <source>ISO-8859-1</source>
        <translation>ISO-8859-1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemorySearch</name>
    <message>
        <location filename="../MemorySearch.ui" line="26"/>
        <source>Memory Search</source>
        <translation>Minnesøk</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="51"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="56"/>
        <source>Current Value</source>
        <translation>Nåværende verdi</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="61"/>
        <location filename="../MemorySearch.ui" line="81"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="71"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="88"/>
        <source>Numeric</source>
        <translation>Numerisk</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="101"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="118"/>
        <source>Width</source>
        <translation>Bredde</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="125"/>
        <location filename="../MemorySearch.ui" line="185"/>
        <source>Guess</source>
        <translation>Gjett</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="138"/>
        <source>1 Byte (8-bit)</source>
        <translation>1 byte (8-bit)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="148"/>
        <source>2 Bytes (16-bit)</source>
        <translation>2 byte (16-bit)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="158"/>
        <source>4 Bytes (32-bit)</source>
        <translation>4 byte (32-bit)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="178"/>
        <source>Number type</source>
        <translation>Nummertype</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="195"/>
        <source>Decimal</source>
        <translation>Desimal</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="202"/>
        <source>Hexadecimal</source>
        <translation>Heksadesimal</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="216"/>
        <source>Search type</source>
        <translation>Søketype</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="223"/>
        <source>Equal to value</source>
        <translation>Lik verdi</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="236"/>
        <source>Greater than value</source>
        <translation>Større enn verdi</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="246"/>
        <source>Less than value</source>
        <translation>Mindre enn verdi</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="256"/>
        <source>Unknown/changed</source>
        <translation>Ukjent/endret</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="269"/>
        <source>Changed by value</source>
        <translation>Endret av verdi</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="282"/>
        <source>Unchanged</source>
        <translation>Uendret</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="295"/>
        <source>Increased</source>
        <translation>Økt</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="308"/>
        <source>Decreased</source>
        <translation>Minket</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="318"/>
        <source>Search ROM</source>
        <translation>Søk etter ROM</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="336"/>
        <source>New Search</source>
        <translation>Nytt søk</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="343"/>
        <source>Search Within</source>
        <translation>Søk i</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="350"/>
        <source>Open in Memory Viewer</source>
        <translation>Åpne i minneviser</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="357"/>
        <source>Refresh</source>
        <translation>Gjenoppfrisk</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="224"/>
        <source> (%0/%1×)</source>
        <translation> (%0/%1×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="226"/>
        <source> (⅟%0×)</source>
        <translation> (⅟%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="229"/>
        <source> (%0×)</source>
        <translation> (%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="233"/>
        <source>%1 byte%2</source>
        <translation>%1 byte%2</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryView</name>
    <message>
        <location filename="../MemoryView.ui" line="14"/>
        <source>Memory</source>
        <translation>Minne</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="192"/>
        <source>String:</source>
        <translation>Streng:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="205"/>
        <source>Load TBL</source>
        <translation>Last inn TBL</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="233"/>
        <source>Copy Selection</source>
        <translation>Kopier utvalg</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="247"/>
        <source>Paste</source>
        <translation>Lim inn</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="240"/>
        <source>Save Selection</source>
        <translation>Lagre utvalg</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="37"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="106"/>
        <source>Alignment:</source>
        <translation>Justering:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="120"/>
        <source>1 Byte</source>
        <translation>1 byte</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="125"/>
        <source>2 Bytes</source>
        <translation>2 byte</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="130"/>
        <source>4 Bytes</source>
        <translation>4 byte</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="152"/>
        <source>Signed:</source>
        <translation>Signert:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="172"/>
        <source>Unsigned:</source>
        <translation>Usignert:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="254"/>
        <source>Save Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="267"/>
        <source>Load</source>
        <translation>Last inn</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="282"/>
        <source>Selected address accesses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="304"/>
        <source>Logging configuration</source>
        <translation>Loggkonfigurasjon</translation>
    </message>
</context>
<context>
    <name>QGBA::MessagePainter</name>
    <message>
        <location filename="../MessagePainter.cpp" line="82"/>
        <source>Frame %1</source>
        <translation>Bilde %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MultiplayerController</name>
    <message>
        <location filename="../MultiplayerController.cpp" line="314"/>
        <source>Couldn&apos;t find available save ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="368"/>
        <source>Trying to detach a multiplayer player that&apos;s not attached</source>
        <translation>Prøver å koble fra en flerspillerspiller som ikke er tilkoblet</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="408"/>
        <source>Clearing invalid save ID</source>
        <translation>Sletter ugyldig lagrings-ID</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="417"/>
        <source>Clearing invalid preferred ID</source>
        <translation>Sletter ugyldig foretrukket ID</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="438"/>
        <source>Trying to get player ID for a multiplayer player that&apos;s not attached</source>
        <translation>Prøver å hente inn spiller-ID-en til en flerspillerspiller som ikke er tilkoblet</translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="452"/>
        <source>Trying to get save ID for a multiplayer player that&apos;s not attached</source>
        <translation>Prøver å hente inn lagrings-ID-en til en flerspillerspiller som ikke er tilkoblet</translation>
    </message>
</context>
<context>
    <name>QGBA::ObjView</name>
    <message>
        <location filename="../ObjView.ui" line="14"/>
        <source>Sprites</source>
        <translation>Figurer</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="72"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="94"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="122"/>
        <source>Magnification</source>
        <translation>Forstørrelse</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="137"/>
        <source>Geometry</source>
        <translation>Geometri</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="145"/>
        <source>Position</source>
        <translation>Posisjon</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="224"/>
        <source>Dimensions</source>
        <translation>Dimensjoner</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="316"/>
        <source>Matrix</source>
        <translation>Matrise</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="389"/>
        <source>Export</source>
        <translation>Eksporter</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="402"/>
        <source>Attributes</source>
        <translation>Attributter</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="410"/>
        <source>Transform</source>
        <translation>Transformer</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="430"/>
        <location filename="../ObjView.cpp" line="182"/>
        <source>Off</source>
        <translation>Av</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="444"/>
        <source>Palette</source>
        <translation>Palett</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="481"/>
        <source>Double Size</source>
        <translation>Dobbel størrelse</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="548"/>
        <location filename="../ObjView.ui" line="561"/>
        <location filename="../ObjView.ui" line="632"/>
        <source>Return, Ctrl+R</source>
        <translation>Return-tast, Ctrl+R</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="522"/>
        <source>Flipped</source>
        <translation>Speilvendt</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="545"/>
        <source>H</source>
        <extracomment>Short for horizontal</extracomment>
        <translation>H</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="558"/>
        <source>V</source>
        <extracomment>Short for vertical</extracomment>
        <translation>V</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="572"/>
        <source>Mode</source>
        <translation>Modus</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="592"/>
        <location filename="../ObjView.cpp" line="191"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="606"/>
        <source>Mosaic</source>
        <translation>Flislagt</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="643"/>
        <source>Enabled</source>
        <translation>Skrudd på</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="677"/>
        <source>Priority</source>
        <translation>Prioritet</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="715"/>
        <source>Tile</source>
        <translation>Flis</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="161"/>
        <location filename="../ObjView.cpp" line="250"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="183"/>
        <location filename="../ObjView.cpp" line="184"/>
        <location filename="../ObjView.cpp" line="185"/>
        <location filename="../ObjView.cpp" line="186"/>
        <location filename="../ObjView.cpp" line="258"/>
        <location filename="../ObjView.cpp" line="259"/>
        <location filename="../ObjView.cpp" line="260"/>
        <location filename="../ObjView.cpp" line="261"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="194"/>
        <source>Trans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="197"/>
        <source>OBJWIN</source>
        <translation>OBJWIN</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="200"/>
        <source>Invalid</source>
        <translation>Ugyldig</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="257"/>
        <location filename="../ObjView.cpp" line="262"/>
        <source>N/A</source>
        <translation>I/T</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="288"/>
        <source>Export sprite</source>
        <translation>Eksporter figur</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="289"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::OverrideView</name>
    <message>
        <location filename="../OverrideView.ui" line="20"/>
        <source>Game Overrides</source>
        <translation>Overstyringer for spill</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="30"/>
        <source>Game Boy Advance</source>
        <translation>Game Boy Advance</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="42"/>
        <location filename="../OverrideView.ui" line="121"/>
        <location filename="../OverrideView.ui" line="241"/>
        <location filename="../OverrideView.ui" line="257"/>
        <source>Autodetect</source>
        <translation>Auto-oppdag</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="55"/>
        <source>Realtime clock</source>
        <translation>Sanntidsklokke</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="65"/>
        <source>Gyroscope</source>
        <translation>Gyroskop</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="75"/>
        <source>Tilt</source>
        <translation>Tilt</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="85"/>
        <source>Light sensor</source>
        <translation>Lyssensor</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="95"/>
        <source>Rumble</source>
        <translation>Vibrasjon</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="113"/>
        <source>Save type</source>
        <translation>Lagringstype</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="126"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="131"/>
        <source>SRAM</source>
        <translation>SRAM</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="136"/>
        <source>Flash 512kb</source>
        <translation>Flash 512kb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="141"/>
        <source>Flash 1Mb</source>
        <translation>Flash 1Mb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="146"/>
        <source>EEPROM 8kB</source>
        <translation>EEPROM 8kB</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="151"/>
        <source>EEPROM 512 bytes</source>
        <translation>EEPROM 512 byte</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="156"/>
        <source>SRAM 64kB (bootlegs only)</source>
        <translation>SRAM 64kB (kun bootleg-spill)</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="164"/>
        <source>Idle loop</source>
        <translation>Tomgangssløyfe</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="190"/>
        <source>Game Boy Player features</source>
        <translation>Game Boy Player-funksjoner</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="197"/>
        <source>VBA bug compatibility mode</source>
        <translation>Kompatibilitetsmodus for VBA-feil</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="227"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="233"/>
        <source>Game Boy model</source>
        <translation>Game Boy-modell</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="249"/>
        <source>Memory bank controller</source>
        <translation>Minnebank-styrer</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="265"/>
        <source>Background Colors</source>
        <translation>Bakgrunnsfarger</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="352"/>
        <source>Sprite Colors 1</source>
        <translation>Figurfarger 1</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="359"/>
        <source>Sprite Colors 2</source>
        <translation>Figurfarger 2</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="529"/>
        <source>Palette preset</source>
        <translation>Forhåndsvalgt fargepalett</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="68"/>
        <source>Official MBCs</source>
        <translation>Offisielle MBC-er</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="72"/>
        <source>Licensed MBCs</source>
        <translation>Lisensierte MBC-er</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="76"/>
        <source>Unlicensed MBCs</source>
        <translation>Ulisensierte MBC-er</translation>
    </message>
</context>
<context>
    <name>QGBA::PaletteView</name>
    <message>
        <location filename="../PaletteView.ui" line="14"/>
        <source>Palette</source>
        <translation>Palett</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="44"/>
        <source>Background</source>
        <translation>Bakgrunn</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="94"/>
        <source>Objects</source>
        <translation>Objekter</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="153"/>
        <source>Selection</source>
        <translation>Utvalg</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="184"/>
        <source>Red</source>
        <translation>Rød</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="191"/>
        <source>Green</source>
        <translation>Grønn</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="198"/>
        <source>Blue</source>
        <translation>Blå</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="253"/>
        <source>16-bit value</source>
        <translation>16-biters verdi</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="260"/>
        <source>Hex code</source>
        <translation>Heksadesimal kode</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="267"/>
        <source>Palette index</source>
        <translation>Palett-indeks</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="340"/>
        <source>Export BG</source>
        <translation>Eksporter BG</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="360"/>
        <source>Export OBJ</source>
        <translation>Eksporter OBJ</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="119"/>
        <source>#%0</source>
        <translation>#%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="120"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="121"/>
        <location filename="../PaletteView.cpp" line="122"/>
        <location filename="../PaletteView.cpp" line="123"/>
        <location filename="../PaletteView.cpp" line="124"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="136"/>
        <source>Export palette</source>
        <translation>Eksporter palett</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="137"/>
        <source>Windows PAL (*.pal);;Adobe Color Table (*.act)</source>
        <translation>Windows PAL (*.pal);;Adobe Color Table (*.act)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="143"/>
        <source>Failed to open output palette file: %1</source>
        <translation>Mislyktes i å åpne utdatapalettfilen: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::PlacementControl</name>
    <message>
        <location filename="../PlacementControl.ui" line="20"/>
        <source>Adjust placement</source>
        <translation>Juster plasseringen</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="26"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="65"/>
        <source>Offset</source>
        <translation>Forskyvning</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="72"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="79"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
</context>
<context>
    <name>QGBA::PrinterView</name>
    <message>
        <location filename="../PrinterView.ui" line="14"/>
        <source>Game Boy Printer</source>
        <translation>Game Boy-skriver</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="130"/>
        <source>Hurry up!</source>
        <translation>Skynd deg!</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="137"/>
        <source>Tear off</source>
        <translation>Riv av</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="180"/>
        <source>Magnification</source>
        <translation>Forstørrelse</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="223"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="60"/>
        <source>Save Printout</source>
        <translation>Lagre utskriften</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="60"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::ROMInfo</name>
    <message>
        <location filename="../ROMInfo.cpp" line="48"/>
        <location filename="../ROMInfo.cpp" line="62"/>
        <location filename="../ROMInfo.cpp" line="70"/>
        <location filename="../ROMInfo.cpp" line="78"/>
        <location filename="../ROMInfo.cpp" line="89"/>
        <location filename="../ROMInfo.cpp" line="102"/>
        <source>(unknown)</source>
        <translation>(ukjent)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="57"/>
        <source> bytes</source>
        <translation> byte</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="92"/>
        <source>(no database present)</source>
        <translation>(ingen database forefinnes)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="14"/>
        <source>ROM Info</source>
        <translation>ROM-info</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="23"/>
        <source>File information</source>
        <translation>Filinformasjon</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="29"/>
        <source>Game name:</source>
        <translation>Spillets navn:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="83"/>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="100"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="134"/>
        <source>ROM header</source>
        <translation>ROM-toppområde</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="140"/>
        <source>Internal name:</source>
        <translation>Internt navn:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="157"/>
        <source>Game ID:</source>
        <translation>Spill-ID:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="174"/>
        <source>Maker Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="191"/>
        <source>Revision:</source>
        <translation>Revisjon:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="49"/>
        <source>File size:</source>
        <translation>Filstørrelse:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="66"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="117"/>
        <source>Save file:</source>
        <translation>Lagrefil:</translation>
    </message>
</context>
<context>
    <name>QGBA::ReportView</name>
    <message>
        <location filename="../ReportView.cpp" line="436"/>
        <source>Bug report archive</source>
        <translation>Feilrapportarkiv</translation>
    </message>
    <message>
        <location filename="../ReportView.cpp" line="436"/>
        <source>ZIP archive (*.zip)</source>
        <translation>ZIP-arkiv (*.zip)</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="14"/>
        <source>Generate Bug Report</source>
        <translation>Opprett en feilrapport</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="67"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To file a bug report, please first generate a report file to attach to the bug report you&apos;re about to file. It is recommended that you include the save files, as these often help with debugging issues. This will collect some information about the version of {projectName} you&apos;re running, your configuration, your computer, and the game you currently have open (if any). Once this collection is completed you can review all of the information gathered below and save it to a zip file. The collection will automatically attempt to redact any personal information, such as your username if it&apos;s in any of the paths gathered, but just in case you can edit it afterwards. After you have generated and saved it, please click the button below or go to &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt; to file the bug report on GitHub. Make sure to attach the report you generated!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="85"/>
        <source>Generate report</source>
        <translation>Generer rapport</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="99"/>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="113"/>
        <source>Open issue list in browser</source>
        <translation>Åpne sakslisten i nettleser</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="134"/>
        <source>Include save file</source>
        <translation>Inkluder lagrefilen</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="150"/>
        <source>Create and include savestate</source>
        <translation>Opprett og inkluder lagringstilstand</translation>
    </message>
</context>
<context>
    <name>QGBA::SaveConverter</name>
    <message>
        <location filename="../SaveConverter.cpp" line="39"/>
        <source>Save games and save states (%1)</source>
        <translation>Lagrefiler og lagringstilstander</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="40"/>
        <source>Select save game or save state</source>
        <translation>Velg lagrefil eller lagringstilstand</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="52"/>
        <source>Save games (%1)</source>
        <translation>Lagrefiler (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="53"/>
        <source>Select save game</source>
        <translation>Velg lagrefil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="74"/>
        <location filename="../SaveConverter.cpp" line="85"/>
        <source>Conversion failed</source>
        <translation>Konvertering mislyktes</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="74"/>
        <source>Failed to convert the save game. This is probably a bug.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="85"/>
        <source>Failed to open output file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="96"/>
        <source>No file selected</source>
        <translation>Ingen fil valgt</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="103"/>
        <source>Could not open file</source>
        <translation>Kunne ikke åpne fil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="118"/>
        <source>No valid formats found</source>
        <translation>Ingen gyldige formater ble funnet</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="126"/>
        <source>Please select a valid input file</source>
        <translation>Velg en gyldig inndatafil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="137"/>
        <source>No valid conversions found</source>
        <translation>Ingen gyldige konverteringer ble funnet</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="666"/>
        <source>Cannot convert save games between platforms</source>
        <translation>Kan ikke konvertere lagrede spill mellom plattformer</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="14"/>
        <source>Convert/Extract Save Game</source>
        <translation>Konverter/Utvinn lagrefil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="20"/>
        <source>Input file</source>
        <translation>Inndatafil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="29"/>
        <location filename="../SaveConverter.ui" line="55"/>
        <source>Browse</source>
        <translation>Bla</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="46"/>
        <source>Output file</source>
        <translation>Utdatafil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="461"/>
        <source>%1 %2 save game</source>
        <translation>%1 %2 lagrefil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="465"/>
        <source>little endian</source>
        <translation>liten endian</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="468"/>
        <source>big endian</source>
        <translation>stor endian</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="479"/>
        <source>SRAM</source>
        <translation>SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="483"/>
        <source>%1 flash</source>
        <translation>%1 flash</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="487"/>
        <source>%1 EEPROM</source>
        <translation>%1 EEPROM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="493"/>
        <source> + RTC</source>
        <translation> + sanntidsklokke</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="502"/>
        <source>%1 SRAM + RTC</source>
        <translation>%1 SRAM + sanntidsklokke</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="504"/>
        <source>%1 SRAM</source>
        <translation>%1 SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="509"/>
        <source>packed MBC2</source>
        <translation>innpakket MBC2</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="511"/>
        <source>unpacked MBC2</source>
        <translation>utpakket MBC2</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="516"/>
        <source>MBC6 flash</source>
        <translation>MBC6-flash</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="518"/>
        <source>MBC6 combined SRAM + flash</source>
        <translation>MBC6 kombinert SRAM + flash</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="520"/>
        <source>MBC6 SRAM</source>
        <translation>MBC6-SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="524"/>
        <source>TAMA5</source>
        <translation>TAMA5</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="536"/>
        <source>%1 (%2)</source>
        <translation>%1 (%2)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="540"/>
        <source>%1 save state with embedded %2 save game</source>
        <translation>%1 lagringstilstand med innebygd %2 lagrefil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="543"/>
        <source>%1 SharkPort %2 save game</source>
        <translation>%1 SharkPort %2 lagrefil</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="546"/>
        <source>%1 GameShark Advance SP %2 save game</source>
        <translation>%1 GameShark Advance SP %2-lagrefil</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingController</name>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="281"/>
        <source>Lua scripts (*.lua)</source>
        <translation>Lua-skripter (*.lua)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="283"/>
        <source>All files (*.*)</source>
        <translation>Alle filer (*.*)</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingTextBuffer</name>
    <message>
        <location filename="../scripting/ScriptingTextBuffer.cpp" line="45"/>
        <source>Untitled buffer</source>
        <translation>Buffer uten navn</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingView</name>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="14"/>
        <source>Scripting</source>
        <translation>Skripting</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="71"/>
        <source>Run</source>
        <translation>Kjør</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="92"/>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="96"/>
        <source>Load recent script</source>
        <translation>Last inn nylig skript</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="108"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="118"/>
        <source>Load script...</source>
        <translation>Last inn skript...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="123"/>
        <source>&amp;Load most recent</source>
        <translation>&amp;Last inn nyeste</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="128"/>
        <source>&amp;Reset</source>
        <translation>&amp;Omstart</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="133"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="138"/>
        <source>Edit autorun scripts...</source>
        <translation>Rediger autokjøringsskripter ...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="143"/>
        <source>Clear console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.cpp" line="67"/>
        <source>Select script to load</source>
        <translation>Velg skript som skal lastes inn</translation>
    </message>
</context>
<context>
    <name>QGBA::SensorView</name>
    <message>
        <location filename="../SensorView.ui" line="20"/>
        <source>Sensors</source>
        <translation>Sensorer</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="31"/>
        <source>Realtime clock</source>
        <translation>Sanntidsklokke</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="50"/>
        <source>Fixed time</source>
        <translation>Fastsatt tid</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="37"/>
        <source>System time</source>
        <translation>Systemtid</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="96"/>
        <source>Start time at</source>
        <translation>Start tiden på</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="60"/>
        <source>Now</source>
        <translation>Nå</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="67"/>
        <source>Offset time</source>
        <translation>Tidsavvik</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="80"/>
        <source> sec</source>
        <translation> sek</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="126"/>
        <source>MM/dd/yy hh:mm:ss AP</source>
        <translation>dd/mm/YYYY hh:mm:ss AP</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="136"/>
        <source>Light sensor</source>
        <translation>Lyssensor</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="142"/>
        <source>Brightness</source>
        <translation>Lysstyrke</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="179"/>
        <source>Tilt sensor</source>
        <translation>Tiltsensor</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="187"/>
        <location filename="../SensorView.ui" line="276"/>
        <source>Set Y</source>
        <translation>Sett Y</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="197"/>
        <location filename="../SensorView.ui" line="286"/>
        <source>Set X</source>
        <translation>Sett X</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="268"/>
        <source>Gyroscope</source>
        <translation>Gyroskop</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="296"/>
        <source>Sensitivity</source>
        <translation>Følsomhet</translation>
    </message>
</context>
<context>
    <name>QGBA::SettingsView</name>
    <message>
        <location filename="../SettingsView.cpp" line="158"/>
        <location filename="../SettingsView.cpp" line="233"/>
        <source>Qt Multimedia</source>
        <translation>Qt Multimedia</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="165"/>
        <source>SDL</source>
        <translation>SDL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="173"/>
        <source>Software (Qt)</source>
        <translation>Programvare (Qt)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1315"/>
        <location filename="../SettingsView.cpp" line="179"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="186"/>
        <source>OpenGL (force version 1.x)</source>
        <translation>OpenGL (tving versjon 1.x)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="219"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="226"/>
        <source>None (Still Image)</source>
        <translation>Ingen (stillbilde)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="335"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="347"/>
        <source>Controllers</source>
        <translation>Kontrollere</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="412"/>
        <source>Shortcuts</source>
        <translation>Snarveier</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="415"/>
        <source>Shaders are not supported when the display driver is not OpenGL.

If it is set to OpenGL and you still see this, your graphics card or drivers may be too old.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="419"/>
        <location filename="../SettingsView.cpp" line="433"/>
        <location filename="../SettingsView.cpp" line="446"/>
        <location filename="../SettingsView.cpp" line="448"/>
        <source>Shaders</source>
        <translation>Skyggeleggere</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="469"/>
        <source>Select BIOS</source>
        <translation>Velg BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="476"/>
        <source>Select directory</source>
        <translation>Velg mappe</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="484"/>
        <source>Select image</source>
        <translation>Velg bilde</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="484"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>Bildefil (*.png *.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="878"/>
        <source>(%1×%2)</source>
        <translation>(%1×%2)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="896"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="901"/>
        <source>Just now</source>
        <translation>Akkurat nå</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="905"/>
        <source>Less than an hour ago</source>
        <translation>Mindre enn én time siden</translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="910"/>
        <source>%n hour(s) ago</source>
        <translation>
            <numerusform>%n time siden</numerusform>
            <numerusform>%n timer siden</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="914"/>
        <source>%n day(s) ago</source>
        <translation>
            <numerusform>%n dag siden</numerusform>
            <numerusform>%n dager siden</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="20"/>
        <source>Settings</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="45"/>
        <source>Audio/Video</source>
        <translation>Lyd/Video</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="50"/>
        <source>Gameplay</source>
        <translation>Spilling</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="55"/>
        <source>Interface</source>
        <translation>Grensesnitt</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="60"/>
        <source>Update</source>
        <translation>Oppdater</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="65"/>
        <source>Emulation</source>
        <translation>Emulering</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="70"/>
        <source>Enhancements</source>
        <translation>Forbedringer</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="75"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="80"/>
        <source>Paths</source>
        <translation>Filbaner</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="85"/>
        <source>Logging</source>
        <translation>Loggføring</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="90"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="111"/>
        <source>Audio driver:</source>
        <translation>Lyddriver:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="128"/>
        <source>Audio buffer:</source>
        <translation>Lydbuffer:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="140"/>
        <location filename="../SettingsView.ui" line="162"/>
        <source>1536</source>
        <translation>1536</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="147"/>
        <source>512</source>
        <translation>512</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="152"/>
        <source>768</source>
        <translation>768</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="157"/>
        <source>1024</source>
        <translation>1024</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="167"/>
        <source>2048</source>
        <translation>2048</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="172"/>
        <source>3072</source>
        <translation>3072</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="177"/>
        <source>4096</source>
        <translation>4096</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="185"/>
        <source>samples</source>
        <translation>datapunkter</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="194"/>
        <source>Sample rate:</source>
        <translation>Datapunktfrekvens:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="206"/>
        <location filename="../SettingsView.ui" line="223"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="213"/>
        <source>22050</source>
        <translation>22050</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="218"/>
        <source>32000</source>
        <translation>32000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="228"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="236"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="245"/>
        <source>Volume:</source>
        <translation>Volum:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="276"/>
        <location filename="../SettingsView.ui" line="316"/>
        <location filename="../SettingsView.ui" line="811"/>
        <location filename="../SettingsView.ui" line="836"/>
        <source>Mute</source>
        <translation>Demp lyd</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="285"/>
        <source>Fast forward volume:</source>
        <translation>Volum ved fremoverspoling:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="325"/>
        <source>Audio in multiplayer:</source>
        <translation>Lyd i flerspiller:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="332"/>
        <source>All windows</source>
        <translation>Alle vinduer</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="345"/>
        <source>Player 1 window only</source>
        <translation>Kun spiller 1 sitt vindu</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="355"/>
        <source>Currently active player window</source>
        <translation>Vinduet til den nåværende aktive spilleren</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="388"/>
        <source>Display driver:</source>
        <translation>Skjermdriver:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="405"/>
        <source>Frameskip:</source>
        <translation>Rammehopp:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="414"/>
        <source>Skip every</source>
        <translation>Hopp over hver</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="424"/>
        <location filename="../SettingsView.ui" line="1199"/>
        <source>frames</source>
        <translation>bilder</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="475"/>
        <source>FPS target:</source>
        <translation>Siktemål for bildefrekvens:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="500"/>
        <source>frames per second</source>
        <translation>bilder per sekund</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="516"/>
        <source>Sync:</source>
        <translation>Synkroniser:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="382"/>
        <location filename="../SettingsView.ui" line="525"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="105"/>
        <location filename="../SettingsView.ui" line="532"/>
        <source>Audio</source>
        <translation>Lyd</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="433"/>
        <source>Lock aspect ratio</source>
        <translation>Lås visningsforhold</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="440"/>
        <source>Force integer scaling</source>
        <translation>Tving frem heltallsskalering</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="454"/>
        <source>Bilinear filtering</source>
        <translation>Bilineær filtrering</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="757"/>
        <source>Show filename instead of ROM name in library view</source>
        <translation>Vis filnavn i stedet for ROM-navn i bibliotekvisningen</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="804"/>
        <location filename="../SettingsView.ui" line="829"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="795"/>
        <source>When inactive:</source>
        <translation>Når den er inaktiv:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="548"/>
        <source>On loading a game:</source>
        <translation>Når det lastes inn et spill:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="555"/>
        <source>Load last state</source>
        <translation>Last inn nyeste tilstand</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="565"/>
        <source>Load cheats</source>
        <translation>Last inn juksekoder</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="599"/>
        <source>Save entered cheats</source>
        <translation>Lagre innskrevne juksekoder</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="820"/>
        <source>When minimized:</source>
        <translation>Når den er minimert:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="959"/>
        <source>Current channel:</source>
        <translation>Nåværende kanal:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="973"/>
        <source>Current version:</source>
        <translation>Nåværende versjon:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="997"/>
        <source>Update channel:</source>
        <translation>Oppdateringskanal:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1007"/>
        <source>Available version:</source>
        <translation>Tilgjengelig versjon:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1014"/>
        <source>(Unknown)</source>
        <translation>(Ukjent)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1024"/>
        <source>Last checked:</source>
        <translation>Sist sjekket:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1045"/>
        <source>Automatically check on start</source>
        <translation>Sjekk automatisk ved oppstart</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1052"/>
        <source>Check now</source>
        <translation>Sjekk nå</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2174"/>
        <source>Default color palette only</source>
        <translation>Kun standard fargepalett</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2167"/>
        <source>SGB color palette if available</source>
        <translation>SGB-fargepalett hvis tilgjengelig</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2181"/>
        <source>GBC color palette if available</source>
        <translation>GBC-fargepalett hvis tilgjengelig</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2188"/>
        <source>SGB (preferred) or GBC color palette if available</source>
        <translation>SGB (foretrukket) eller GBC-fargepalett hvis tilgjengelig</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2200"/>
        <source>Game Boy Camera</source>
        <translation>Game Boy Camera</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2206"/>
        <source>Driver:</source>
        <translation>Driver:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2223"/>
        <source>Source:</source>
        <translation>Kilde:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="509"/>
        <source>Native (59.7275)</source>
        <translation>Systemstandard (59.7275)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="447"/>
        <source>Interframe blending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="709"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="726"/>
        <source>Library:</source>
        <translation>Bibliotek:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="734"/>
        <source>List view</source>
        <translation>Listevisning</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="739"/>
        <source>Tree view</source>
        <translation>Tre-visning</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="747"/>
        <source>Show when no game open</source>
        <translation>Vis når ingen spill er åpne</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="764"/>
        <source>Clear cache</source>
        <translation>Tøm mellomlageret</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="778"/>
        <source>Allow opposing input directions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="785"/>
        <source>Suspend screensaver</source>
        <translation>Forhindre skjermsparer</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="852"/>
        <source>Dynamically update window title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="872"/>
        <source>Show filename instead of ROM name in title bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="889"/>
        <source>Show OSD messages</source>
        <translation>Vis meldinger på skjermen</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="698"/>
        <source>Enable Discord Rich Presence</source>
        <translation>Skru på Discord Rich Presence</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="575"/>
        <source>Edit autorun scripts</source>
        <translation>Rediger autokjøringsskripter</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="589"/>
        <source>Periodically autosave state</source>
        <translation>Periodisk autolagre tilstanden</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="862"/>
        <source>Show FPS in title bar</source>
        <translation>Vis bildefrekvensen i tittellinjen</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="904"/>
        <source>Show frame count in OSD</source>
        <translation>Vis «bilder per sekund»-teller på skjermen</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="911"/>
        <source>Show emulation info on reset</source>
        <translation>Vis emuleringsinfo ved omstart</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="948"/>
        <source>Custom border:</source>
        <translation>Tilpassede kanter:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1066"/>
        <source>Fast forward speed:</source>
        <translation>Hastighet ved fremspoling:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1097"/>
        <location filename="../SettingsView.ui" line="1140"/>
        <source>Unbounded</source>
        <translation>Ubegrenset</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1109"/>
        <source>Fast forward (held) speed:</source>
        <translation>Hastighet for spoling frem (Holdt inn):</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1152"/>
        <source>Autofire interval:</source>
        <translation>Autoklikk-intervall:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1176"/>
        <source>Enable rewind</source>
        <translation>Skru på tilbakespoling</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1183"/>
        <source>Rewind history:</source>
        <translation>Tilbakestillingshistorikk:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1208"/>
        <source>Rewind speed:</source>
        <translation>Tilbakespolingsfart:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1245"/>
        <source>Idle loops:</source>
        <translation>Tomgangssløyfer:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1253"/>
        <source>Run all</source>
        <translation>Kjør alle</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1258"/>
        <source>Remove known</source>
        <translation>Fjern kjente</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1263"/>
        <source>Detect and remove</source>
        <translation>Oppdag og fjern</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1271"/>
        <source>Preload entire ROM into memory</source>
        <translation>Forhåndsinnlast hele ROM-en i minnet</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="616"/>
        <source>Save state extra data:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="633"/>
        <location filename="../SettingsView.ui" line="677"/>
        <source>Save game</source>
        <translation>Lagrefil</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="660"/>
        <source>Load state extra data:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1815"/>
        <source>Models</source>
        <translation>Modeller</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1821"/>
        <source>GB only:</source>
        <translation>Kun GB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1831"/>
        <source>SGB compatible:</source>
        <translation>SGB-kompatibel:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1841"/>
        <source>GBC only:</source>
        <translation>Kun GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1851"/>
        <source>GBC compatible:</source>
        <translation>GBC-kompatibel:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1861"/>
        <source>SGB and GBC compatible:</source>
        <translation>SGB- og GBC-kompatible:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1881"/>
        <source>Game Boy palette</source>
        <translation>Game Boy-fargepalett</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1887"/>
        <source>Preset:</source>
        <translation>Forhåndsinnstilling:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="623"/>
        <location filename="../SettingsView.ui" line="667"/>
        <source>Screenshot</source>
        <translation>Skjermbilde</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="643"/>
        <location filename="../SettingsView.ui" line="684"/>
        <source>Cheat codes</source>
        <translation>Juksekoder</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1281"/>
        <source>Enable Game Boy Player features by default</source>
        <translation>Skru på Game Boy Player-funksjoner som standard</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1288"/>
        <source>Enable VBA bug compatibility in ROM hacks</source>
        <translation>Aktiver VBA-feilkompatibilitet i ROM-hacker</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1302"/>
        <source>Video renderer:</source>
        <translation>Videorenderer:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1310"/>
        <source>Software</source>
        <translation>Programvare</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1323"/>
        <source>OpenGL enhancements</source>
        <translation>OpenGL-forbedringer</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1329"/>
        <source>High-resolution scale:</source>
        <translation>Høyoppløsnings-skalering:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1367"/>
        <source>(240×160)</source>
        <translation>(240×160)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1396"/>
        <source>GB BIOS file:</source>
        <translation>GB BIOS-fil:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="932"/>
        <location filename="../SettingsView.ui" line="1415"/>
        <location filename="../SettingsView.ui" line="1443"/>
        <location filename="../SettingsView.ui" line="1471"/>
        <location filename="../SettingsView.ui" line="1499"/>
        <location filename="../SettingsView.ui" line="1557"/>
        <location filename="../SettingsView.ui" line="1605"/>
        <location filename="../SettingsView.ui" line="1653"/>
        <location filename="../SettingsView.ui" line="1701"/>
        <location filename="../SettingsView.ui" line="1749"/>
        <source>Browse</source>
        <translation>Bla</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1508"/>
        <source>Use BIOS file if found</source>
        <translation>Bruk BIOS-filen hvis den blir funnet</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1518"/>
        <source>Skip BIOS intro</source>
        <translation>Hopp over BIOS-introen</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1480"/>
        <source>GBA BIOS file:</source>
        <translation>GBA-BIOS-fil:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1452"/>
        <source>GBC BIOS file:</source>
        <translation>GBC-BIOS-fil:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1424"/>
        <source>SGB BIOS file:</source>
        <translation>SGB-BIOS-fil:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1532"/>
        <source>Save games</source>
        <translation>Lagrefiler</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1566"/>
        <location filename="../SettingsView.ui" line="1614"/>
        <location filename="../SettingsView.ui" line="1662"/>
        <location filename="../SettingsView.ui" line="1710"/>
        <location filename="../SettingsView.ui" line="1758"/>
        <source>Same directory as the ROM</source>
        <translation>Samme mappe som ROM-en</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1580"/>
        <source>Save states</source>
        <translation>Lagringstilstander</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1628"/>
        <source>Screenshots</source>
        <translation>Skjermklipp</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1676"/>
        <source>Patches</source>
        <translation>Patcher</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1724"/>
        <source>Cheats</source>
        <translation>Juks</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1781"/>
        <source>Log to file</source>
        <translation>Loggfør til en fil</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1788"/>
        <source>Log to console</source>
        <translation>Loggfør til konsollen</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1802"/>
        <source>Select Log File</source>
        <translation>Velg loggfil</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1897"/>
        <source>Default BG colors:</source>
        <translation>Standard BG-farger:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1984"/>
        <source>Default sprite colors 1:</source>
        <translation>Standard figurfarger 1:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2071"/>
        <source>Default sprite colors 2:</source>
        <translation>Standard figurfarger 2:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1871"/>
        <source>Super Game Boy borders</source>
        <translation>Super Game Boy-kanter</translation>
    </message>
</context>
<context>
    <name>QGBA::ShaderSelector</name>
    <message>
        <location filename="../ShaderSelector.cpp" line="78"/>
        <source>No shader active</source>
        <translation>Ingen aktive skyggeleggere</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="92"/>
        <location filename="../ShaderSelector.cpp" line="95"/>
        <source>Load shader</source>
        <translation>Last inn skyggelegger</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="94"/>
        <source>mGBA Shaders</source>
        <translation>mGBA-skyggeleggere</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="125"/>
        <source>Error loading shader</source>
        <translation>Feil under innlasting av skyggelegger</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="125"/>
        <source>The shader &quot;%1&quot; could not be loaded successfully.</source>
        <translation>«%1»-skyggeleggeren kunne ikke bli vellykket lastet inn.</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="147"/>
        <source>No shader loaded</source>
        <translation>Ingen skyggeleggere er lastet inn</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="155"/>
        <source>by %1</source>
        <translation>av %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="166"/>
        <source>Preprocessing</source>
        <translation>Forbehandling</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="173"/>
        <source>Pass %1</source>
        <translation>Passér 1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="14"/>
        <source>Shaders</source>
        <translation>Skygger</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="28"/>
        <source>Active Shader:</source>
        <translation>Aktiv skyggelegger:</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="35"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="45"/>
        <source>Author</source>
        <translation>Skaper</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="62"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="88"/>
        <source>Unload Shader</source>
        <translation>Last ut skyggelegger</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="95"/>
        <source>Load New Shader</source>
        <translation>Last inn ny skyggelegging</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutModel</name>
    <message>
        <location filename="../ShortcutModel.cpp" line="68"/>
        <source>Action</source>
        <translation>Handling</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="70"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="72"/>
        <source>Gamepad</source>
        <translation>Kontroller</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutView</name>
    <message>
        <location filename="../ShortcutView.ui" line="14"/>
        <source>Edit Shortcuts</source>
        <translation>Rediger snarveier</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="32"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="42"/>
        <source>Gamepad</source>
        <translation>Kontroller</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="49"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
</context>
<context>
    <name>QGBA::TileView</name>
    <message>
        <location filename="../TileView.cpp" line="227"/>
        <source>Export tiles</source>
        <translation>Eksporter flis</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="228"/>
        <location filename="../TileView.cpp" line="240"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="239"/>
        <source>Export tile</source>
        <translation>Eksporter flis</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="14"/>
        <source>Tiles</source>
        <translation>Fliser</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="170"/>
        <source>Export Selected</source>
        <translation>Eksporter valgte</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="184"/>
        <source>Export All</source>
        <translation>Eksporter alle</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="40"/>
        <source>256 colors</source>
        <translation>256 farger</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="33"/>
        <source>Palette</source>
        <translation>Palett</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="73"/>
        <source>Magnification</source>
        <translation>Forstørrelse</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="96"/>
        <source>Tiles per row</source>
        <translation>Fliser per rad</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="103"/>
        <source>Fit to window</source>
        <translation>Tilpass til vinduet</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="119"/>
        <source>Displayed tiles</source>
        <translation>Viste fliser</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="125"/>
        <source>Only BG tiles</source>
        <translation>Kun bakgrunnsfliser</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="135"/>
        <source>Only OBJ tiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="145"/>
        <source>Both</source>
        <translation>Begge</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="163"/>
        <source>Copy Selected</source>
        <translation>Kopier valgte</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="177"/>
        <source>Copy All</source>
        <translation>Kopier alle</translation>
    </message>
</context>
<context>
    <name>QGBA::VideoView</name>
    <message>
        <location filename="../VideoView.cpp" line="224"/>
        <source>Failed to open output video file: %1</source>
        <translation>Mislyktes i å åpne utdatavideofilen: %1</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="245"/>
        <source>Native (%0x%1)</source>
        <translation>Standard (%0x%1)</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="260"/>
        <source>Select output file</source>
        <translation>Velg utdatafil</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="20"/>
        <source>Record Video</source>
        <translation>Ta opp video</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="40"/>
        <source>Start</source>
        <translation>Begynn</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="56"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="69"/>
        <source>Select File</source>
        <translation>Velg fil</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="101"/>
        <source>Presets</source>
        <translation>Forhåndsinnstillinger</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="109"/>
        <source>High &amp;Quality</source>
        <translation>Høy &amp;kvalitet</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="119"/>
        <source>&amp;YouTube</source>
        <translation>&amp;YouTube</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="129"/>
        <source>WebM</source>
        <translation>WebM</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="139"/>
        <source>MP4</source>
        <translation>MP4</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="146"/>
        <source>&amp;Lossless</source>
        <translation>&amp;Tapsfri</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="167"/>
        <source>4K</source>
        <translation>4K</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="174"/>
        <source>&amp;1080p</source>
        <translation>&amp;1080p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="184"/>
        <source>&amp;720p</source>
        <translation>&amp;720p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="194"/>
        <source>&amp;480p</source>
        <translation>&amp;480p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="207"/>
        <source>&amp;Native</source>
        <translation>&amp;Standard</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="240"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="375"/>
        <source> Bitrate (kbps)</source>
        <translation> Bitfrekvens (kb/s)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="420"/>
        <source>ABR</source>
        <translation>ABR</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="465"/>
        <source>VBR</source>
        <translation>VBR</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="478"/>
        <source>CRF</source>
        <translation>CRF</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="494"/>
        <source>Dimensions</source>
        <translation>Dimensjoner</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="560"/>
        <source>Lock aspect ratio</source>
        <translation>Lås visningsforhold</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="575"/>
        <source>Show advanced</source>
        <translation>Vis avansert</translation>
    </message>
</context>
<context>
    <name>QGBA::Window</name>
    <message>
        <location filename="../Window.cpp" line="354"/>
        <source>Archives (%1)</source>
        <translation>Arkiv (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="359"/>
        <location filename="../Window.cpp" line="375"/>
        <location filename="../Window.cpp" line="402"/>
        <source>Select ROM</source>
        <translation>Velg ROM</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="393"/>
        <source>Select folder</source>
        <translation>Velg mappe</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="537"/>
        <location filename="../Window.cpp" line="544"/>
        <source>Select save</source>
        <translation>Velg lagrefil</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="449"/>
        <source>Select patch</source>
        <translation>Velg feilfiks</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="449"/>
        <source>Patches (*.ips *.ups *.bps)</source>
        <translation>Feilfikser (*.ips *.ups *.bps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="460"/>
        <source>Select e-Reader dotcode</source>
        <translation>Velg e-Reader-punktkode</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="460"/>
        <source>e-Reader card (*.raw *.bin *.bmp)</source>
        <translation>e-Reader-kort (*.raw *.bin *.bmp)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="530"/>
        <source>Select image</source>
        <translation>Velg bilde</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="530"/>
        <source>Image file (*.png *.gif *.jpg *.jpeg);;All files (*)</source>
        <translation>Bildefil (*.png *.gif *.jpg *.jpeg);;All filer (*)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="544"/>
        <source>GameShark saves (*.sps *.xps)</source>
        <translation>GameShark-lagrefiler (*.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="583"/>
        <source>Select video log</source>
        <translation>Velg videologgføring</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="583"/>
        <source>Video logs (*.mvl)</source>
        <translation>Videologgføringer (*.mvl)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1040"/>
        <source>Crash</source>
        <translation>Krasj</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1041"/>
        <source>The game has crashed with the following error:

%1</source>
        <translation>Spillet har krasjet med følgende feil:

%1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1048"/>
        <source>Couldn&apos;t Start</source>
        <translation>Klarte ikke å starte opp</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1049"/>
        <source>Could not start game.</source>
        <translation>Klarte ikke å starte opp spillet.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1063"/>
        <source>Unimplemented BIOS call</source>
        <translation>Uimplementert BIOS-påkalling</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1064"/>
        <source>This game uses a BIOS call that is not implemented. Please use the official BIOS for best experience.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1086"/>
        <source>Failed to create an appropriate display device, falling back to software display. Games may run slowly, especially with larger windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1187"/>
        <source>Really make portable?</source>
        <translation>Vil du virkelig gjøre den bærbar?</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1188"/>
        <source>This will make the emulator load its configuration from the same directory as the executable. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1200"/>
        <source>Restart needed</source>
        <translation>Gjennomfør omstart</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1201"/>
        <source>Some changes will not take effect until the emulator is restarted.</source>
        <translation>Noen endringer vil ikke tre i kraft før emulatoren startes på nytt.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1252"/>
        <source> -  Player %1 of %2</source>
        <translation> -  Spiller %1 av %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1263"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1265"/>
        <source>%1 - %2 - %3</source>
        <translation>%1 - %2 - %3</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1267"/>
        <source>%1 - %2 (%3 fps) - %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1331"/>
        <source>&amp;File</source>
        <translation>&amp;Fil</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1333"/>
        <source>Load &amp;ROM...</source>
        <translation>Last inn &amp;ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1336"/>
        <source>Load ROM in archive...</source>
        <translation>Last inn arkiv-ROM ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1337"/>
        <source>Add folder to library...</source>
        <translation>Legg til mappe i biblioteket ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="410"/>
        <source>Save games (%1)</source>
        <translation>Lagrefiler (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="411"/>
        <source>Select save game</source>
        <translation>Velg lagrefil</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="419"/>
        <source>mGBA save state files (%1)</source>
        <translation>mGBA-lagringstilstandsfiler (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="421"/>
        <location filename="../Window.cpp" line="426"/>
        <source>Select save state</source>
        <translation>Velg lagringstilstand</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="468"/>
        <source>Select e-Reader card images</source>
        <translation>Velg e-Reader-kortavbildninger</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="468"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>Bildefil (*.png *.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="469"/>
        <source>Conversion finished</source>
        <translation>Konverteringen er fullført</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="510"/>
        <source>%1 of %2 e-Reader cards converted successfully.</source>
        <translation>%1 of %2 e-Reader-kort ble vellykket konvertert.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1341"/>
        <source>Load alternate save game...</source>
        <translation>Last inn alternativ lagrefil ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1344"/>
        <source>Load temporary save game...</source>
        <translation>Last inn midlertidig lagrefil ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1377"/>
        <source>Load &amp;patch...</source>
        <translation>Last inn &amp;patch ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1380"/>
        <source>Boot BIOS</source>
        <translation>Oppstarts-BIOS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1474"/>
        <source>Replace ROM...</source>
        <translation>Bytt ROM....</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1384"/>
        <source>Scan e-Reader dotcodes...</source>
        <translation>Skann e-Reader-punktkoder...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1825"/>
        <source>Convert e-Reader card image to raw...</source>
        <translation>Konverter e-Reader-kortbilde til råfil ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1388"/>
        <source>ROM &amp;info...</source>
        <translation>ROM-&amp;info ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1390"/>
        <source>Recent</source>
        <translation>Nylig</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1790"/>
        <source>Make portable</source>
        <translation>Gjør bærbar</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1393"/>
        <source>&amp;Load state</source>
        <translation>&amp;Last inn tilstand</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1398"/>
        <source>Load state file...</source>
        <translation>Last inn lagringstilstand ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1403"/>
        <source>&amp;Save state</source>
        <translation>&amp;Lagre en tilstand</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1408"/>
        <source>Save state file...</source>
        <translation>Last inn lagringstilstand ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1413"/>
        <source>Quick load</source>
        <translation>Hurtiginnlasting</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1414"/>
        <source>Quick save</source>
        <translation>Hurtiglagring</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1416"/>
        <source>Load recent</source>
        <translation>Last inn nylig</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1421"/>
        <source>Save recent</source>
        <translation>Lagre nylig</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1429"/>
        <source>Undo load state</source>
        <translation>Angre åpning av lagringstilstand</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1432"/>
        <source>Undo save state</source>
        <translation>Angre lagring av lagringstilstand</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1439"/>
        <location filename="../Window.cpp" line="1444"/>
        <source>State &amp;%1</source>
        <translation>Tilstand &amp;%1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1570"/>
        <source>Load camera image...</source>
        <translation>Last inn kamerabilde ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1350"/>
        <source>Convert save game...</source>
        <translation>Konverter lagrefil ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="537"/>
        <source>GameShark saves (*.gsv *.sps *.xps)</source>
        <translation>GameShark-lagrefiler (*.gsv *.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1159"/>
        <source>Failed to start audio processor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1212"/>
        <source>Reset needed</source>
        <translation>Tilbakestilling kreves</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1213"/>
        <source>Some changes will not take effect until the game is reset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1340"/>
        <source>Save games</source>
        <translation>Lagrefiler</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1353"/>
        <source>Import GameShark Save...</source>
        <translation>Importer GameShark-lagrefil ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1356"/>
        <source>Export GameShark Save...</source>
        <translation>Eksporter GameShark-lagrefil ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1363"/>
        <source>Automatically determine</source>
        <translation>Bestem automatisk</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1367"/>
        <source>Use player %0 save game</source>
        <translation>Bruk spiller %0 sin lagrefil</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1451"/>
        <source>New multiplayer window</source>
        <translation>Nytt flerspillervindu</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1454"/>
        <source>Connect to Dolphin...</source>
        <translation>Koble til Dolphin...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1460"/>
        <source>Report bug...</source>
        <translation>Rapporter inn feil...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1466"/>
        <source>About...</source>
        <translation>Om …</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1467"/>
        <source>E&amp;xit</source>
        <translation>A&amp;vslutt</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1469"/>
        <source>&amp;Emulation</source>
        <translation>&amp;Emulering</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1470"/>
        <source>&amp;Reset</source>
        <translation>&amp;Omstart</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1471"/>
        <source>Sh&amp;utdown</source>
        <translation>Skr&amp;u av</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1475"/>
        <source>Yank game pak</source>
        <translation>Dra ut spillkassetten</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1478"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pause</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1487"/>
        <source>&amp;Next frame</source>
        <translation>&amp;Neste ramme</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1491"/>
        <source>Fast forward (held)</source>
        <translation>Spoling frem (Holdt inn)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1497"/>
        <source>&amp;Fast forward</source>
        <translation>&amp;Spoling frem</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1501"/>
        <source>Fast forward speed</source>
        <translation>Hastighet ved fremspoling</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1506"/>
        <source>Unbounded</source>
        <translation>Ubegrenset</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1510"/>
        <source>%0x</source>
        <translation>%0x</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1514"/>
        <source>Increase fast forward speed</source>
        <translation>Øk hastigheten for spoling frem</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1521"/>
        <source>Decrease fast forward speed</source>
        <translation>Reduser hastigheten for spoling frem</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1528"/>
        <source>Rewind (held)</source>
        <translation>Spol tilbake (holdt)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1540"/>
        <source>Re&amp;wind</source>
        <translation>Spol ti&amp;lbake</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1545"/>
        <source>Step backwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1552"/>
        <source>Solar sensor</source>
        <translation>Solsensor</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1553"/>
        <source>Increase solar level</source>
        <translation>Øke solnivået</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1554"/>
        <source>Decrease solar level</source>
        <translation>Reduser solnivået</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1555"/>
        <source>Brightest solar level</source>
        <translation>Lyseste solnivå</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1558"/>
        <source>Darkest solar level</source>
        <translation>Mørkeste solnivå</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1564"/>
        <source>Brightness %1</source>
        <translation>Lysstyrke %1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1572"/>
        <source>Game Boy Printer...</source>
        <translation>Game Boy Printer...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1581"/>
        <source>BattleChip Gate...</source>
        <translation>BattleChip Gate ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1585"/>
        <source>Audio/&amp;Video</source>
        <translation>Lyd/&amp;Video</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1586"/>
        <source>Frame size</source>
        <translation>Rammestørrelse</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1588"/>
        <source>%1×</source>
        <translation>%1×</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1629"/>
        <source>Toggle fullscreen</source>
        <translation>Skru på/av fullskjerm</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1632"/>
        <source>&amp;Lock frame size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1645"/>
        <source>Lock aspect ratio</source>
        <translation>Lås visningsforhold</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1657"/>
        <source>Force integer scaling</source>
        <translation>Tving frem heltallsskalering</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1669"/>
        <source>Interframe blending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1678"/>
        <source>Bilinear filtering</source>
        <translation>Bilineær filtrering</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1686"/>
        <source>Frame&amp;skip</source>
        <translation>Ramme&amp;hopp</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1699"/>
        <source>Mute</source>
        <translation>Demp lyd</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1706"/>
        <source>FPS target</source>
        <translation>FPS-mål</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1714"/>
        <source>Native (59.7275)</source>
        <translation>Systemstandard (59.7275)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1729"/>
        <source>Take &amp;screenshot</source>
        <translation>Ta &amp;skjermbilde</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1731"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1735"/>
        <source>Record A/V...</source>
        <translation>Ta opp A/V ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1736"/>
        <source>Record GIF/WebP/APNG...</source>
        <translation>Ta opp GIF/WebP/APNG ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1740"/>
        <source>Video layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1741"/>
        <source>Audio channels</source>
        <translation>Lydkanaler</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1743"/>
        <source>Adjust layer placement...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1747"/>
        <source>Hide &amp;menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1752"/>
        <source>&amp;Tools</source>
        <translation>Verk&amp;tøy</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1753"/>
        <source>View &amp;logs...</source>
        <translation>Vis &amp;loggføringer ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1755"/>
        <source>Game &amp;overrides...</source>
        <translation>Spilloverstyringer ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1768"/>
        <source>Game Pak sensors...</source>
        <translation>Game Pak-sensorer ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1781"/>
        <source>&amp;Cheats...</source>
        <translation>&amp;Juksekoder ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1786"/>
        <source>Create forwarder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1789"/>
        <source>Settings...</source>
        <translation>Innstillinger…</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1794"/>
        <source>Open debugger console...</source>
        <translation>Åpne feilsøkingskonsoll ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1796"/>
        <source>Start &amp;GDB server...</source>
        <translation>Start &amp;GDB-tjener ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1783"/>
        <source>Scripting...</source>
        <translation>Skripting ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1804"/>
        <source>Game state views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1805"/>
        <source>View &amp;palette...</source>
        <translation>Vis &amp;palett ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1806"/>
        <source>View &amp;sprites...</source>
        <translation>Vis &amp;figurer ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1807"/>
        <source>View &amp;tiles...</source>
        <translation>Vis &amp;fliser...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1808"/>
        <source>View &amp;map...</source>
        <translation>Vis &amp;kart …</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1809"/>
        <source>&amp;Frame inspector...</source>
        <translation>&amp;Rammeinspektør ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1810"/>
        <source>View memory...</source>
        <translation>Vis minne ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1811"/>
        <source>Search memory...</source>
        <translation>Søk i minne ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1812"/>
        <source>View &amp;I/O registers...</source>
        <translation>Vis &amp;I/O-registre ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1815"/>
        <source>Log memory &amp;accesses...</source>
        <translation>Loggfør minnetilg&amp;anger ...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1829"/>
        <source>Record debug video log...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1830"/>
        <source>Stop debug video log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1834"/>
        <source>Exit fullscreen</source>
        <translation>Gå ut av fullskjerm</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1836"/>
        <source>GameShark Button (held)</source>
        <translation>GameShark-knapp (Holdt inn)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1842"/>
        <source>Autofire</source>
        <translation>Autoklikk</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1843"/>
        <source>Autofire A</source>
        <translation>Autoklikk A</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1848"/>
        <source>Autofire B</source>
        <translation>Autoklikk B</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1853"/>
        <source>Autofire L</source>
        <translation>Autoklikk L</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1858"/>
        <source>Autofire R</source>
        <translation>Autoklikk R</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1863"/>
        <source>Autofire Start</source>
        <translation>Autoklikk Start</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1868"/>
        <source>Autofire Select</source>
        <translation>Autoklikk Select</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1873"/>
        <source>Autofire Up</source>
        <translation>Autoklikk opp</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1878"/>
        <source>Autofire Right</source>
        <translation>Autoklikk høyre</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1883"/>
        <source>Autofire Down</source>
        <translation>Autoklikk ned</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1888"/>
        <source>Autofire Left</source>
        <translation>Autoklikk venstre</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="2093"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../utils.cpp" line="26"/>
        <source>%1 byte</source>
        <translation>%1 byte</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="29"/>
        <source>%1 kiB</source>
        <translation>%1 kiB</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="33"/>
        <source>%1 MiB</source>
        <translation>%1 MiB</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="183"/>
        <source>Super (L)</source>
        <translation>Super (L)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="185"/>
        <source>Super (R)</source>
        <translation>Super (R)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="187"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../utils.cpp" line="174"/>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="176"/>
        <source>Control</source>
        <translation>Kontroll</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="178"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="180"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
</context>
</TS>
