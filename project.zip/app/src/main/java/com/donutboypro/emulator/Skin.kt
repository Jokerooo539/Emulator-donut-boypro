package com.donutboypro.emulator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

/** Describes a controller theme. Colours are ARGB ints. */
class SkinSpec(
    val id: String,
    val name: String,
    val author: String,
    val backgroundColor: Int,
    val buttonColor: Int,
    val pressedColor: Int,
    val textColor: Int,
    val backgroundPortrait: String?,
    val backgroundLandscape: String?,
    val images: Map<String, String>,
    val builtIn: Boolean
)

/** A skin with its images decoded and ready to draw. */
class LoadedSkin(
    val spec: SkinSpec,
    val backgroundPortrait: Bitmap?,
    val backgroundLandscape: Bitmap?,
    val images: Map<String, Bitmap>
)

/**
 * Skin format (a .zip containing skin.json plus optional PNG/JPG/WEBP files):
 *
 * {
 *   "name": "My skin", "author": "me",
 *   "backgroundColor": "#101820", "buttonColor": "#66FFFFFF", "pressedColor": "#CCFFFFFF", "textColor": "#FFFFFF",
 *   "backgroundPortrait": "bg_portrait.png", "backgroundLandscape": "bg_landscape.png",
 *   "images": { "a": "a.png", "a_pressed": "a_down.png", "b": "b.png", "l": "l.png", "r": "r.png",
 *               "start": "start.png", "select": "select.png", "dpad": "dpad.png",
 *               "turbo_a": "...", "turbo_b": "...", "macro": "..." }
 * }
 */
object SkinStore {
    const val DEFAULT_ID = "builtin:classic"
    private const val MAX_FILE_BYTES = 8 * 1024 * 1024
    private const val MAX_TOTAL_BYTES = 40 * 1024 * 1024
    private val ALLOWED_EXT = listOf(".png", ".jpg", ".jpeg", ".webp", ".json")

    private fun builtIn(id: String, name: String, bg: Long, button: Long, pressed: Long, text: Long) = SkinSpec(
        "builtin:$id", name, "Donut Boy Pro", bg.toInt(), button.toInt(), pressed.toInt(), text.toInt(),
        null, null, emptyMap(), true
    )

    val builtIns: List<SkinSpec> = listOf(
        builtIn("classic", "Classic dark", 0xFF000000, 0x55FFFFFF, 0xAAFFFFFF, 0xFFFFFFFF),
        builtIn("donut", "Pink donut", 0xFF2B1020, 0xAAFF8FB8, 0xFFFFC2DA, 0xFF3A0F24),
        builtIn("midnight", "Midnight blue", 0xFF0A0F1F, 0x6646C2FF, 0xCC9FE3FF, 0xFFFFFFFF),
        builtIn("purple", "Retro purple", 0xFF241A52, 0xAA8E7CFF, 0xFFC9BEFF, 0xFFFFFFFF),
        builtIn("mint", "Mint", 0xFF0B1F1A, 0x8872E0C2, 0xFFB5F5E3, 0xFF06231B),
        builtIn("light", "Light", 0xFFE9E9EF, 0x66000000, 0xAA000000, 0xFF111111)
    )

    private fun root(context: Context) = File(context.filesDir, "skins").apply { mkdirs() }

    fun installed(context: Context): List<SkinSpec> {
        val out = mutableListOf<SkinSpec>()
        root(context).listFiles()?.forEach { dir ->
            if (dir.isDirectory && !dir.name.startsWith(".")) {
                val json = File(dir, "skin.json")
                if (json.exists()) {
                    runCatching { parse(json.readText(), "user:${dir.name}", false) }.getOrNull()?.let { out.add(it) }
                }
            }
        }
        return out.sortedBy { it.name.lowercase() }
    }

    fun all(context: Context): List<SkinSpec> = builtIns + installed(context)

    fun find(context: Context, id: String): SkinSpec =
        all(context).firstOrNull { it.id == id } ?: builtIns.first()

    private fun color(o: JSONObject, key: String, fallback: Int): Int =
        runCatching { Color.parseColor(o.getString(key)) }.getOrDefault(fallback)

    private fun parse(text: String, id: String, builtIn: Boolean): SkinSpec {
        val o = JSONObject(text)
        val images = mutableMapOf<String, String>()
        o.optJSONObject("images")?.let { img ->
            val keys = img.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                images[k] = img.getString(k)
            }
        }
        return SkinSpec(
            id = id,
            name = o.optString("name", "Unnamed skin").take(40),
            author = o.optString("author", "").take(40),
            backgroundColor = color(o, "backgroundColor", 0xFF000000.toInt()),
            buttonColor = color(o, "buttonColor", 0x55FFFFFF),
            pressedColor = color(o, "pressedColor", 0xAAFFFFFF.toInt()),
            textColor = color(o, "textColor", 0xFFFFFFFF.toInt()),
            backgroundPortrait = o.optString("backgroundPortrait", "").ifBlank { null },
            backgroundLandscape = o.optString("backgroundLandscape", "").ifBlank { null },
            images = images,
            builtIn = builtIn
        )
    }

    private fun decode(file: File, maxSide: Int): Bitmap? {
        if (!file.exists()) return null
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        }.getOrNull()
    }

    /** Decodes a skin's images. Falls back to the classic skin if it is missing or broken. */
    fun load(context: Context, id: String): LoadedSkin {
        val spec = find(context, id)
        if (spec.builtIn) return LoadedSkin(spec, null, null, emptyMap())
        val dir = File(root(context), id.removePrefix("user:"))
        val images = mutableMapOf<String, Bitmap>()
        spec.images.forEach { (key, name) ->
            decode(File(dir, safeName(name)), 512)?.let { images[key] = it }
        }
        return LoadedSkin(
            spec,
            spec.backgroundPortrait?.let { decode(File(dir, safeName(it)), 2048) },
            spec.backgroundLandscape?.let { decode(File(dir, safeName(it)), 2048) },
            images
        )
    }

    private fun safeName(name: String) = name.substringAfterLast('/').substringAfterLast('\\')

    /** Imports a skin .zip. Returns null on success or a human-readable error. */
    fun importZip(context: Context, uri: Uri): String? {
        val files = mutableMapOf<String, ByteArray>()
        var total = 0
        try {
            val input = context.contentResolver.openInputStream(uri) ?: return "Could not read that file."
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory) continue
                    val name = safeName(entry.name)         // flatten folders and block "../" tricks
                    if (name.isBlank() || name.startsWith(".")) continue
                    if (ALLOWED_EXT.none { name.endsWith(it, ignoreCase = true) }) continue
                    val buffer = ByteArrayOutputStream()
                    val chunk = ByteArray(16 * 1024)
                    var size = 0
                    while (true) {
                        val n = zip.read(chunk)
                        if (n < 0) break
                        size += n
                        total += n
                        if (size > MAX_FILE_BYTES || total > MAX_TOTAL_BYTES) return "That skin is too large."
                        buffer.write(chunk, 0, n)
                    }
                    files[name] = buffer.toByteArray()
                }
            }
        } catch (t: Throwable) {
            return "That is not a valid zip file."
        }
        val jsonBytes = files["skin.json"] ?: return "The zip has no skin.json file."
        val spec = try {
            parse(String(jsonBytes, Charsets.UTF_8), "user:tmp", false)
        } catch (t: Throwable) {
            return "skin.json is not valid JSON."
        }
        val missing = (spec.images.values + listOfNotNull(spec.backgroundPortrait, spec.backgroundLandscape))
            .map { safeName(it) }.firstOrNull { !files.containsKey(it) }
        if (missing != null) return "skin.json refers to a missing file: $missing"

        val folder = spec.name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "skin" } +
            "-" + Integer.toHexString(jsonBytes.contentHashCode() and 0xFFFFFF)
        val target = File(root(context), folder)
        target.deleteRecursively()
        target.mkdirs()
        files.forEach { (name, bytes) -> File(target, name).writeBytes(bytes) }
        return null
    }

    fun delete(context: Context, spec: SkinSpec) {
        if (!spec.builtIn) File(root(context), spec.id.removePrefix("user:")).deleteRecursively()
    }
}
