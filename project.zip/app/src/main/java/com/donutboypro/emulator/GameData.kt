package com.donutboypro.emulator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Per-game settings. Video / control / sensor options changed while a game is running are remembered
 * for that game only; everything else keeps following the global settings.
 */
object GameOverrides {
    private fun file(dir: File) = File(dir, "settings.json")

    fun apply(base: AppSettings, dir: File): AppSettings {
        val f = file(dir)
        if (!f.exists()) return base
        return runCatching {
            val o = JSONObject(f.readText())
            base.copy(
                linearFilter = o.optBoolean("linearFilter", base.linearFilter),
                integerScale = o.optBoolean("integerScale", base.integerScale),
                screenEffect = o.optInt("screenEffect", base.screenEffect),
                controlsOpacity = o.optDouble("controlsOpacity", base.controlsOpacity.toDouble()).toFloat(),
                controlsScale = o.optDouble("controlsScale", base.controlsScale.toDouble()).toFloat(),
                fastForwardSpeed = o.optInt("fastForwardSpeed", base.fastForwardSpeed),
                solarLevel = o.optInt("solarLevel", base.solarLevel),
                motionSensitivity = o.optDouble("motionSensitivity", base.motionSensitivity.toDouble()).toFloat(),
                skinId = o.optString("skinId", base.skinId)
            )
        }.getOrDefault(base)
    }

    fun save(dir: File, s: AppSettings) {
        val o = JSONObject()
            .put("linearFilter", s.linearFilter)
            .put("integerScale", s.integerScale)
            .put("screenEffect", s.screenEffect)
            .put("controlsOpacity", s.controlsOpacity.toDouble())
            .put("controlsScale", s.controlsScale.toDouble())
            .put("fastForwardSpeed", s.fastForwardSpeed)
            .put("solarLevel", s.solarLevel)
            .put("motionSensitivity", s.motionSensitivity.toDouble())
            .put("skinId", s.skinId)
        runCatching { file(dir).writeText(o.toString()) }
    }

    fun clear(dir: File) { file(dir).delete() }
    fun exists(dir: File) = file(dir).exists()
}

/** Box art: pick an image from the gallery, or it is taken automatically from your last frame of play. */
object CoverStore {
    private const val MAX_WIDTH = 480

    private fun key(game: Game) = Integer.toUnsignedString(game.uri.toString().hashCode(), 16)

    private fun file(context: Context, game: Game): File {
        val dir = File(context.filesDir, "covers").apply { mkdirs() }
        return File(dir, key(game) + ".jpg")
    }

    fun exists(context: Context, game: Game) = file(context, game).exists()

    fun load(context: Context, game: Game): Bitmap? {
        val f = file(context, game)
        return if (f.exists()) runCatching { BitmapFactory.decodeFile(f.absolutePath) }.getOrNull() else null
    }

    fun setFromUri(context: Context, game: Game, uri: Uri): Boolean = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= MAX_WIDTH) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false
        save(context, game, bmp)
        true
    }.getOrDefault(false)

    fun setFromBitmap(context: Context, game: Game, bmp: Bitmap) {
        val scaled = Bitmap.createScaledBitmap(bmp, bmp.width * 2, bmp.height * 2, false)
        save(context, game, scaled)
    }

    fun remove(context: Context, game: Game) { file(context, game).delete() }

    private fun save(context: Context, game: Game, bmp: Bitmap) {
        FileOutputStream(file(context, game)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    }
}

/** Where the user's own GBA BIOS file is kept (copied there from the picker). */
object BiosStore {
    fun file(context: Context) = File(context.filesDir, "bios.gba")
    fun exists(context: Context) = file(context).let { it.exists() && it.length() == 16384L }

    /** A real GBA BIOS is exactly 16 KiB. */
    fun import(context: Context, uri: Uri): Boolean = runCatching {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (bytes.size != 16384) return false
        file(context).writeBytes(bytes)
        true
    }.getOrDefault(false)

    fun remove(context: Context) { file(context).delete() }
}
