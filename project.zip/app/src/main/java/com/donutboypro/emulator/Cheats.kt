package com.donutboypro.emulator

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Cheat(val name: String, val code: String, val enabled: Boolean)

object CheatStore {
    private fun file(dir: File) = File(dir, "cheats.json")

    fun load(dir: File): MutableList<Cheat> {
        val f = file(dir)
        val list = mutableListOf<Cheat>()
        if (!f.exists()) return list
        runCatching {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Cheat(o.optString("n", "Cheat"), o.optString("c", ""), o.optBoolean("e", true)))
            }
        }
        return list
    }

    fun save(dir: File, cheats: List<Cheat>) {
        val arr = JSONArray()
        cheats.forEach { arr.put(JSONObject().put("n", it.name).put("c", it.code).put("e", it.enabled)) }
        runCatching { file(dir).writeText(arr.toString()) }
    }

    /**
     * Turns pasted GameShark / Action Replay / CodeBreaker text into one "XXXXXXXX XXXXXXXX" pair per line.
     * Accepts spaces, newlines and '+' (libretro .cht style) as separators.
     */
    fun normalize(raw: String): String {
        val tokens = raw.trim().split(Regex("[+\\s]+")).filter { it.isNotEmpty() }
        val lines = mutableListOf<String>()
        var i = 0
        while (i < tokens.size) {
            val a = tokens[i]
            if (a.length == 8 && i + 1 < tokens.size) {
                lines.add("$a ${tokens[i + 1]}")
                i += 2
            } else {
                i += 1
            }
        }
        return lines.joinToString("\n")
    }

    /** Parses libretro / My Boy! style ".cht" files (cheatN_desc, cheatN_code, cheatN_enable). */
    fun parseCht(text: String): List<Cheat> {
        val re = Regex("^\\s*cheat(\\d+)_(desc|code|enable)\\s*=\\s*\"?(.*?)\"?\\s*$")
        val descs = sortedMapOf<Int, String>()
        val codes = mutableMapOf<Int, String>()
        val enables = mutableMapOf<Int, Boolean>()
        text.lineSequence().forEach { line ->
            val m = re.find(line) ?: return@forEach
            val index = m.groupValues[1].toIntOrNull() ?: return@forEach
            val value = m.groupValues[3]
            when (m.groupValues[2]) {
                "desc" -> descs[index] = value
                "code" -> codes[index] = value
                "enable" -> enables[index] = value.equals("true", ignoreCase = true)
            }
        }
        val out = mutableListOf<Cheat>()
        descs.forEach { (index, name) ->
            val code = normalize(codes[index] ?: "")
            if (code.isNotEmpty()) out.add(Cheat(name.ifBlank { "Cheat ${index + 1}" }, code, enables[index] ?: false))
        }
        return out
    }
}
