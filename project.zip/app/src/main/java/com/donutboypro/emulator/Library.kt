package com.donutboypro.emulator

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.CRC32
import java.util.zip.ZipInputStream

data class Game(val name: String, val uri: Uri, val fromFolder: Boolean = false) {
    val title: String get() = name.substringBeforeLast('.')
    val isZip: Boolean get() = name.endsWith(".zip", ignoreCase = true)
}

object RomSupport {
    fun isRom(name: String) = name.endsWith(".gba", ignoreCase = true) || name.endsWith(".zip", ignoreCase = true)
}

/** Walks a Storage Access Framework folder tree and returns every .gba / .zip inside it. */
object FolderScanner {
    private const val MAX_DEPTH = 6
    private const val MAX_RESULTS = 3000

    fun scan(context: Context, tree: Uri): List<Game> {
        val out = ArrayList<Game>()
        runCatching {
            walk(context, tree, DocumentsContract.getTreeDocumentId(tree), 0, out)
        }
        return out
    }

    private fun walk(context: Context, tree: Uri, docId: String, depth: Int, out: MutableList<Game>) {
        if (depth > MAX_DEPTH || out.size >= MAX_RESULTS) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        context.contentResolver.query(children, columns, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    walk(context, tree, id, depth + 1, out)
                } else if (RomSupport.isRom(name)) {
                    out.add(Game(name, DocumentsContract.buildDocumentUriUsingTree(tree, id), fromFolder = true))
                }
            }
        }
    }
}

class PreparedRom(val romFile: File, val gameId: String, val gameDir: File)

/** Copies a ROM (or the first .gba inside a zip) to private storage and works out its per-game save folder. */
object RomPreparer {
    fun prepare(context: Context, game: Game): PreparedRom {
        val cache = File(context.filesDir, "rom_cache").apply { mkdirs() }
        val key = Integer.toUnsignedString(game.uri.toString().hashCode(), 16)
        val out = File(cache, "$key.gba")
        val input = context.contentResolver.openInputStream(game.uri)
            ?: throw IllegalStateException("Android could not read this ROM. Remove it from the library and add it again.")
        input.use {
            if (game.isZip) extractFirstGba(it, out) else FileOutputStream(out).use { o -> it.copyTo(o) }
        }
        if (out.length() < 1024L) throw IllegalArgumentException("The selected file is too small to be a valid GBA ROM.")
        // Saves are keyed by ROM content, so they survive moving or renaming the file.
        val id = crc32Hex(out)
        val dir = File(context.filesDir, "games/$id").apply { mkdirs() }
        return PreparedRom(out, id, dir)
    }

    private fun extractFirstGba(input: InputStream, out: File) {
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                    FileOutputStream(out).use { o -> zip.copyTo(o) }
                    return
                }
            }
        }
        throw IllegalArgumentException("No .gba file was found inside this zip.")
    }

    private fun crc32Hex(file: File): String {
        val crc = CRC32()
        val buffer = ByteArray(64 * 1024)
        file.inputStream().use { s ->
            while (true) {
                val n = s.read(buffer)
                if (n < 0) break
                crc.update(buffer, 0, n)
            }
        }
        return java.lang.Long.toHexString(crc.value).padStart(8, '0')
    }
}
