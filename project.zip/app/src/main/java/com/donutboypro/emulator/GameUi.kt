package com.donutboypro.emulator

import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.DateFormat
import java.util.Date
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

private enum class GameDialog { Menu, SaveSlots, LoadSlots, Cheats }
private enum class Confirm { QuickSave, QuickLoad, Reset }

@Composable
fun GameScreen(
    session: EmulatorSession,
    gameName: String,
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    onExit: () -> Unit,
    onScreenshot: (android.graphics.Bitmap) -> Unit,
    onImportCheats: ((List<Cheat>) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    var dialog by remember { mutableStateOf<GameDialog?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var fastForward by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    fun openDialog(d: GameDialog?) {
        dialog = d
        session.pausedByUser = d != null
    }
    fun doQuickSave() {
        val slot = session.quickSave()
        toast(if (slot > 0) "State saved (slot $slot)" else "Could not save state")
    }
    fun doQuickLoad() {
        val slot = session.quickLoad()
        toast(if (slot > 0) "State loaded (slot $slot)" else "No quick save found")
    }
    val haptic: () -> Unit = {
        if (settings.vibrateButtons) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    BackHandler { if (dialog == null) openDialog(GameDialog.Menu) else openDialog(null) }

    val alpha = settings.controlsOpacity
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val landscape = maxWidth > maxHeight
        if (landscape) {
            GameCanvas(session, settings, Modifier.fillMaxSize())
            if (showControls) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.Start) {
                        ShoulderButton("L", NativeGbaBridge.Key.L, session, alpha, haptic)
                        DPad(session, 140.dp, alpha, settings.dpadDeadZone, settings.disableDiagonals, haptic)
                    }
                    Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
                        UtilityRow(
                            session, settings, fastForward, { fastForward = it },
                            onMenu = { openDialog(GameDialog.Menu) },
                            onQuickSave = { if (settings.confirmQuickSave) confirm = Confirm.QuickSave else doQuickSave() },
                            onQuickLoad = { if (settings.confirmQuickLoad) confirm = Confirm.QuickLoad else doQuickLoad() }
                        )
                        StartSelectRow(session, alpha, haptic)
                    }
                    Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                        ShoulderButton("R", NativeGbaBridge.Key.R, session, alpha, haptic)
                        ActionCluster(session, alpha, haptic)
                    }
                }
            } else {
                TextButton(onClick = { openDialog(GameDialog.Menu) }, modifier = Modifier.align(Alignment.TopCenter)) { Text("☰", color = Color.White) }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Box(Modifier.fillMaxWidth().aspectRatio(240f / 160f)) {
                    GameCanvas(session, settings, Modifier.fillMaxSize())
                    if (settings.showFps) {
                        Text("${session.fps.intValue} fps", color = Color(0xFF72E0C2), fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                    }
                }
                Text(gameName, color = Color(0xFF9AA8B8), fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
                if (showControls) {
                    Column(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                        UtilityRow(
                            session, settings, fastForward, { fastForward = it },
                            onMenu = { openDialog(GameDialog.Menu) },
                            onQuickSave = { if (settings.confirmQuickSave) confirm = Confirm.QuickSave else doQuickSave() },
                            onQuickLoad = { if (settings.confirmQuickLoad) confirm = Confirm.QuickLoad else doQuickLoad() }
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            ShoulderButton("L", NativeGbaBridge.Key.L, session, alpha, haptic)
                            ShoulderButton("R", NativeGbaBridge.Key.R, session, alpha, haptic)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            DPad(session, 140.dp, alpha, settings.dpadDeadZone, settings.disableDiagonals, haptic)
                            ActionCluster(session, alpha, haptic)
                        }
                        StartSelectRow(session, alpha, haptic)
                    }
                } else {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        TextButton(onClick = { openDialog(GameDialog.Menu) }) { Text("☰ Menu") }
                    }
                }
            }
        }
    }

    // Keep the session's fast-forward flag in step with the toggle.
    LaunchedEffect(fastForward) { session.fastForward = fastForward }

    when (dialog) {
        GameDialog.Menu -> MenuDialog(
            session = session, settings = settings, showControls = showControls,
            onToggleControls = { showControls = !showControls },
            onSettingsChange = onSettingsChange,
            onDismiss = { openDialog(null) },
            onSave = { openDialog(GameDialog.SaveSlots) },
            onLoad = { openDialog(GameDialog.LoadSlots) },
            onCheats = { openDialog(GameDialog.Cheats) },
            onQuickSave = { openDialog(null); if (settings.confirmQuickSave) confirm = Confirm.QuickSave else doQuickSave() },
            onQuickLoad = { openDialog(null); if (settings.confirmQuickLoad) confirm = Confirm.QuickLoad else doQuickLoad() },
            onScreenshot = { openDialog(null); onScreenshot(session.snapshot()) },
            onReset = { openDialog(null); confirm = Confirm.Reset },
            onExit = { openDialog(null); onExit() }
        )
        GameDialog.SaveSlots -> SlotsDialog(session, save = true, onDismiss = { openDialog(GameDialog.Menu) },
            onPick = { slot ->
                toast(if (session.saveStateSlot(slot)) "Saved to slot $slot" else "Could not save state")
                openDialog(null)
            })
        GameDialog.LoadSlots -> SlotsDialog(session, save = false, onDismiss = { openDialog(GameDialog.Menu) },
            onPick = { slot ->
                toast(if (session.loadStateSlot(slot)) "Loaded slot $slot" else "Slot $slot is empty")
                openDialog(null)
            })
        GameDialog.Cheats -> CheatsDialog(session, onDismiss = { openDialog(null) }, onImportCheats = onImportCheats, toast = ::toast)
        null -> {}
    }

    confirm?.let { action ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(when (action) { Confirm.QuickSave -> "Quick save?"; Confirm.QuickLoad -> "Quick load?"; Confirm.Reset -> "Reset game?" }) },
            text = { Text(when (action) {
                Confirm.QuickSave -> "This overwrites your quick-save slot."
                Confirm.QuickLoad -> "Unsaved progress will be lost."
                Confirm.Reset -> "The game restarts. Battery saves are kept."
            }) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    when (action) {
                        Confirm.QuickSave -> doQuickSave()
                        Confirm.QuickLoad -> doQuickLoad()
                        Confirm.Reset -> session.reset()
                    }
                }) { Text("Yes") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun GameCanvas(session: EmulatorSession, settings: AppSettings, modifier: Modifier) {
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE")
        val tick = session.frameTick.intValue   // reading this here redraws the canvas every new frame
        val image = session.currentBitmap().asImageBitmap()
        val scale = min(size.width / EmulatorSession.SCREEN_W, size.height / EmulatorSession.SCREEN_H)
        val used = if (settings.integerScale && scale >= 1f) floor(scale) else scale
        val w = (EmulatorSession.SCREEN_W * used).roundToInt()
        val h = (EmulatorSession.SCREEN_H * used).roundToInt()
        val x = ((size.width - w) / 2f).roundToInt()
        val y = if (size.height > size.width) 0 else ((size.height - h) / 2f).roundToInt()
        drawImage(
            image = image,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(EmulatorSession.SCREEN_W, EmulatorSession.SCREEN_H),
            dstOffset = IntOffset(x, y),
            dstSize = IntSize(w, h),
            filterQuality = if (settings.linearFilter) FilterQuality.Low else FilterQuality.None
        )
    }
}

@Composable
private fun ShoulderButton(label: String, key: Int, session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    PadButton(label, 84.dp, 40.dp, alpha, roundedShape(14.dp),
        onDown = { haptic(); session.setButton(key, true) },
        onUp = { session.setButton(key, false) })
}

@Composable
private fun StartSelectRow(session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        PadButton("SELECT", 78.dp, 32.dp, alpha, roundedShape(12.dp),
            onDown = { haptic(); session.setButton(NativeGbaBridge.Key.SELECT, true) },
            onUp = { session.setButton(NativeGbaBridge.Key.SELECT, false) })
        PadButton("START", 78.dp, 32.dp, alpha, roundedShape(12.dp),
            onDown = { haptic(); session.setButton(NativeGbaBridge.Key.START, true) },
            onUp = { session.setButton(NativeGbaBridge.Key.START, false) })
    }
}

@Composable
private fun ActionCluster(session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            // Turbo buttons: hold to auto-repeat
            PadButton("B⚡", 44.dp, 34.dp, alpha * 0.8f,
                onDown = { haptic(); session.setTurbo(NativeGbaBridge.Key.B, true) },
                onUp = { session.setTurbo(NativeGbaBridge.Key.B, false) })
            // Macro button: presses A and B together
            PadButton("A+B", 50.dp, 38.dp, alpha * 0.8f,
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.A, true); session.setButton(NativeGbaBridge.Key.B, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.A, false); session.setButton(NativeGbaBridge.Key.B, false) })
            PadButton("A⚡", 44.dp, 34.dp, alpha * 0.8f,
                onDown = { haptic(); session.setTurbo(NativeGbaBridge.Key.A, true) },
                onUp = { session.setTurbo(NativeGbaBridge.Key.A, false) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            PadButton("B", 64.dp, 64.dp, alpha,
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.B, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.B, false) })
            PadButton("A", 72.dp, 72.dp, alpha,
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.A, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.A, false) })
        }
    }
}

@Composable
private fun UtilityRow(
    session: EmulatorSession,
    settings: AppSettings,
    fastForward: Boolean,
    onFastForward: (Boolean) -> Unit,
    onMenu: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onMenu, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("☰", color = Color.White, fontSize = 18.sp) }
        if (settings.rewindEnabled) {
            PadButton("⏪", 44.dp, 34.dp, 0.9f, roundedShape(10.dp),
                onDown = { session.rewinding = true },
                onUp = { session.rewinding = false })
        }
        FilterChip(
            selected = fastForward,
            onClick = { onFastForward(!fastForward) },
            label = { Text("⏩ ${settings.fastForwardSpeed}x", fontSize = 12.sp) }
        )
        TextButton(onClick = onQuickSave, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("💾", fontSize = 18.sp) }
        TextButton(onClick = onQuickLoad, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("📂", fontSize = 18.sp) }
    }
}

@Composable
private fun MenuDialog(
    session: EmulatorSession,
    settings: AppSettings,
    showControls: Boolean,
    onToggleControls: () -> Unit,
    onSettingsChange: (AppSettings) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    onLoad: () -> Unit,
    onCheats: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit,
    onScreenshot: () -> Unit,
    onReset: () -> Unit,
    onExit: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                MenuItem("▶  Resume", onDismiss)
                MenuItem("💾  Quick save", onQuickSave)
                MenuItem("📂  Quick load", onQuickLoad)
                MenuItem("🗂  Save state…", onSave)
                MenuItem("📥  Load state…", onLoad)
                MenuItem("🎯  Cheats…", onCheats)
                MenuItem("📷  Screenshot", onScreenshot)
                MenuItem(if (settings.linearFilter) "🖼  Filter: Smooth (tap for Sharp)" else "🖼  Filter: Sharp (tap for Smooth)") {
                    onSettingsChange(settings.copy(linearFilter = !settings.linearFilter))
                }
                MenuItem(if (settings.integerScale) "📐  Scale: Integer (tap for Fit)" else "📐  Scale: Fit (tap for Integer)") {
                    onSettingsChange(settings.copy(integerScale = !settings.integerScale))
                }
                MenuItem(if (showControls) "🎮  Hide on-screen controls" else "🎮  Show on-screen controls", onToggleControls)
                MenuItem("🔄  Reset game", onReset)
                MenuItem("🚪  Exit to library", onExit)
            }
        }
    }
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun SlotsDialog(session: EmulatorSession, save: Boolean, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text(if (save) "Save to slot" else "Load from slot", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                for (slot in 1..EmulatorSession.MANUAL_SLOTS) {
                    val time = session.slotTimestamp(slot)
                    val enabled = save || time != null
                    TextButton(onClick = { onPick(slot) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Slot $slot — " + (if (time != null) format.format(Date(time)) else "empty"),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Back") }
            }
        }
    }
}

@Composable
private fun CheatsDialog(
    session: EmulatorSession,
    onDismiss: () -> Unit,
    onImportCheats: ((List<Cheat>) -> Unit) -> Unit,
    toast: (String) -> Unit
) {
    val cheats = remember { mutableStateListOf<Cheat>().apply { addAll(CheatStore.load(session.gameDir)) } }
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    fun commit() {
        CheatStore.save(session.gameDir, cheats)
        session.applyCheats(cheats)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text("Cheats", color = Color.White, fontSize = 18.sp)
                Text("GameShark, Action Replay and CodeBreaker codes", color = Color(0xFF9AA8B8), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                if (cheats.isEmpty()) {
                    Text("No cheats yet for this game.", color = Color(0xFF9AA8B8))
                } else {
                    LazyColumn(Modifier.heightIn(max = 220.dp)) {
                        itemsIndexed(cheats) { index, cheat ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = cheat.enabled, onCheckedChange = {
                                    cheats[index] = cheat.copy(enabled = it)
                                    commit()
                                })
                                Spacer(Modifier.width(8.dp))
                                Text(cheat.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                                TextButton(onClick = { cheats.removeAt(index); commit() }) { Text("Delete") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = code, onValueChange = { code = it },
                    label = { Text("Code(s), e.g. 82003884 0001") }, modifier = Modifier.fillMaxWidth(), minLines = 2
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = {
                        val normalized = CheatStore.normalize(code)
                        if (normalized.isEmpty()) {
                            toast("Enter a code like 82003884 0001")
                        } else {
                            cheats.add(Cheat(name.ifBlank { "Cheat ${cheats.size + 1}" }, normalized, true))
                            val accepted = session.applyCheats(cheats)
                            if (accepted < cheats.size) {
                                cheats.removeAt(cheats.size - 1)
                                session.applyCheats(cheats)
                                toast("That code was not recognised")
                            } else {
                                CheatStore.save(session.gameDir, cheats)
                                name = ""; code = ""
                            }
                        }
                    }) { Text("Add") }
                    TextButton(onClick = {
                        onImportCheats { imported ->
                            cheats.addAll(imported)
                            commit()
                            toast("Imported ${imported.size} cheat(s)")
                        }
                    }) { Text("Import .cht") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            }
        }
    }
}
