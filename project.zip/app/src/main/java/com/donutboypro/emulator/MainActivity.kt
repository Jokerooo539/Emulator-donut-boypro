package com.donutboypro.emulator

import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

private const val PREFS = "donut_boy_library"
private const val GAMES_KEY = "gba_uris"
private const val FOLDERS_KEY = "rom_folders"
private const val LAST_GAME_KEY = "last_game_uri"

class MainActivity : ComponentActivity() {
    private val games = mutableStateListOf<Game>()          // individually imported files
    private val folderGames = mutableStateListOf<Game>()    // found by scanning ROM folders
    private val folders = mutableStateListOf<Uri>()
    private var scanning by mutableStateOf(false)
    private var settings by mutableStateOf(AppSettings())
    private var session by mutableStateOf<EmulatorSession?>(null)
    private var activeGame by mutableStateOf<Game?>(null)
    private var isLoading by mutableStateOf(false)
    private var launchError by mutableStateOf<String?>(null)
    private val nativeBridge by lazy { NativeGbaBridge() }
    private var chtCallback: ((List<Cheat>) -> Unit)? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            val name = getDisplayName(uri) ?: "GBA game"
            if (!RomSupport.isRom(name)) return@forEach
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            if (games.none { it.uri == uri }) games.add(Game(name, uri))
        }
        saveLibrary()
    }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (folders.none { it == uri }) folders.add(uri)
            saveLibrary()
            scanFolders()
        }
    }

    private val chtPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val callback = chtCallback
        chtCallback = null
        if (uri == null || callback == null) return@registerForActivityResult
        lifecycleScope.launch {
            val cheats = withContext(Dispatchers.IO) {
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    CheatStore.parseCht(text)
                }.getOrDefault(emptyList())
            }
            if (cheats.isEmpty()) toast("No cheats found in that file") else callback(cheats)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore.load(this)
        loadLibrary()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF72E0C2), background = Color(0xFF10151D), surface = Color(0xFF1B2430)
            )) {
                val current = session
                val game = activeGame
                if (current != null && game != null) {
                    GameScreen(
                        session = current,
                        gameName = game.title,
                        settings = settings,
                        onSettingsChange = { updateSettings(it) },
                        onExit = { closeGame() },
                        onScreenshot = { saveScreenshot(it) },
                        onImportCheats = { callback ->
                            chtCallback = callback
                            chtPicker.launch(arrayOf("*/*"))
                        }
                    )
                } else {
                    val library = (games.toList() + folderGames.toList())
                        .distinctBy { it.uri.toString() }
                        .sortedBy { it.title.lowercase() }
                    HomeScreen(
                        games = library,
                        folders = folders.toList(),
                        scanning = scanning,
                        settings = settings,
                        onSettingsChange = { updateSettings(it) },
                        onImportFiles = { filePicker.launch(arrayOf("application/octet-stream", "application/zip", "*/*")) },
                        onAddFolder = { folderPicker.launch(null) },
                        onRescan = { scanFolders() },
                        onRemoveFolder = { folders.remove(it); saveLibrary(); scanFolders() },
                        onOpen = { startGame(it) },
                        onRemove = { games.remove(it); saveLibrary() }
                    )
                    if (isLoading) AlertDialog(
                        onDismissRequest = {}, title = { Text("Starting GBA game") },
                        text = { Text("Preparing the ROM and starting the mGBA engine…") }, confirmButton = {}
                    )
                    launchError?.let { message ->
                        AlertDialog(
                            onDismissRequest = { launchError = null },
                            title = { Text("Could not start game") }, text = { Text(message) },
                            confirmButton = { TextButton(onClick = { launchError = null }) { Text("OK") } }
                        )
                    }
                }
            }
        }
        scanFolders()
        if (settings.loadLastGameOnStartup && savedInstanceState == null) startLastGame()
    }

    // ----- game lifecycle -----

    private fun startGame(game: Game) {
        if (isLoading || session != null) return
        isLoading = true
        launchError = null
        val startSettings = settings
        lifecycleScope.launch {
            try {
                val created = withContext(Dispatchers.IO) {
                    val prepared = RomPreparer.prepare(this@MainActivity, game)
                    val savePath = File(prepared.gameDir, "game.sav").absolutePath
                    val handle = nativeBridge.create(prepared.romFile.absolutePath, savePath)
                    if (handle == 0L) {
                        null
                    } else {
                        val s = EmulatorSession(applicationContext, nativeBridge, handle, prepared.gameDir, startSettings)
                        s.prepare(CheatStore.load(prepared.gameDir))
                        s
                    }
                }
                if (created == null) {
                    launchError = "mGBA could not open this file. Check that it is a valid GBA ROM (.gba, or a .zip containing one). If it still fails, check Logcat for DonutBoyPro errors."
                } else {
                    created.start()
                    session = created
                    activeGame = game
                    enterGameMode()
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(LAST_GAME_KEY, game.uri.toString()).apply()
                }
            } catch (t: Throwable) {
                launchError = "${t.javaClass.simpleName}: ${t.message ?: "Unknown error"}. Check that the native library was built and packaged for this phone."
            } finally {
                isLoading = false
            }
        }
    }

    private fun startLastGame() {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(LAST_GAME_KEY, null) ?: return
        runCatching {
            val uri = Uri.parse(raw)
            val name = getDisplayName(uri) ?: return
            if (RomSupport.isRom(name)) startGame(Game(name, uri))
        }
    }

    private fun closeGame() {
        val old = session
        session = null
        activeGame = null
        old?.close(saveAuto = true)
        leaveGameMode()
    }

    private fun enterGameMode() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun leaveGameMode() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun updateSettings(new: AppSettings) {
        settings = new
        SettingsStore.save(this, new)
        session?.settings = new
    }

    override fun onPause() {
        session?.let {
            it.pausedByLifecycle = true
            it.autoSave()
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        session?.pausedByLifecycle = false
    }

    override fun onDestroy() {
        val old = session
        session = null
        old?.close(saveAuto = true)
        super.onDestroy()
    }

    // ----- gamepads -----

    private fun mapPadKey(code: Int): Int? = when (code) {
        KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_Y -> NativeGbaBridge.Key.A
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_X -> NativeGbaBridge.Key.B
        KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_L2 -> NativeGbaBridge.Key.L
        KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_R2 -> NativeGbaBridge.Key.R
        KeyEvent.KEYCODE_BUTTON_SELECT -> NativeGbaBridge.Key.SELECT
        KeyEvent.KEYCODE_BUTTON_START -> NativeGbaBridge.Key.START
        KeyEvent.KEYCODE_DPAD_UP -> NativeGbaBridge.Key.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> NativeGbaBridge.Key.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> NativeGbaBridge.Key.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> NativeGbaBridge.Key.RIGHT
        else -> null
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val s = session
        val fromPad = (event.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (event.source and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
        if (s != null && fromPad) {
            val key = mapPadKey(event.keyCode)
            if (key != null) {
                when (event.action) {
                    KeyEvent.ACTION_DOWN -> s.setPad(key, true)
                    KeyEvent.ACTION_UP -> s.setPad(key, false)
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        val s = session
        if (s != null && (event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            event.action == MotionEvent.ACTION_MOVE) {
            val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val x = if (abs(hatX) > 0.5f) hatX else event.getAxisValue(MotionEvent.AXIS_X)
            val y = if (abs(hatY) > 0.5f) hatY else event.getAxisValue(MotionEvent.AXIS_Y)
            var mask = 0
            if (x > 0.5f) mask = mask or NativeGbaBridge.Key.mask(NativeGbaBridge.Key.RIGHT)
            if (x < -0.5f) mask = mask or NativeGbaBridge.Key.mask(NativeGbaBridge.Key.LEFT)
            if (y > 0.5f) mask = mask or NativeGbaBridge.Key.mask(NativeGbaBridge.Key.DOWN)
            if (y < -0.5f) mask = mask or NativeGbaBridge.Key.mask(NativeGbaBridge.Key.UP)
            s.setStick(mask)
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    // ----- screenshots -----

    private fun saveScreenshot(source: Bitmap) {
        lifecycleScope.launch(Dispatchers.IO) {
            val name = "DonutBoyPro_${System.currentTimeMillis()}.png"
            val ok = runCatching {
                val big = Bitmap.createScaledBitmap(source, source.width * 3, source.height * 3, false)
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DonutBoyPro")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("Could not create the image")
                    contentResolver.openOutputStream(uri)?.use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
                    File(dir, name).outputStream().use { big.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
            }.isSuccess
            withContext(Dispatchers.Main) {
                toast(if (ok) "Screenshot saved" else "Could not save screenshot")
            }
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    // ----- library persistence -----

    private fun scanFolders() {
        if (folders.isEmpty()) {
            folderGames.clear()
            return
        }
        val snapshot = folders.toList()
        scanning = true
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) { snapshot.flatMap { FolderScanner.scan(this@MainActivity, it) } }
            folderGames.clear()
            folderGames.addAll(found)
            scanning = false
        }
    }

    private fun getDisplayName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor?.moveToFirst() == true) cursor.getString(0) else uri.lastPathSegment?.substringAfterLast('/')
        } catch (t: Throwable) {
            null
        } finally {
            cursor?.close()
        }
    }

    private fun loadLibrary() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.getStringSet(GAMES_KEY, emptySet()).orEmpty().forEach { raw ->
            runCatching {
                val uri = Uri.parse(raw)
                val name = getDisplayName(uri) ?: return@runCatching
                if (RomSupport.isRom(name)) games.add(Game(name, uri))
            }
        }
        prefs.getStringSet(FOLDERS_KEY, emptySet()).orEmpty().forEach { raw ->
            runCatching { folders.add(Uri.parse(raw)) }
        }
    }

    private fun saveLibrary() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putStringSet(GAMES_KEY, games.map { it.uri.toString() }.toSet())
            .putStringSet(FOLDERS_KEY, folders.map { it.toString() }.toSet())
            .apply()
    }
}
