# Donut Boy Pro 0.4.0 — Native GBA Preview

This update connects the Android library screen to the bundled mGBA GBA core through JNI.

## Included
- Existing GBA-only library and persistent imported-file references.
- Copies Android `content://` ROM selections into app-private storage before loading.
- Calls the native mGBA bridge when a library item is opened.
- Runs native frames and displays a 240 × 160 game image.
- Adds on-screen A, B, D-pad, Start, Select, L and R buttons.
- Synchronizes native frame/input/cleanup calls.
- Displays an error dialog if ROM copying or native startup fails.
- Retains the bundled mGBA source and license notices.

## Not included or not yet verified
- Android audio output (this preview is silent).
- Save states, rewind, cheats, fast-forward, Bluetooth controller mapping, skins and cloud sync.
- Device-level performance, ROM compatibility and lifecycle testing have not been completed in this build environment.
- The source ZIP has not been successfully rebuilt here: this environment could not download Gradle because network DNS access is unavailable. Build and test it in Android Studio on your Windows PC before relying on it.

## Build on Windows
1. Extract the ZIP.
2. Open `DonutBoyPro-Android-Starter/DonutBoyPro` in Android Studio.
3. Ensure Android SDK, NDK `27.0.12077973`, and CMake `3.22.1` are installed (matching the project's existing configuration).
4. Run in PowerShell from the project root:

   ```powershell
   .\gradlew.bat :app:assembleDebug
   ```

5. APK output:

   `app\build\outputs\apk\debug\app-debug.apk`

## Legal
No game ROMs or proprietary BIOS are included. Import only ROM files you are legally entitled to use. mGBA is distributed under the Mozilla Public License 2.0; retain its license and notices when redistributing modified builds.
