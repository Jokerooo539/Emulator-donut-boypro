package com.donutboypro.emulator

import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.DateFormat
import java.util.Date
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

private enum class GameDialog { Menu, SaveSlots, LoadSlots, Cheats, Buttons }
private enum class Confirm { QuickSave, QuickLoad, Reset }

private val GROUP_NAMES = mapOf(
    "screen" to "Game screen", "menu" to "Menu button", "rewind" to "Rewind button", "ff" to "Fast-forward button",
    "qsave" to "Quick save button", "qload" to "Quick load button", "l" to "L button", "r" to "R button",
    "dpad" to "D-pad", "action" to "A / B buttons", "startselect" to "Select / Start"
)

private val EFFECT_NAMES = listOf("Off", "Scanlines", "LCD grid", "GBA colours", "Scanlines + GBA colours")

private val GBA_COLOR_MATRIX = ColorMatrix(
    floatArrayOf(
        0.86f, 0.10f, 0.04f, 0f, 6f,
        0.05f, 0.90f, 0.05f, 0f, 6f,
        0.04f, 0.10f, 0.86f, 0f, 6f,
        0f, 0f, 0f, 1f, 0f
    )
)

@Composable
fun GameScreen(
    session: EmulatorSession,
    gameName: String,
    settings: AppSettings,
    skin: LoadedSkin?,
    skins: List<SkinSpec>,
    hasGameOverrides: Boolean,
    onSettingsChange: (AppSettings) -> Unit,
    onResetGameSettings: () -> Unit,
    onExit: () -> Unit,
    onScreenshot: (android.graphics.Bitmap) -> Unit,
    onToggleGif: () -> Unit,
    onImportCheats: ((List<Cheat>) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    var dialog by remember { mutableStateOf<GameDialog?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var fastForward by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    fun openDialog(d: GameDialog?) {
        dialog = d
        session.pausedByUser = d != null
    }
    fun doQuickSave() {
        val slot = session.quickSave()
        toast(if (slot > 0) "State saved (slot $slot)" else "Could not save state")
    }
    fun doQuickLoad() {
        val slot = session.quickLoad()
        toast(if (slot > 0) "State loaded (slot $slot)" else "No quick save found")
    }
    val haptic: () -> Unit = {
        if (settings.vibrateButtons) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }
    val onQuickSave: () -> Unit = {
        if (settings.confirmQuickSave) { confirm = Confirm.QuickSave } else { doQuickSave() }
    }
    val onQuickLoad: () -> Unit = {
        if (settings.confirmQuickLoad) { confirm = Confirm.QuickLoad } else { doQuickLoad() }
    }

    BackHandler {
        if (editing) {
            editing = false
        } else if (dialog == null) {
            openDialog(GameDialog.Menu)
        } else {
            openDialog(null)
        }
    }

    CompositionLocalProvider(LocalSkin provides skin) {
    BoxWithConstraints(Modifier.fillMaxSize().background(Color(skin?.spec?.backgroundColor ?: 0xFF000000.toInt()))) {
        val landscape = maxWidth > maxHeight
        val backdrop = if (landscape) skin?.backgroundLandscape else skin?.backgroundPortrait
        if (backdrop != null) {
            Image(bitmap = backdrop.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        val layout = remember(landscape) { ControlLayout(context, if (landscape) "land" else "port") }
        var selected by remember { mutableStateOf("screen") }
        val baseW = if (landscape) min(maxWidth.value, maxHeight.value * 1.5f) else maxWidth.value
        val screenScale = layout.scale("screen")
        val screenW = (baseW * screenScale).dp
        val screenH = (baseW * screenScale * 2f / 3f).dp
        val belowScreen = (maxWidth.value * 2f / 3f).dp

        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Movable(
                "screen", if (landscape) Alignment.Center else Alignment.TopCenter, 0.dp, 0.dp, layout, 1f,
                editing, selected == "screen", { selected = it }, false
            ) {
                Box(Modifier.size(screenW, screenH)) { GameCanvas(session, settings, Modifier.fillMaxSize()) }
            }
            if (settings.showFps) {
                Text("${session.fps.intValue} fps", color = Color(0xFF72E0C2), fontSize = 11.sp, modifier = Modifier.align(Alignment.TopStart).padding(6.dp))
            }
            if (session.recording.intValue == 1) {
                Text("● REC", color = Color(0xFFFF5252), fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp))
            }
            if (showControls || editing) {
                ControlsOverlay(
                    landscape, belowScreen, session, settings, layout, editing, selected, { selected = it },
                    fastForward, { fastForward = it }, { openDialog(GameDialog.Menu) }, onQuickSave, onQuickLoad, haptic
                )
            } else {
                TextButton(onClick = { openDialog(GameDialog.Menu) }, modifier = Modifier.align(Alignment.TopCenter)) { Text("☰", color = Color.White) }
            }
        }

        if (editing) {
            Surface(
                modifier = Modifier.align(Alignment.Center).padding(16.dp),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = Color(0xEE1B2430)
            ) {
                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Tap or drag any item to move it", color = Color.White, fontSize = 13.sp)
                    Text("Selected: ${GROUP_NAMES[selected] ?: selected}", color = Color(0xFF72E0C2), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { layout.setScale(selected, (layout.scale(selected) - 0.1f).coerceAtLeast(0.4f)) }) { Text("Smaller") }
                        TextButton(onClick = { layout.setScale(selected, (layout.scale(selected) + 0.1f).coerceAtMost(2.5f)) }) { Text("Bigger") }
                        TextButton(onClick = { layout.reset() }) { Text("Reset all") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { openDialog(GameDialog.Buttons) }) { Text("Show / hide buttons") }
                        Button(onClick = { editing = false }) { Text("Done") }
                    }
                }
            }
        }
    }
    }

    // Keep the session's fast-forward flag in step with the toggle.
    LaunchedEffect(fastForward) { session.fastForward = fastForward }

    when (dialog) {
        GameDialog.Menu -> MenuDialog(
            session = session, settings = settings, skins = skins, showControls = showControls, hasGameOverrides = hasGameOverrides,
            onToggleControls = { showControls = !showControls },
            onSettingsChange = onSettingsChange,
            onResetGameSettings = onResetGameSettings,
            onDismiss = { openDialog(null) },
            onSave = { openDialog(GameDialog.SaveSlots) },
            onLoad = { openDialog(GameDialog.LoadSlots) },
            onCheats = { openDialog(GameDialog.Cheats) },
            onQuickSave = { openDialog(null); onQuickSave() },
            onQuickLoad = { openDialog(null); onQuickLoad() },
            onScreenshot = { openDialog(null); onScreenshot(session.snapshot()) },
            onToggleGif = { openDialog(null); onToggleGif() },
            onEditLayout = { openDialog(null); showControls = true; editing = true },
            onButtons = { openDialog(GameDialog.Buttons) },
            onReset = { openDialog(null); confirm = Confirm.Reset },
            onExit = { openDialog(null); onExit() }
        )
        GameDialog.SaveSlots -> SlotsDialog(session, save = true, onDismiss = { openDialog(GameDialog.Menu) },
            onPick = { slot ->
                toast(if (session.saveStateSlot(slot)) "Saved to slot $slot" else "Could not save state")
                openDialog(null)
            })
        GameDialog.LoadSlots -> SlotsDialog(session, save = false, onDismiss = { openDialog(GameDialog.Menu) },
            onPick = { slot ->
                toast(if (session.loadStateSlot(slot)) "Loaded slot $slot" else "Slot $slot is empty")
                openDialog(null)
            })
        GameDialog.Cheats -> CheatsDialog(session, onDismiss = { openDialog(null) }, onImportCheats = onImportCheats, toast = ::toast)
        GameDialog.Buttons -> ButtonsDialog(settings, onSettingsChange) { openDialog(null) }
        null -> {}
    }

    confirm?.let { action ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(when (action) { Confirm.QuickSave -> "Quick save?"; Confirm.QuickLoad -> "Quick load?"; Confirm.Reset -> "Reset game?" }) },
            text = { Text(when (action) {
                Confirm.QuickSave -> "This overwrites your quick-save slot."
                Confirm.QuickLoad -> "Unsaved progress will be lost."
                Confirm.Reset -> "The game restarts. Battery saves are kept."
            }) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    when (action) {
                        Confirm.QuickSave -> doQuickSave()
                        Confirm.QuickLoad -> doQuickLoad()
                        Confirm.Reset -> session.reset()
                    }
                }) { Text("Yes") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun GameCanvas(session: EmulatorSession, settings: AppSettings, modifier: Modifier) {
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE")
        val tick = session.frameTick.intValue   // reading this here redraws the canvas every new frame
        val image = session.currentBitmap().asImageBitmap()
        val scale = min(size.width / EmulatorSession.SCREEN_W, size.height / EmulatorSession.SCREEN_H)
        val used = if (settings.integerScale && scale >= 1f) floor(scale) else scale
        val w = (EmulatorSession.SCREEN_W * used).roundToInt()
        val h = (EmulatorSession.SCREEN_H * used).roundToInt()
        val x = ((size.width - w) / 2f).roundToInt()
        val y = ((size.height - h) / 2f).roundToInt()
        val effect = settings.screenEffect
        drawImage(
            image = image,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(EmulatorSession.SCREEN_W, EmulatorSession.SCREEN_H),
            dstOffset = IntOffset(x, y),
            dstSize = IntSize(w, h),
            filterQuality = if (settings.linearFilter) FilterQuality.Low else FilterQuality.None,
            colorFilter = if (effect == 3 || effect == 4) ColorFilter.colorMatrix(GBA_COLOR_MATRIX) else null
        )
        if ((effect == 1 || effect == 4) && used >= 2f) {
            // scanlines: a darker band at the bottom of every source row
            val thickness = used * 0.35f
            for (r in 0 until EmulatorSession.SCREEN_H) {
                val ly = y + (r + 1) * used - thickness / 2f
                drawLine(Color(0x66000000), Offset(x.toFloat(), ly), Offset((x + w).toFloat(), ly), strokeWidth = thickness)
            }
        }
        if (effect == 2 && used >= 3f) {
            // LCD grid: faint lines between pixels
            val lineColor = Color(0x30000000)
            for (c in 1 until EmulatorSession.SCREEN_W) {
                val lx = x + c * used
                drawLine(lineColor, Offset(lx, y.toFloat()), Offset(lx, (y + h).toFloat()), strokeWidth = 1f)
            }
            for (r in 1 until EmulatorSession.SCREEN_H) {
                val ly = y + r * used
                drawLine(lineColor, Offset(x.toFloat(), ly), Offset((x + w).toFloat(), ly), strokeWidth = 1f)
            }
        }
    }
}

/** Anything on the play screen that can be dragged (and resized) while [editing]: the game screen and every control group. */
@Composable
private fun BoxScope.Movable(
    id: String, align: Alignment, baseX: Dp, baseY: Dp, layout: ControlLayout, scale: Float,
    editing: Boolean, selected: Boolean, onSelect: (String) -> Unit, useLayer: Boolean,
    content: @Composable () -> Unit
) {
    val off = layout.get(id)
    var mod = Modifier
        .align(align)
        .offset { IntOffset((off.first + baseX.value).dp.roundToPx(), (off.second + baseY.value).dp.roundToPx()) }
    if (useLayer) mod = mod.graphicsLayer { scaleX = scale; scaleY = scale }
    Box(mod) {
        content()
        if (editing) {
            val dragScale = if (useLayer) scale else 1f
            Box(
                Modifier
                    .matchParentSize()
                    .background(Color(0x3372E0C2))
                    .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color(0xFF72E0C2))
                    .pointerInput(id) { detectTapGestures(onTap = { onSelect(id) }) }
                    .pointerInput(id, dragScale) {
                        detectDragGestures(onDragStart = { onSelect(id) }, onDragEnd = { layout.save() }) { change, drag ->
                            change.consume()
                            layout.move(id, drag.x * dragScale / density, drag.y * dragScale / density)
                        }
                    }
            )
        }
    }
}

@Composable
private fun BoxScope.ControlsOverlay(
    landscape: Boolean,
    belowScreen: Dp,
    session: EmulatorSession,
    settings: AppSettings,
    layout: ControlLayout,
    editing: Boolean,
    selected: String,
    onSelect: (String) -> Unit,
    fastForward: Boolean,
    onFastForward: (Boolean) -> Unit,
    onMenu: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit,
    haptic: () -> Unit
) {
    val alpha = settings.controlsOpacity
    val g = settings.controlsScale
    val row1 = if (landscape) 0.dp else belowScreen + 14.dp
    val row2 = if (landscape) 0.dp else belowScreen + 66.dp
    val bottomLift = if (landscape) 0.dp else (-100).dp
    val startLift = if (landscape) 0.dp else (-20).dp

    // Separate, individually movable utility buttons
    Movable("menu", Alignment.TopCenter, (-120).dp, row1, layout, layout.scale("menu") * g, editing, selected == "menu", onSelect, true) {
        PadButton("☰", 48.dp, 38.dp, 0.9f, roundedShape(10.dp), skinKey = "menu", onDown = { haptic() }, onUp = onMenu)
    }
    if (settings.rewindEnabled && settings.isShown("rewind")) {
        Movable("rewind", Alignment.TopCenter, (-62).dp, row1, layout, layout.scale("rewind") * g, editing, selected == "rewind", onSelect, true) {
            PadButton("⏪", 48.dp, 38.dp, 0.9f, roundedShape(10.dp), skinKey = "rewind",
                onDown = { session.rewinding = true }, onUp = { session.rewinding = false })
        }
    }
    if (settings.isShown("ff")) {
        Movable("ff", Alignment.TopCenter, 0.dp, row1, layout, layout.scale("ff") * g, editing, selected == "ff", onSelect, true) {
            PadButton("⏩ ${settings.fastForwardSpeed}x", 64.dp, 38.dp, 0.9f, roundedShape(10.dp), skinKey = "ff", highlight = fastForward,
                onDown = { haptic() }, onUp = { onFastForward(!fastForward) })
        }
    }
    if (settings.isShown("qsave")) {
        Movable("qsave", Alignment.TopCenter, 62.dp, row1, layout, layout.scale("qsave") * g, editing, selected == "qsave", onSelect, true) {
            PadButton("💾", 48.dp, 38.dp, 0.9f, roundedShape(10.dp), skinKey = "qsave", onDown = { haptic() }, onUp = onQuickSave)
        }
    }
    if (settings.isShown("qload")) {
        Movable("qload", Alignment.TopCenter, 120.dp, row1, layout, layout.scale("qload") * g, editing, selected == "qload", onSelect, true) {
            PadButton("📂", 48.dp, 38.dp, 0.9f, roundedShape(10.dp), skinKey = "qload", onDown = { haptic() }, onUp = onQuickLoad)
        }
    }

    Movable("l", Alignment.TopStart, 0.dp, row2, layout, layout.scale("l") * g, editing, selected == "l", onSelect, true) {
        ShoulderButton("L", NativeGbaBridge.Key.L, session, alpha, haptic)
    }
    Movable("r", Alignment.TopEnd, 0.dp, row2, layout, layout.scale("r") * g, editing, selected == "r", onSelect, true) {
        ShoulderButton("R", NativeGbaBridge.Key.R, session, alpha, haptic)
    }
    Movable("dpad", Alignment.BottomStart, 0.dp, bottomLift, layout, layout.scale("dpad") * g, editing, selected == "dpad", onSelect, true) {
        DPad(session, 140.dp, alpha, settings.dpadDeadZone, settings.disableDiagonals, haptic)
    }
    Movable("action", Alignment.BottomEnd, 0.dp, bottomLift, layout, layout.scale("action") * g, editing, selected == "action", onSelect, true) {
        ActionCluster(session, settings, alpha, haptic)
    }
    Movable("startselect", Alignment.BottomCenter, 0.dp, startLift, layout, layout.scale("startselect") * g, editing, selected == "startselect", onSelect, true) {
        StartSelectRow(session, alpha, haptic)
    }
}

@Composable
private fun ShoulderButton(label: String, key: Int, session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    PadButton(label, 84.dp, 40.dp, alpha, roundedShape(14.dp), skinKey = label.lowercase(),
        onDown = { haptic(); session.setButton(key, true) },
        onUp = { session.setButton(key, false) })
}

@Composable
private fun StartSelectRow(session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        PadButton("SELECT", 78.dp, 32.dp, alpha, roundedShape(12.dp), skinKey = "select",
            onDown = { haptic(); session.setButton(NativeGbaBridge.Key.SELECT, true) },
            onUp = { session.setButton(NativeGbaBridge.Key.SELECT, false) })
        PadButton("START", 78.dp, 32.dp, alpha, roundedShape(12.dp), skinKey = "start",
            onDown = { haptic(); session.setButton(NativeGbaBridge.Key.START, true) },
            onUp = { session.setButton(NativeGbaBridge.Key.START, false) })
    }
}

@Composable
private fun ActionCluster(session: EmulatorSession, settings: AppSettings, alpha: Float, haptic: () -> Unit) {
    val showTurboB = settings.isShown("turboB")
    val showMacro = settings.isShown("macro")
    val showTurboA = settings.isShown("turboA")
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (showTurboB || showMacro || showTurboA) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                // Turbo buttons: hold to auto-repeat
                if (showTurboB) {
                    PadButton("B⚡", 44.dp, 34.dp, alpha * 0.8f, skinKey = "turbo_b",
                        onDown = { haptic(); session.setTurbo(NativeGbaBridge.Key.B, true) },
                        onUp = { session.setTurbo(NativeGbaBridge.Key.B, false) })
                }
                // Macro button: presses A and B together
                if (showMacro) {
                    PadButton("A+B", 50.dp, 38.dp, alpha * 0.8f, skinKey = "macro",
                        onDown = { haptic(); session.setButton(NativeGbaBridge.Key.A, true); session.setButton(NativeGbaBridge.Key.B, true) },
                        onUp = { session.setButton(NativeGbaBridge.Key.A, false); session.setButton(NativeGbaBridge.Key.B, false) })
                }
                if (showTurboA) {
                    PadButton("A⚡", 44.dp, 34.dp, alpha * 0.8f, skinKey = "turbo_a",
                        onDown = { haptic(); session.setTurbo(NativeGbaBridge.Key.A, true) },
                        onUp = { session.setTurbo(NativeGbaBridge.Key.A, false) })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            PadButton("B", 64.dp, 64.dp, alpha, skinKey = "b",
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.B, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.B, false) })
            PadButton("A", 72.dp, 72.dp, alpha, skinKey = "a",
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.A, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.A, false) })
        }
    }
}

@Composable
private fun ButtonsDialog(settings: AppSettings, onChange: (AppSettings) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text("Visible buttons", color = Color.White, fontSize = 18.sp)
                Text("Turn off the buttons you never use. Saved for all games.", color = Color(0xFF9AA8B8), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                ButtonVisibilityList(settings, onChange)
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            }
        }
    }
}

@Composable
private fun MenuDialog(
    session: EmulatorSession,
    settings: AppSettings,
    skins: List<SkinSpec>,
    showControls: Boolean,
    hasGameOverrides: Boolean,
    onToggleControls: () -> Unit,
    onSettingsChange: (AppSettings) -> Unit,
    onResetGameSettings: () -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    onLoad: () -> Unit,
    onCheats: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit,
    onScreenshot: () -> Unit,
    onToggleGif: () -> Unit,
    onEditLayout: () -> Unit,
    onButtons: () -> Unit,
    onReset: () -> Unit,
    onExit: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                MenuItem("▶  Resume", onDismiss)
                MenuItem("💾  Quick save", onQuickSave)
                MenuItem("📂  Quick load", onQuickLoad)
                MenuItem("🗂  Save state…", onSave)
                MenuItem("📥  Load state…", onLoad)
                MenuItem("🎯  Cheats…", onCheats)
                MenuItem("📷  Screenshot", onScreenshot)
                MenuItem(if (session.recording.intValue == 1) "⏹  Stop GIF recording" else "🎥  Record GIF (up to 20 s)", onToggleGif)
                Text("Changes below are remembered for this game only", color = Color(0xFF9AA8B8), fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp, top = 8.dp))
                MenuItem(if (settings.linearFilter) "🖼  Filter: Smooth (tap for Sharp)" else "🖼  Filter: Sharp (tap for Smooth)") {
                    onSettingsChange(settings.copy(linearFilter = !settings.linearFilter))
                }
                MenuItem(if (settings.integerScale) "📐  Scale: Integer (tap for Fit)" else "📐  Scale: Fit (tap for Integer)") {
                    onSettingsChange(settings.copy(integerScale = !settings.integerScale))
                }
                MenuItem("✨  Effect: ${EFFECT_NAMES[settings.screenEffect.coerceIn(0, EFFECT_NAMES.size - 1)]}") {
                    onSettingsChange(settings.copy(screenEffect = (settings.screenEffect + 1) % EFFECT_NAMES.size))
                }
                Column(Modifier.padding(horizontal = 12.dp)) {
                    Text("☀  Sun level (solar-sensor games): ${settings.solarLevel}", color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = settings.solarLevel.toFloat(),
                        onValueChange = { onSettingsChange(settings.copy(solarLevel = it.roundToInt())) },
                        valueRange = 0f..255f
                    )
                }
                if (skins.isNotEmpty()) {
                    val currentIndex = skins.indexOfFirst { it.id == settings.skinId }.coerceAtLeast(0)
                    MenuItem("🎨  Skin: ${skins[currentIndex].name} (tap for next)") {
                        onSettingsChange(settings.copy(skinId = skins[(currentIndex + 1) % skins.size].id))
                    }
                }
                MenuItem("✋  Move / resize screen and controls", onEditLayout)
                MenuItem("🎛  Show / hide buttons…", onButtons)
                MenuItem(if (showControls) "🎮  Hide on-screen controls" else "🎮  Show on-screen controls", onToggleControls)
                if (hasGameOverrides) MenuItem("↺  Use global settings for this game", onResetGameSettings)
                MenuItem("🔄  Reset game", onReset)
                MenuItem("🚪  Exit to library", onExit)
            }
        }
    }
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun SlotsDialog(session: EmulatorSession, save: Boolean, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text(if (save) "Save to slot" else "Load from slot", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                for (slot in 1..EmulatorSession.MANUAL_SLOTS) {
                    val time = session.slotTimestamp(slot)
                    val enabled = save || time != null
                    TextButton(onClick = { onPick(slot) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Slot $slot — " + (if (time != null) format.format(Date(time)) else "empty"),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Back") }
            }
        }
    }
}

@Composable
private fun CheatsDialog(
    session: EmulatorSession,
    onDismiss: () -> Unit,
    onImportCheats: ((List<Cheat>) -> Unit) -> Unit,
    toast: (String) -> Unit
) {
    val cheats = remember { mutableStateListOf<Cheat>().apply { addAll(CheatStore.load(session.gameDir)) } }
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    fun commit() {
        CheatStore.save(session.gameDir, cheats)
        session.applyCheats(cheats)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text("Cheats", color = Color.White, fontSize = 18.sp)
                Text("GameShark, Action Replay and CodeBreaker codes", color = Color(0xFF9AA8B8), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                if (cheats.isEmpty()) {
                    Text("No cheats yet for this game.", color = Color(0xFF9AA8B8))
                } else {
                    LazyColumn(Modifier.heightIn(max = 220.dp)) {
                        itemsIndexed(cheats) { index, cheat ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = cheat.enabled, onCheckedChange = {
                                    cheats[index] = cheat.copy(enabled = it)
                                    commit()
                                })
                                Spacer(Modifier.width(8.dp))
                                Text(cheat.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                                TextButton(onClick = { cheats.removeAt(index); commit() }) { Text("Delete") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = code, onValueChange = { code = it },
                    label = { Text("Code(s), e.g. 82003884 0001") }, modifier = Modifier.fillMaxWidth(), minLines = 2
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = {
                        val normalized = CheatStore.normalize(code)
                        if (normalized.isEmpty()) {
                            toast("Enter a code like 82003884 0001")
                        } else {
                            cheats.add(Cheat(name.ifBlank { "Cheat ${cheats.size + 1}" }, normalized, true))
                            val accepted = session.applyCheats(cheats)
                            if (accepted < cheats.size) {
                                cheats.removeAt(cheats.size - 1)
                                session.applyCheats(cheats)
                                toast("That code was not recognised")
                            } else {
                                CheatStore.save(session.gameDir, cheats)
                                name = ""; code = ""
                            }
                        }
                    }) { Text("Add") }
                    TextButton(onClick = {
                        onImportCheats { imported ->
                            cheats.addAll(imported)
                            commit()
                            toast("Imported ${imported.size} cheat(s)")
                        }
                    }) { Text("Import .cht") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            }
        }
    }
}
