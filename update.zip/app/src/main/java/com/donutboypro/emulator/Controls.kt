package com.donutboypro.emulator

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The skin currently applied to the on-screen controls (null = built-in classic look). */
val LocalSkin = compositionLocalOf<LoadedSkin?> { null }

/** A held-down on-screen button. Supports multi-touch because each button tracks its own pointer. */
@Composable
fun PadButton(
    label: String,
    width: Dp,
    height: Dp,
    alpha: Float,
    shape: Shape = CircleShape,
    skinKey: String? = null,
    highlight: Boolean = false,
    onDown: () -> Unit,
    onUp: () -> Unit
) {
    val skin = LocalSkin.current
    var pressed by remember { mutableStateOf(false) }
    val normalImage = if (skinKey != null) skin?.images?.get(skinKey) else null
    val pressedImage = if (skinKey != null) skin?.images?.get(skinKey + "_pressed") else null
    val active = pressed || highlight
    val shownImage = if (active && pressedImage != null) pressedImage else normalImage
    val idleColor = skin?.spec?.buttonColor ?: 0x55FFFFFF
    val downColor = skin?.spec?.pressedColor ?: 0xAAFFFFFF.toInt()
    val labelColor = skin?.spec?.textColor ?: 0xFFFFFFFF.toInt()
    val down by rememberUpdatedState(onDown)
    val up by rememberUpdatedState(onUp)
    Box(
        modifier = Modifier
            .width(width)
            .height(height)
            .alpha(alpha)
            .background(if (shownImage != null) Color.Transparent else Color(if (active) downColor else idleColor), shape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    down()
                    do {
                        val event = awaitPointerEvent()
                        event.changes.forEach { it.consume() }
                    } while (event.changes.any { it.pressed })
                    pressed = false
                    up()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (shownImage != null) {
            Image(
                bitmap = shownImage.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(label, color = Color(labelColor), fontSize = 15.sp)
        }
    }
}

fun roundedShape(dp: Dp): Shape = RoundedCornerShape(dp)

/** Slide-able directional pad with a configurable dead zone and optional diagonal blocking. */
@Composable
fun DPad(
    session: EmulatorSession,
    sizeDp: Dp,
    alpha: Float,
    deadZone: Float,
    noDiagonals: Boolean,
    onPress: () -> Unit
) {
    val press by rememberUpdatedState(onPress)
    val skin = LocalSkin.current
    val dpadImage = skin?.images?.get("dpad")
    Box(
        modifier = Modifier
            .size(sizeDp)
            .alpha(alpha)
            .background(if (dpadImage != null) Color.Transparent else Color(((skin?.spec?.buttonColor ?: 0x55FFFFFF) and 0x00FFFFFF) or 0x33000000), CircleShape)
            .pointerInput(session, deadZone, noDiagonals) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    press()
                    val pointerId = down.id
                    val radius = size.width / 2f
                    val center = Offset(size.width / 2f, size.height / 2f)
                    session.setDpad(dpadMaskFor(down.position, center, radius, deadZone, noDiagonals))
                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == pointerId } ?: event.changes.first()
                        session.setDpad(
                            if (change.pressed) dpadMaskFor(change.position, center, radius, deadZone, noDiagonals) else 0
                        )
                        event.changes.forEach { it.consume() }
                    } while (event.changes.any { it.pressed })
                    session.setDpad(0)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (dpadImage != null) {
            Image(
                bitmap = dpadImage.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize()
            )
        } else {
            Text("✥", color = Color(skin?.spec?.textColor ?: 0xFFFFFFFF.toInt()), fontSize = 34.sp)
        }
    }
}

private fun dpadMaskFor(pos: Offset, center: Offset, radius: Float, deadZone: Float, noDiagonals: Boolean): Int {
    if (radius <= 0f) return 0
    val nx = (pos.x - center.x) / radius
    val ny = (pos.y - center.y) / radius
    var horizontal = 0
    var vertical = 0
    if (nx > deadZone) horizontal = NativeGbaBridge.Key.mask(NativeGbaBridge.Key.RIGHT)
    if (nx < -deadZone) horizontal = NativeGbaBridge.Key.mask(NativeGbaBridge.Key.LEFT)
    if (ny > deadZone) vertical = NativeGbaBridge.Key.mask(NativeGbaBridge.Key.DOWN)
    if (ny < -deadZone) vertical = NativeGbaBridge.Key.mask(NativeGbaBridge.Key.UP)
    if (noDiagonals && horizontal != 0 && vertical != 0) {
        return if (kotlin.math.abs(nx) >= kotlin.math.abs(ny)) horizontal else vertical
    }
    return horizontal or vertical
}
