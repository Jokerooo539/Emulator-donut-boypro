package com.donutboypro.emulator

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject

/** User-chosen position (dp offset from the default spot) and size multiplier for every screen / control group, per orientation. */
class ControlLayout(private val context: Context, private val orientation: String) {
    val offsets = mutableStateMapOf<String, Pair<Float, Float>>()
    val scales = mutableStateMapOf<String, Float>()

    init {
        val raw = prefs().getString(orientation, null)
        if (raw != null) {
            runCatching {
                val o = JSONObject(raw)
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val a = o.getJSONArray(k)
                    offsets[k] = Pair(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
                    if (a.length() > 2) scales[k] = a.getDouble(2).toFloat()
                }
            }
        }
    }

    private fun prefs() = context.getSharedPreferences("donut_boy_layout", Context.MODE_PRIVATE)

    fun get(id: String): Pair<Float, Float> = offsets[id] ?: Pair(0f, 0f)

    fun scale(id: String): Float = scales[id] ?: 1f

    fun setScale(id: String, value: Float) {
        scales[id] = value
        save()
    }

    fun move(id: String, dx: Float, dy: Float) {
        val c = get(id)
        offsets[id] = Pair(c.first + dx, c.second + dy)
    }

    fun save() {
        val o = JSONObject()
        val ids = HashSet<String>()
        ids.addAll(offsets.keys)
        ids.addAll(scales.keys)
        for (id in ids) {
            val pos = get(id)
            o.put(id, JSONArray().put(pos.first.toDouble()).put(pos.second.toDouble()).put(scale(id).toDouble()))
        }
        prefs().edit().putString(orientation, o.toString()).apply()
    }

    fun reset() {
        offsets.clear()
        scales.clear()
        save()
    }
}
