package com.donutboypro.emulator

import android.content.Context
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.mutableIntStateOf
import java.io.File
import java.util.concurrent.locks.LockSupport

/**
 * One running game: owns the native core handle, the emulation thread, audio output,
 * input state, save states, rewind, fast-forward, rumble and motion sensors.
 */
class EmulatorSession(
    private val context: Context,
    private val bridge: NativeGbaBridge,
    private val handle: Long,
    val gameDir: File,
    initialSettings: AppSettings
) {
    @Volatile var settings: AppSettings = initialSettings

    // ----- state visible to the UI -----
    val frameTick = mutableIntStateOf(0)
    val fps = mutableIntStateOf(0)
    @Volatile var fastForward = false
    @Volatile var rewinding = false
    @Volatile var pausedByUser = false
    @Volatile var pausedByLifecycle = false

    // ----- internals -----
    @Volatile private var running = false
    @Volatile private var closed = false
    private var thread: Thread? = null
    private val bitmaps = arrayOf(
        Bitmap.createBitmap(SCREEN_W, SCREEN_H, Bitmap.Config.ARGB_8888),
        Bitmap.createBitmap(SCREEN_W, SCREEN_H, Bitmap.Config.ARGB_8888)
    )
    @Volatile private var shown = 0
    private val pixels = IntArray(SCREEN_W * SCREEN_H)

    private var audio: AudioTrack? = null
    private var audioPlaying = false
    private var audioFactor = 1

    private val inputLock = Any()
    private var touchMask = 0
    private var dpadMask = 0
    private var padMask = 0
    private var stickMask = 0
    private var turboMask = 0

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private var lastBuzz = 0L

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private var sensorsOn = false
    private var accelX = 0f
    private var accelY = 0f
    private var gyroZ = 0f
    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            if (closed) return
            when (event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> { accelX = event.values[0]; accelY = event.values[1] }
                Sensor.TYPE_GYROSCOPE -> gyroZ = event.values[2]
            }
            val k = settings.motionSensitivity
            bridge.setSensors(handle, accelX * k, accelY * k, gyroZ * k)
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    // ----- GIF recording -----
    @Volatile private var gif: GifEncoder? = null
    private var gifStream: java.io.OutputStream? = null
    private var gifFile: File? = null
    private var gifFrames = 0
    val recording = mutableIntStateOf(0)   // 0 = idle, 1 = recording (state so the UI updates)

    /** Starts recording ~30 fps GIF at native size, up to 20 seconds. */
    fun startGif(target: File): Boolean {
        if (gif != null || closed) return false
        return try {
            val stream = java.io.BufferedOutputStream(java.io.FileOutputStream(target), 64 * 1024)
            gifStream = stream
            gifFile = target
            gifFrames = 0
            gif = GifEncoder(stream, SCREEN_W, SCREEN_H, 3)
            recording.intValue = 1
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** Finishes the GIF; returns the file, or null if nothing was recorded. */
    fun stopGif(): File? {
        val g = gif ?: return null
        gif = null
        recording.intValue = 0
        return try {
            synchronized(this) { g.finish() }
            gifStream?.close()
            val f = gifFile
            if (gifFrames > 0) f else { f?.delete(); null }
        } catch (t: Throwable) {
            null
        } finally {
            gifStream = null
            gifFile = null
        }
    }

    /** Pushes the current solar-sensor level / sensitivity to the running game. */
    fun applyLiveSettings() {
        if (!closed) bridge.setSolar(handle, settings.solarLevel)
    }

    private val paused: Boolean get() = pausedByUser || pausedByLifecycle

    fun currentBitmap(): Bitmap = bitmaps[shown]

    /** Copy of the current frame for screenshots. */
    fun snapshot(): Bitmap = currentBitmap().copy(Bitmap.Config.ARGB_8888, false)

    // ----- setup -----

    /** Call on a background thread before [start]: rewind, cheats and auto-load. */
    fun prepare(cheats: List<Cheat>) {
        bridge.setRewindEnabled(handle, settings.rewindEnabled)
        bridge.setSolar(handle, settings.solarLevel)
        applyCheats(cheats)
        if (settings.autoLoadState) {
            val f = statePath(0)
            if (f.exists()) bridge.loadState(handle, f.absolutePath)
        }
    }

    fun start() {
        if (running || closed) return
        running = true
        if (settings.audioEnabled) audio = createAudio(bridge.audioSampleRate(handle))
        if (settings.motionControls) startSensors()
        thread = Thread({ loop() }, "DonutEmulator").also { it.start() }
    }

    /** Stops the thread and destroys the native core. Call on the main thread. */
    fun close(saveAuto: Boolean) {
        if (closed) return
        if (saveAuto) autoSave()
        stopGif()
        closed = true
        running = false
        stopSensors()
        runCatching { audio?.stop() }   // also unblocks a pending audio write
        runCatching { thread?.join(1500) }
        runCatching { audio?.release() }
        audio = null
        // If the thread somehow did not stop, leak the core rather than crash on a use-after-free.
        if (thread?.isAlive != true) bridge.destroy(handle)
    }

    // ----- input -----

    fun setButton(key: Int, down: Boolean) = synchronized(inputLock) {
        touchMask = if (down) touchMask or NativeGbaBridge.Key.mask(key) else touchMask and NativeGbaBridge.Key.mask(key).inv()
    }

    fun setDpad(mask: Int) = synchronized(inputLock) { dpadMask = mask }

    fun setPad(key: Int, down: Boolean) = synchronized(inputLock) {
        padMask = if (down) padMask or NativeGbaBridge.Key.mask(key) else padMask and NativeGbaBridge.Key.mask(key).inv()
    }

    fun setStick(mask: Int) = synchronized(inputLock) { stickMask = mask }

    fun setTurbo(key: Int, down: Boolean) = synchronized(inputLock) {
        turboMask = if (down) turboMask or NativeGbaBridge.Key.mask(key) else turboMask and NativeGbaBridge.Key.mask(key).inv()
    }

    // ----- save states -----

    fun statePath(slot: Int): File = File(gameDir, if (slot == 0) "auto.ss" else "state$slot.ss")

    fun slotTimestamp(slot: Int): Long? = statePath(slot).takeIf { it.exists() }?.lastModified()

    fun saveStateSlot(slot: Int): Boolean {
        if (closed) return false
        return bridge.saveState(handle, statePath(slot).absolutePath)
    }

    fun loadStateSlot(slot: Int): Boolean {
        if (closed) return false
        val f = statePath(slot)
        return f.exists() && bridge.loadState(handle, f.absolutePath)
    }

    fun autoSave() {
        if (settings.autoSaveState && !closed) saveStateSlot(0)
    }

    /** Returns the slot that was written, or -1. */
    fun quickSave(): Int {
        val s = settings
        val slot = if (s.rotateQuickSlots) {
            val latest = latestQuickSlot()
            if (latest == -1) 1 else latest % QUICK_ROTATION_SLOTS + 1
        } else s.quickSlot
        return if (saveStateSlot(slot)) slot else -1
    }

    /** Returns the slot that was loaded, or -1. */
    fun quickLoad(): Int {
        val s = settings
        val slot = if (s.rotateQuickSlots) latestQuickSlot() else s.quickSlot
        return if (slot > 0 && loadStateSlot(slot)) slot else -1
    }

    private fun latestQuickSlot(): Int {
        var best = -1
        var bestTime = 0L
        for (slot in 1..QUICK_ROTATION_SLOTS) {
            val t = slotTimestamp(slot) ?: continue
            if (t >= bestTime) { best = slot; bestTime = t }
        }
        return best
    }

    // ----- cheats / reset -----

    /** Returns how many cheat entries the core accepted. */
    fun applyCheats(cheats: List<Cheat>): Int {
        if (closed) return 0
        val names = Array(cheats.size) { cheats[it].name }
        val codes = Array(cheats.size) { CheatStore.normalize(cheats[it].code) }
        val enabled = BooleanArray(cheats.size) { cheats[it].enabled }
        return bridge.setCheats(handle, names, codes, enabled)
    }

    fun reset() {
        if (!closed) bridge.reset(handle)
    }

    // ----- emulation loop -----

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val baseFrameNs = 1_000_000_000.0 / GBA_FPS
        val audioBuf = ShortArray(AUDIO_BUFFER_FRAMES * 2)
        val baseRate = bridge.audioSampleRate(handle)
        var nextDeadline = System.nanoTime()
        var frameCount = 0L
        var lastKeys = -1
        var fpsStart = System.nanoTime()
        var fpsFrames = 0
        var lastAutoSave = System.nanoTime()

        while (running) {
            if (paused) {
                if (audioPlaying) {
                    runCatching { audio?.pause(); audio?.flush() }
                    audioPlaying = false
                }
                try { Thread.sleep(20) } catch (e: InterruptedException) { /* ignore */ }
                nextDeadline = System.nanoTime()
                continue
            }
            val s = settings
            val a = audio
            if (a != null && !audioPlaying) {
                // Start with ~50 ms of silence so the first frames cannot underrun and crackle.
                runCatching { a.write(ShortArray((baseRate / 20) * 2), 0, (baseRate / 20) * 2) }
                runCatching { a.play() }
                audioPlaying = true
            }

            // input (with turbo)
            var held = 0
            var turbo = 0
            synchronized(inputLock) {
                held = touchMask or dpadMask or padMask or stickMask
                turbo = turboMask
            }
            var mask = held
            if (turbo != 0) {
                val half = (30 / s.turboClicksPerSecond.coerceIn(1, 30)).coerceAtLeast(1)
                if ((frameCount / half) % 2L == 0L) mask = mask or turbo
            }
            if (mask != lastKeys) {
                bridge.setKeys(handle, mask)
                lastKeys = mask
            }

            val isRewinding = rewinding && s.rewindEnabled
            val ff = fastForward && !isRewinding
            val speed = if (ff) s.fastForwardSpeed.coerceIn(2, 8) else 1
            // While fast-forwarding, every frame's sound is played back faster (higher pitch) so it stays in sync.
            val wantAudio = a != null && !isRewinding && (!ff || s.ffSound)
            val factor = if (ff && s.ffSound) speed else 1
            if (a != null && factor != audioFactor) {
                runCatching { a.setPlaybackRate(baseRate * factor) }
                audioFactor = factor
            }
            for (i in 0 until speed) {
                val last = i == speed - 1
                val r = bridge.runFrame(handle, if (last) pixels else null, if (wantAudio) audioBuf else null, isRewinding)
                if (r < 0) { running = false; break }
                if (a != null && wantAudio && r > 0) {
                    runCatching { a.write(audioBuf, 0, r * 2) }
                }
            }
            if (!running) break
            frameCount++

            // publish video
            val next = 1 - shown
            bitmaps[next].setPixels(pixels, 0, SCREEN_W, 0, 0, SCREEN_W, SCREEN_H)
            shown = next
            frameTick.intValue = frameTick.intValue + 1

            // GIF capture (every second frame ~ 30 fps)
            val g = gif
            if (g != null && !ff && frameCount % 2L == 0L) {
                synchronized(this) { g.addFrame(pixels) }
                gifFrames++
                if (gifFrames >= MAX_GIF_FRAMES) stopGif()
            }

            // (audio is written right after each emulated frame above; the blocking write keeps us in step with the speaker)

            // rumble
            if (s.rumble && bridge.rumbleLevel(handle) > 0.5f) buzz(40)

            // timed auto save
            val nowNs = System.nanoTime()
            if (s.autoSaveState && s.timedAutoSaveMinutes > 0 &&
                nowNs - lastAutoSave > s.timedAutoSaveMinutes * 60_000_000_000L) {
                saveStateSlot(0)
                lastAutoSave = nowNs
            }

            // fps counter
            fpsFrames++
            if (nowNs - fpsStart >= 1_000_000_000L) {
                fps.intValue = fpsFrames
                fpsFrames = 0
                fpsStart = nowNs
            }

            // pacing
            nextDeadline += (baseFrameNs / speed).toLong()
            val remaining = nextDeadline - System.nanoTime()
            if (remaining > 0) LockSupport.parkNanos(remaining)
            else if (remaining < -100_000_000L) nextDeadline = System.nanoTime()
        }
    }

    // ----- helpers -----

    @Suppress("DEPRECATION")
    private fun createAudio(rate: Int): AudioTrack? = try {
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) {
            null
        } else {
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 3, (rate / 8) * 4), AudioTrack.MODE_STREAM
            )
            if (track.state == AudioTrack.STATE_INITIALIZED) track else { track.release(); null }
        }
    } catch (t: Throwable) {
        null
    }

    @Suppress("DEPRECATION")
    private fun buzz(ms: Long) {
        val now = System.currentTimeMillis()
        if (now - lastBuzz < ms) return
        lastBuzz = now
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        else v.vibrate(ms)
    }

    private fun startSensors() {
        val sm = sensorManager ?: return
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        if (acc != null) sm.registerListener(sensorListener, acc, SensorManager.SENSOR_DELAY_GAME)
        if (gyro != null) sm.registerListener(sensorListener, gyro, SensorManager.SENSOR_DELAY_GAME)
        sensorsOn = acc != null || gyro != null
    }

    private fun stopSensors() {
        if (sensorsOn) sensorManager?.unregisterListener(sensorListener)
        sensorsOn = false
    }

    companion object {
        const val SCREEN_W = 240
        const val SCREEN_H = 160
        const val GBA_FPS = 59.7275
        const val AUDIO_BUFFER_FRAMES = 8192
        const val QUICK_ROTATION_SLOTS = 4
        const val MANUAL_SLOTS = 8
        const val MAX_GIF_FRAMES = 600
    }
}
