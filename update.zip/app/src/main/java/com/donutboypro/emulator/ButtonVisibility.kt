package com.donutboypro.emulator

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Optional on-screen buttons the user can switch off (the menu button is always kept so you can never lock yourself out). */
val OPTIONAL_BUTTONS = listOf(
    "turboA" to "Turbo A  (A⚡)",
    "turboB" to "Turbo B  (B⚡)",
    "macro" to "A+B button",
    "rewind" to "Rewind  (⏪)",
    "ff" to "Fast-forward  (⏩)",
    "qsave" to "Quick save  (💾)",
    "qload" to "Quick load  (📂)"
)

@Composable
fun ButtonVisibilityList(settings: AppSettings, onChange: (AppSettings) -> Unit) {
    Column {
        for (item in OPTIONAL_BUTTONS) {
            val id = item.first
            val label = item.second
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = settings.isShown(id), onCheckedChange = { onChange(settings.withShown(id, it)) })
            }
        }
    }
}
