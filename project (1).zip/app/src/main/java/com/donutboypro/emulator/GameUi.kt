package com.donutboypro.emulator

import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.text.DateFormat
import java.util.Date
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

private enum class GameDialog { Menu, SaveSlots, LoadSlots, Cheats }
private enum class Confirm { QuickSave, QuickLoad, Reset }

private val EFFECT_NAMES = listOf("Off", "Scanlines", "LCD grid", "GBA colours", "Scanlines + GBA colours")

private val GBA_COLOR_MATRIX = ColorMatrix(
    floatArrayOf(
        0.86f, 0.10f, 0.04f, 0f, 6f,
        0.05f, 0.90f, 0.05f, 0f, 6f,
        0.04f, 0.10f, 0.86f, 0f, 6f,
        0f, 0f, 0f, 1f, 0f
    )
)

@Composable
fun GameScreen(
    session: EmulatorSession,
    gameName: String,
    settings: AppSettings,
    hasGameOverrides: Boolean,
    onSettingsChange: (AppSettings) -> Unit,
    onResetGameSettings: () -> Unit,
    onExit: () -> Unit,
    onScreenshot: (android.graphics.Bitmap) -> Unit,
    onToggleGif: () -> Unit,
    onImportCheats: ((List<Cheat>) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    var dialog by remember { mutableStateOf<GameDialog?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var fastForward by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    fun openDialog(d: GameDialog?) {
        dialog = d
        session.pausedByUser = d != null
    }
    fun doQuickSave() {
        val slot = session.quickSave()
        toast(if (slot > 0) "State saved (slot $slot)" else "Could not save state")
    }
    fun doQuickLoad() {
        val slot = session.quickLoad()
        toast(if (slot > 0) "State loaded (slot $slot)" else "No quick save found")
    }
    val haptic: () -> Unit = {
        if (settings.vibrateButtons) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }
    val onQuickSave: () -> Unit = {
        if (settings.confirmQuickSave) { confirm = Confirm.QuickSave } else { doQuickSave() }
    }
    val onQuickLoad: () -> Unit = {
        if (settings.confirmQuickLoad) { confirm = Confirm.QuickLoad } else { doQuickLoad() }
    }

    BackHandler {
        if (editing) {
            editing = false
        } else if (dialog == null) {
            openDialog(GameDialog.Menu)
        } else {
            openDialog(null)
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val landscape = maxWidth > maxHeight
        val layout = remember(landscape) { ControlLayout(context, if (landscape) "land" else "port") }
        if (landscape) {
            GameCanvas(session, settings, Modifier.fillMaxSize())
            Text(
                if (session.recording.intValue == 1) "● REC" else "",
                color = Color(0xFFFF5252), fontSize = 12.sp, modifier = Modifier.padding(8.dp)
            )
            if (showControls || editing) {
                ControlsOverlay(
                    Modifier.fillMaxSize().padding(12.dp), true, session, settings, layout, editing,
                    fastForward, { fastForward = it }, { openDialog(GameDialog.Menu) }, onQuickSave, onQuickLoad, haptic
                )
            } else {
                TextButton(onClick = { openDialog(GameDialog.Menu) }, modifier = Modifier.align(Alignment.TopCenter)) { Text("☰", color = Color.White) }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Box(Modifier.fillMaxWidth().aspectRatio(240f / 160f)) {
                    GameCanvas(session, settings, Modifier.fillMaxSize())
                    if (settings.showFps) {
                        Text("${session.fps.intValue} fps", color = Color(0xFF72E0C2), fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                    }
                    if (session.recording.intValue == 1) {
                        Text("● REC", color = Color(0xFFFF5252), fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd).padding(8.dp))
                    }
                }
                Text(gameName, color = Color(0xFF9AA8B8), fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    if (showControls || editing) {
                        ControlsOverlay(
                            Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp), false, session, settings, layout, editing,
                            fastForward, { fastForward = it }, { openDialog(GameDialog.Menu) }, onQuickSave, onQuickLoad, haptic
                        )
                    } else {
                        TextButton(onClick = { openDialog(GameDialog.Menu) }, modifier = Modifier.align(Alignment.Center)) { Text("☰ Menu") }
                    }
                }
            }
        }

        if (editing) {
            Surface(
                modifier = Modifier.align(Alignment.Center).padding(16.dp),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = Color(0xEE1B2430)
            ) {
                Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Drag the controls where you want them", color = Color.White, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { onSettingsChange(settings.copy(controlsScale = (settings.controlsScale - 0.1f).coerceAtLeast(0.6f))) }) { Text("Smaller") }
                        TextButton(onClick = { onSettingsChange(settings.copy(controlsScale = (settings.controlsScale + 0.1f).coerceAtMost(1.5f))) }) { Text("Bigger") }
                        TextButton(onClick = { layout.reset() }) { Text("Reset") }
                        Button(onClick = { editing = false }) { Text("Done") }
                    }
                }
            }
        }
    }

    // Keep the session's fast-forward flag in step with the toggle.
    LaunchedEffect(fastForward) { session.fastForward = fastForward }

    when (dialog) {
        GameDialog.Menu -> MenuDialog(
            session = session, settings = settings, showControls = showControls, hasGameOverrides = hasGameOverrides,
            onToggleControls = { showControls = !showControls },
            onSettingsChange = onSettingsChange,
            onResetGameSettings = onResetGameSettings,
            onDismiss = { openDialog(null) },
            onSave = { openDialog(GameDialog.SaveSlots) },
            onLoad = { openDialog(GameDialog.LoadSlots) },
            onCheats = { openDialog(GameDialog.Cheats) },
            onQuickSave = { openDialog(null); onQuickSave() },
            onQuickLoad = { openDialog(null); onQuickLoad() },
            onScreenshot = { openDialog(null); onScreenshot(session.snapshot()) },
            onToggleGif = { openDialog(null); onToggleGif() },
            onEditLayout = { openDialog(null); showControls = true; editing = true },
            onReset = { openDialog(null); confirm = Confirm.Reset },
            onExit = { openDialog(null); onExit() }
        )
        GameDialog.SaveSlots -> SlotsDialog(session, save = true, onDismiss = { openDialog(GameDialog.Menu) },
            onPick = { slot ->
                toast(if (session.saveStateSlot(slot)) "Saved to slot $slot" else "Could not save state")
                openDialog(null)
            })
        GameDialog.LoadSlots -> SlotsDialog(session, save = false, onDismiss = { openDialog(GameDialog.Menu) },
            onPick = { slot ->
                toast(if (session.loadStateSlot(slot)) "Loaded slot $slot" else "Slot $slot is empty")
                openDialog(null)
            })
        GameDialog.Cheats -> CheatsDialog(session, onDismiss = { openDialog(null) }, onImportCheats = onImportCheats, toast = ::toast)
        null -> {}
    }

    confirm?.let { action ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(when (action) { Confirm.QuickSave -> "Quick save?"; Confirm.QuickLoad -> "Quick load?"; Confirm.Reset -> "Reset game?" }) },
            text = { Text(when (action) {
                Confirm.QuickSave -> "This overwrites your quick-save slot."
                Confirm.QuickLoad -> "Unsaved progress will be lost."
                Confirm.Reset -> "The game restarts. Battery saves are kept."
            }) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    when (action) {
                        Confirm.QuickSave -> doQuickSave()
                        Confirm.QuickLoad -> doQuickLoad()
                        Confirm.Reset -> session.reset()
                    }
                }) { Text("Yes") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun GameCanvas(session: EmulatorSession, settings: AppSettings, modifier: Modifier) {
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE")
        val tick = session.frameTick.intValue   // reading this here redraws the canvas every new frame
        val image = session.currentBitmap().asImageBitmap()
        val scale = min(size.width / EmulatorSession.SCREEN_W, size.height / EmulatorSession.SCREEN_H)
        val used = if (settings.integerScale && scale >= 1f) floor(scale) else scale
        val w = (EmulatorSession.SCREEN_W * used).roundToInt()
        val h = (EmulatorSession.SCREEN_H * used).roundToInt()
        val x = ((size.width - w) / 2f).roundToInt()
        val y = ((size.height - h) / 2f).roundToInt()
        val effect = settings.screenEffect
        drawImage(
            image = image,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(EmulatorSession.SCREEN_W, EmulatorSession.SCREEN_H),
            dstOffset = IntOffset(x, y),
            dstSize = IntSize(w, h),
            filterQuality = if (settings.linearFilter) FilterQuality.Low else FilterQuality.None,
            colorFilter = if (effect == 3 || effect == 4) ColorFilter.colorMatrix(GBA_COLOR_MATRIX) else null
        )
        if ((effect == 1 || effect == 4) && used >= 2f) {
            // scanlines: a darker band at the bottom of every source row
            val thickness = used * 0.35f
            for (r in 0 until EmulatorSession.SCREEN_H) {
                val ly = y + (r + 1) * used - thickness / 2f
                drawLine(Color(0x66000000), Offset(x.toFloat(), ly), Offset((x + w).toFloat(), ly), strokeWidth = thickness)
            }
        }
        if (effect == 2 && used >= 3f) {
            // LCD grid: faint lines between pixels
            val lineColor = Color(0x30000000)
            for (c in 1 until EmulatorSession.SCREEN_W) {
                val lx = x + c * used
                drawLine(lineColor, Offset(lx, y.toFloat()), Offset(lx, (y + h).toFloat()), strokeWidth = 1f)
            }
            for (r in 1 until EmulatorSession.SCREEN_H) {
                val ly = y + r * used
                drawLine(lineColor, Offset(x.toFloat(), ly), Offset((x + w).toFloat(), ly), strokeWidth = 1f)
            }
        }
    }
}

/** A group of controls that can be dragged to a new place while [editing]. */
@Composable
private fun BoxScope.Movable(
    id: String, align: Alignment, baseY: Dp, layout: ControlLayout, scale: Float, editing: Boolean,
    content: @Composable () -> Unit
) {
    val off = layout.get(id)
    Box(
        Modifier
            .align(align)
            .offset { IntOffset(off.first.dp.roundToPx(), (off.second + baseY.value).dp.roundToPx()) }
            .graphicsLayer { scaleX = scale; scaleY = scale }
    ) {
        content()
        if (editing) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(Color(0x3372E0C2))
                    .border(1.dp, Color(0xFF72E0C2))
                    .pointerInput(id, scale) {
                        detectDragGestures(onDragEnd = { layout.save() }) { change, drag ->
                            change.consume()
                            layout.move(id, drag.x * scale / density, drag.y * scale / density)
                        }
                    }
            )
        }
    }
}

@Composable
private fun ControlsOverlay(
    modifier: Modifier,
    landscape: Boolean,
    session: EmulatorSession,
    settings: AppSettings,
    layout: ControlLayout,
    editing: Boolean,
    fastForward: Boolean,
    onFastForward: (Boolean) -> Unit,
    onMenu: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit,
    haptic: () -> Unit
) {
    val alpha = settings.controlsOpacity
    val s = settings.controlsScale
    val shoulderY = if (landscape) 0.dp else 46.dp
    val padY = if (landscape) 0.dp else 20.dp
    Box(modifier) {
        Movable("util", Alignment.TopCenter, 0.dp, layout, s, editing) {
            UtilityRow(session, settings, fastForward, onFastForward, onMenu, onQuickSave, onQuickLoad)
        }
        Movable("l", Alignment.TopStart, shoulderY, layout, s, editing) {
            ShoulderButton("L", NativeGbaBridge.Key.L, session, alpha, haptic)
        }
        Movable("r", Alignment.TopEnd, shoulderY, layout, s, editing) {
            ShoulderButton("R", NativeGbaBridge.Key.R, session, alpha, haptic)
        }
        Movable("dpad", if (landscape) Alignment.BottomStart else Alignment.CenterStart, padY, layout, s, editing) {
            DPad(session, 140.dp, alpha, settings.dpadDeadZone, settings.disableDiagonals, haptic)
        }
        Movable("action", if (landscape) Alignment.BottomEnd else Alignment.CenterEnd, padY, layout, s, editing) {
            ActionCluster(session, alpha, haptic)
        }
        Movable("startselect", Alignment.BottomCenter, 0.dp, layout, s, editing) {
            StartSelectRow(session, alpha, haptic)
        }
    }
}

@Composable
private fun ShoulderButton(label: String, key: Int, session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    PadButton(label, 84.dp, 40.dp, alpha, roundedShape(14.dp),
        onDown = { haptic(); session.setButton(key, true) },
        onUp = { session.setButton(key, false) })
}

@Composable
private fun StartSelectRow(session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        PadButton("SELECT", 78.dp, 32.dp, alpha, roundedShape(12.dp),
            onDown = { haptic(); session.setButton(NativeGbaBridge.Key.SELECT, true) },
            onUp = { session.setButton(NativeGbaBridge.Key.SELECT, false) })
        PadButton("START", 78.dp, 32.dp, alpha, roundedShape(12.dp),
            onDown = { haptic(); session.setButton(NativeGbaBridge.Key.START, true) },
            onUp = { session.setButton(NativeGbaBridge.Key.START, false) })
    }
}

@Composable
private fun ActionCluster(session: EmulatorSession, alpha: Float, haptic: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            // Turbo buttons: hold to auto-repeat
            PadButton("B⚡", 44.dp, 34.dp, alpha * 0.8f,
                onDown = { haptic(); session.setTurbo(NativeGbaBridge.Key.B, true) },
                onUp = { session.setTurbo(NativeGbaBridge.Key.B, false) })
            // Macro button: presses A and B together
            PadButton("A+B", 50.dp, 38.dp, alpha * 0.8f,
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.A, true); session.setButton(NativeGbaBridge.Key.B, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.A, false); session.setButton(NativeGbaBridge.Key.B, false) })
            PadButton("A⚡", 44.dp, 34.dp, alpha * 0.8f,
                onDown = { haptic(); session.setTurbo(NativeGbaBridge.Key.A, true) },
                onUp = { session.setTurbo(NativeGbaBridge.Key.A, false) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            PadButton("B", 64.dp, 64.dp, alpha,
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.B, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.B, false) })
            PadButton("A", 72.dp, 72.dp, alpha,
                onDown = { haptic(); session.setButton(NativeGbaBridge.Key.A, true) },
                onUp = { session.setButton(NativeGbaBridge.Key.A, false) })
        }
    }
}

@Composable
private fun UtilityRow(
    session: EmulatorSession,
    settings: AppSettings,
    fastForward: Boolean,
    onFastForward: (Boolean) -> Unit,
    onMenu: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onMenu, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("☰", color = Color.White, fontSize = 18.sp) }
        if (settings.rewindEnabled) {
            PadButton("⏪", 44.dp, 34.dp, 0.9f, roundedShape(10.dp),
                onDown = { session.rewinding = true },
                onUp = { session.rewinding = false })
        }
        FilterChip(
            selected = fastForward,
            onClick = { onFastForward(!fastForward) },
            label = { Text("⏩ ${settings.fastForwardSpeed}x", fontSize = 12.sp) }
        )
        TextButton(onClick = onQuickSave, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("💾", fontSize = 18.sp) }
        TextButton(onClick = onQuickLoad, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("📂", fontSize = 18.sp) }
    }
}

@Composable
private fun MenuDialog(
    session: EmulatorSession,
    settings: AppSettings,
    showControls: Boolean,
    hasGameOverrides: Boolean,
    onToggleControls: () -> Unit,
    onSettingsChange: (AppSettings) -> Unit,
    onResetGameSettings: () -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    onLoad: () -> Unit,
    onCheats: () -> Unit,
    onQuickSave: () -> Unit,
    onQuickLoad: () -> Unit,
    onScreenshot: () -> Unit,
    onToggleGif: () -> Unit,
    onEditLayout: () -> Unit,
    onReset: () -> Unit,
    onExit: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                MenuItem("▶  Resume", onDismiss)
                MenuItem("💾  Quick save", onQuickSave)
                MenuItem("📂  Quick load", onQuickLoad)
                MenuItem("🗂  Save state…", onSave)
                MenuItem("📥  Load state…", onLoad)
                MenuItem("🎯  Cheats…", onCheats)
                MenuItem("📷  Screenshot", onScreenshot)
                MenuItem(if (session.recording.intValue == 1) "⏹  Stop GIF recording" else "🎥  Record GIF (up to 20 s)", onToggleGif)
                Text("Changes below are remembered for this game only", color = Color(0xFF9AA8B8), fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp, top = 8.dp))
                MenuItem(if (settings.linearFilter) "🖼  Filter: Smooth (tap for Sharp)" else "🖼  Filter: Sharp (tap for Smooth)") {
                    onSettingsChange(settings.copy(linearFilter = !settings.linearFilter))
                }
                MenuItem(if (settings.integerScale) "📐  Scale: Integer (tap for Fit)" else "📐  Scale: Fit (tap for Integer)") {
                    onSettingsChange(settings.copy(integerScale = !settings.integerScale))
                }
                MenuItem("✨  Effect: ${EFFECT_NAMES[settings.screenEffect.coerceIn(0, EFFECT_NAMES.size - 1)]}") {
                    onSettingsChange(settings.copy(screenEffect = (settings.screenEffect + 1) % EFFECT_NAMES.size))
                }
                Column(Modifier.padding(horizontal = 12.dp)) {
                    Text("☀  Sun level (solar-sensor games): ${settings.solarLevel}", color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = settings.solarLevel.toFloat(),
                        onValueChange = { onSettingsChange(settings.copy(solarLevel = it.roundToInt())) },
                        valueRange = 0f..255f
                    )
                }
                MenuItem("✋  Move / resize on-screen controls", onEditLayout)
                MenuItem(if (showControls) "🎮  Hide on-screen controls" else "🎮  Show on-screen controls", onToggleControls)
                if (hasGameOverrides) MenuItem("↺  Use global settings for this game", onResetGameSettings)
                MenuItem("🔄  Reset game", onReset)
                MenuItem("🚪  Exit to library", onExit)
            }
        }
    }
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun SlotsDialog(session: EmulatorSession, save: Boolean, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text(if (save) "Save to slot" else "Load from slot", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                for (slot in 1..EmulatorSession.MANUAL_SLOTS) {
                    val time = session.slotTimestamp(slot)
                    val enabled = save || time != null
                    TextButton(onClick = { onPick(slot) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Slot $slot — " + (if (time != null) format.format(Date(time)) else "empty"),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Back") }
            }
        }
    }
}

@Composable
private fun CheatsDialog(
    session: EmulatorSession,
    onDismiss: () -> Unit,
    onImportCheats: ((List<Cheat>) -> Unit) -> Unit,
    toast: (String) -> Unit
) {
    val cheats = remember { mutableStateListOf<Cheat>().apply { addAll(CheatStore.load(session.gameDir)) } }
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }

    fun commit() {
        CheatStore.save(session.gameDir, cheats)
        session.applyCheats(cheats)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), color = Color(0xFF1B2430)) {
            Column(Modifier.padding(16.dp)) {
                Text("Cheats", color = Color.White, fontSize = 18.sp)
                Text("GameShark, Action Replay and CodeBreaker codes", color = Color(0xFF9AA8B8), fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                if (cheats.isEmpty()) {
                    Text("No cheats yet for this game.", color = Color(0xFF9AA8B8))
                } else {
                    LazyColumn(Modifier.heightIn(max = 220.dp)) {
                        itemsIndexed(cheats) { index, cheat ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = cheat.enabled, onCheckedChange = {
                                    cheats[index] = cheat.copy(enabled = it)
                                    commit()
                                })
                                Spacer(Modifier.width(8.dp))
                                Text(cheat.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                                TextButton(onClick = { cheats.removeAt(index); commit() }) { Text("Delete") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = code, onValueChange = { code = it },
                    label = { Text("Code(s), e.g. 82003884 0001") }, modifier = Modifier.fillMaxWidth(), minLines = 2
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = {
                        val normalized = CheatStore.normalize(code)
                        if (normalized.isEmpty()) {
                            toast("Enter a code like 82003884 0001")
                        } else {
                            cheats.add(Cheat(name.ifBlank { "Cheat ${cheats.size + 1}" }, normalized, true))
                            val accepted = session.applyCheats(cheats)
                            if (accepted < cheats.size) {
                                cheats.removeAt(cheats.size - 1)
                                session.applyCheats(cheats)
                                toast("That code was not recognised")
                            } else {
                                CheatStore.save(session.gameDir, cheats)
                                name = ""; code = ""
                            }
                        }
                    }) { Text("Add") }
                    TextButton(onClick = {
                        onImportCheats { imported ->
                            cheats.addAll(imported)
                            commit()
                            toast("Imported ${imported.size} cheat(s)")
                        }
                    }) { Text("Import .cht") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            }
        }
    }
}
