package com.donutboypro.emulator

import java.io.OutputStream

/**
 * Small streaming GIF writer (fixed 216-colour palette, no dithering). Frames are written as they are added,
 * so recording does not need to keep frames in memory. Adapted from the classic LZW algorithm used by GIF encoders.
 */
class GifEncoder(private val out: OutputStream, private val width: Int, private val height: Int, private val delayCs: Int) {
    private var headerWritten = false
    private val indexed = ByteArray(width * height)

    // LZW state
    private val htab = IntArray(HSIZE)
    private val codetab = IntArray(HSIZE)
    private var nBits = 0
    private var maxCode = 0
    private var freeEnt = 0
    private var clearFlg = false
    private var curAccum = 0
    private var curBits = 0
    private val accum = ByteArray(256)
    private var aCount = 0
    private var gInitBits = 9
    private var clearCode = 256
    private var eofCode = 257
    private var pixIndex = 0

    fun addFrame(argb: IntArray) {
        if (!headerWritten) writeHeader()
        for (i in indexed.indices) {
            val c = argb[i]
            val r = (((c shr 16) and 0xFF) * 5 + 127) / 255
            val g = (((c shr 8) and 0xFF) * 5 + 127) / 255
            val b = ((c and 0xFF) * 5 + 127) / 255
            indexed[i] = (r * 36 + g * 6 + b).toByte()
        }
        // Graphic control extension (delay, no transparency)
        out.write(byteArrayOf(0x21, 0xF9.toByte(), 0x04, 0x04, (delayCs and 0xFF).toByte(), ((delayCs shr 8) and 0xFF).toByte(), 0x00, 0x00))
        // Image descriptor
        out.write(0x2C)
        writeShort(0); writeShort(0); writeShort(width); writeShort(height)
        out.write(0x00)
        out.write(8) // LZW minimum code size
        pixIndex = 0
        compress(9)
        out.write(0)
    }

    fun finish() {
        if (!headerWritten) writeHeader()
        out.write(0x3B)
        out.flush()
    }

    private fun writeHeader() {
        headerWritten = true
        out.write("GIF89a".toByteArray(Charsets.US_ASCII))
        writeShort(width); writeShort(height)
        out.write(0xF7) // global colour table, 8 bits per channel, 256 entries
        out.write(0); out.write(0)
        val palette = ByteArray(256 * 3)
        for (r in 0..5) for (g in 0..5) for (b in 0..5) {
            val idx = (r * 36 + g * 6 + b) * 3
            palette[idx] = (r * 51).toByte()
            palette[idx + 1] = (g * 51).toByte()
            palette[idx + 2] = (b * 51).toByte()
        }
        out.write(palette)
        // Looping extension (loop forever)
        out.write(byteArrayOf(0x21, 0xFF.toByte(), 0x0B))
        out.write("NETSCAPE2.0".toByteArray(Charsets.US_ASCII))
        out.write(byteArrayOf(0x03, 0x01, 0x00, 0x00, 0x00))
    }

    private fun writeShort(v: Int) {
        out.write(v and 0xFF)
        out.write((v shr 8) and 0xFF)
    }

    private fun maxCodeFor(bits: Int) = (1 shl bits) - 1

    private fun compress(initBits: Int) {
        gInitBits = initBits
        clearFlg = false
        nBits = gInitBits
        maxCode = maxCodeFor(nBits)
        clearCode = 1 shl (initBits - 1)
        eofCode = clearCode + 1
        freeEnt = clearCode + 2
        aCount = 0
        curAccum = 0
        curBits = 0

        var ent = nextPixel()
        var hshift = 0
        var fcode = HSIZE
        while (fcode < 65536) { ++hshift; fcode *= 2 }
        hshift = 8 - hshift
        clHash()
        output(clearCode)

        outer@ while (true) {
            val c = nextPixel()
            if (c == -1) break
            fcode = (c shl BITS) + ent
            var i = (c shl hshift) xor ent
            if (htab[i] == fcode) {
                ent = codetab[i]
                continue
            } else if (htab[i] >= 0) {
                var disp = HSIZE - i
                if (i == 0) disp = 1
                do {
                    i -= disp
                    if (i < 0) i += HSIZE
                    if (htab[i] == fcode) {
                        ent = codetab[i]
                        continue@outer
                    }
                } while (htab[i] >= 0)
            }
            output(ent)
            ent = c
            if (freeEnt < MAXMAXCODE) {
                codetab[i] = freeEnt++
                htab[i] = fcode
            } else {
                clBlock()
            }
        }
        output(ent)
        output(eofCode)
    }

    private fun nextPixel(): Int = if (pixIndex < indexed.size) (indexed[pixIndex++].toInt() and 0xFF) else -1

    private fun clHash() { java.util.Arrays.fill(htab, -1) }

    private fun clBlock() {
        clHash()
        freeEnt = clearCode + 2
        clearFlg = true
        output(clearCode)
    }

    private fun output(code: Int) {
        curAccum = if (curBits > 0) (curAccum and MASKS[curBits]) or (code shl curBits) else code
        curBits += nBits
        while (curBits >= 8) {
            charOut(curAccum and 0xFF)
            curAccum = curAccum shr 8
            curBits -= 8
        }
        if (freeEnt > maxCode || clearFlg) {
            if (clearFlg) {
                nBits = gInitBits
                maxCode = maxCodeFor(nBits)
                clearFlg = false
            } else {
                ++nBits
                maxCode = if (nBits == BITS) MAXMAXCODE else maxCodeFor(nBits)
            }
        }
        if (code == eofCode) {
            while (curBits > 0) {
                charOut(curAccum and 0xFF)
                curAccum = curAccum shr 8
                curBits -= 8
            }
            flushChar()
        }
    }

    private fun charOut(c: Int) {
        accum[aCount++] = c.toByte()
        if (aCount >= 254) flushChar()
    }

    private fun flushChar() {
        if (aCount > 0) {
            out.write(aCount)
            out.write(accum, 0, aCount)
            aCount = 0
        }
    }

    companion object {
        private const val BITS = 12
        private const val HSIZE = 5003
        private const val MAXMAXCODE = 1 shl BITS
        private val MASKS = intArrayOf(
            0x0000, 0x0001, 0x0003, 0x0007, 0x000F, 0x001F, 0x003F, 0x007F, 0x00FF,
            0x01FF, 0x03FF, 0x07FF, 0x0FFF, 0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF
        )
    }
}
