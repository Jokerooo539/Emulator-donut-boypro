package com.donutboypro.emulator

import android.content.Context

/** All user-adjustable options. Stored in SharedPreferences; a copy is handed to each running session. */
data class AppSettings(
    val audioEnabled: Boolean = true,
    val vibrateButtons: Boolean = true,
    val rumble: Boolean = true,
    val motionControls: Boolean = false,
    val linearFilter: Boolean = false,
    val integerScale: Boolean = false,
    val controlsOpacity: Float = 0.85f,
    val dpadDeadZone: Float = 0.2f,
    val disableDiagonals: Boolean = false,
    val turboClicksPerSecond: Int = 10,
    val fastForwardSpeed: Int = 3,
    val rewindEnabled: Boolean = true,
    val autoSaveState: Boolean = true,
    val autoLoadState: Boolean = true,
    val timedAutoSaveMinutes: Int = 0,
    val rotateQuickSlots: Boolean = false,
    val quickSlot: Int = 1,
    val confirmQuickSave: Boolean = false,
    val confirmQuickLoad: Boolean = false,
    val loadLastGameOnStartup: Boolean = false,
    val showFps: Boolean = false,
    val screenEffect: Int = 0,          // 0 none, 1 scanlines, 2 LCD grid, 3 GBA LCD colours, 4 scanlines + GBA colours
    val controlsScale: Float = 1f,
    val solarLevel: Int = 80,           // 0-255, solar-sensor games (e.g. Boktai)
    val motionSensitivity: Float = 1f,
    val useCustomBios: Boolean = false
)

object SettingsStore {
    private const val FILE = "donut_boy_settings"

    fun load(context: Context): AppSettings {
        val p = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = AppSettings()
        return AppSettings(
            audioEnabled = p.getBoolean("audioEnabled", d.audioEnabled),
            vibrateButtons = p.getBoolean("vibrateButtons", d.vibrateButtons),
            rumble = p.getBoolean("rumble", d.rumble),
            motionControls = p.getBoolean("motionControls", d.motionControls),
            linearFilter = p.getBoolean("linearFilter", d.linearFilter),
            integerScale = p.getBoolean("integerScale", d.integerScale),
            controlsOpacity = p.getFloat("controlsOpacity", d.controlsOpacity),
            dpadDeadZone = p.getFloat("dpadDeadZone", d.dpadDeadZone),
            disableDiagonals = p.getBoolean("disableDiagonals", d.disableDiagonals),
            turboClicksPerSecond = p.getInt("turboClicksPerSecond", d.turboClicksPerSecond),
            fastForwardSpeed = p.getInt("fastForwardSpeed", d.fastForwardSpeed),
            rewindEnabled = p.getBoolean("rewindEnabled", d.rewindEnabled),
            autoSaveState = p.getBoolean("autoSaveState", d.autoSaveState),
            autoLoadState = p.getBoolean("autoLoadState", d.autoLoadState),
            timedAutoSaveMinutes = p.getInt("timedAutoSaveMinutes", d.timedAutoSaveMinutes),
            rotateQuickSlots = p.getBoolean("rotateQuickSlots", d.rotateQuickSlots),
            quickSlot = p.getInt("quickSlot", d.quickSlot),
            confirmQuickSave = p.getBoolean("confirmQuickSave", d.confirmQuickSave),
            confirmQuickLoad = p.getBoolean("confirmQuickLoad", d.confirmQuickLoad),
            loadLastGameOnStartup = p.getBoolean("loadLastGameOnStartup", d.loadLastGameOnStartup),
            showFps = p.getBoolean("showFps", d.showFps),
            screenEffect = p.getInt("screenEffect", d.screenEffect),
            controlsScale = p.getFloat("controlsScale", d.controlsScale),
            solarLevel = p.getInt("solarLevel", d.solarLevel),
            motionSensitivity = p.getFloat("motionSensitivity", d.motionSensitivity),
            useCustomBios = p.getBoolean("useCustomBios", d.useCustomBios)
        )
    }

    fun save(context: Context, s: AppSettings) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("audioEnabled", s.audioEnabled)
            .putBoolean("vibrateButtons", s.vibrateButtons)
            .putBoolean("rumble", s.rumble)
            .putBoolean("motionControls", s.motionControls)
            .putBoolean("linearFilter", s.linearFilter)
            .putBoolean("integerScale", s.integerScale)
            .putFloat("controlsOpacity", s.controlsOpacity)
            .putFloat("dpadDeadZone", s.dpadDeadZone)
            .putBoolean("disableDiagonals", s.disableDiagonals)
            .putInt("turboClicksPerSecond", s.turboClicksPerSecond)
            .putInt("fastForwardSpeed", s.fastForwardSpeed)
            .putBoolean("rewindEnabled", s.rewindEnabled)
            .putBoolean("autoSaveState", s.autoSaveState)
            .putBoolean("autoLoadState", s.autoLoadState)
            .putInt("timedAutoSaveMinutes", s.timedAutoSaveMinutes)
            .putBoolean("rotateQuickSlots", s.rotateQuickSlots)
            .putInt("quickSlot", s.quickSlot)
            .putBoolean("confirmQuickSave", s.confirmQuickSave)
            .putBoolean("confirmQuickLoad", s.confirmQuickLoad)
            .putBoolean("loadLastGameOnStartup", s.loadLastGameOnStartup)
            .putBoolean("showFps", s.showFps)
            .putInt("screenEffect", s.screenEffect)
            .putFloat("controlsScale", s.controlsScale)
            .putInt("solarLevel", s.solarLevel)
            .putFloat("motionSensitivity", s.motionSensitivity)
            .putBoolean("useCustomBios", s.useCustomBios)
            .apply()
    }
}
