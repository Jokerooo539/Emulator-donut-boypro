package com.donutboypro.emulator

/** JNI boundary for the GBA-only mGBA core. The ROM must first be copied to an app-readable file path. */
class NativeGbaBridge {
    companion object {
        init { System.loadLibrary("donutboypro_native") }
    }

    /** [savePath] is the battery-save (.sav) file (created if missing). [biosPath] may be empty. Returns 0 on failure. */
    external fun create(romPath: String, savePath: String, biosPath: String, solarLevel: Int): Long
    external fun audioSampleRate(handle: Long): Int

    /** Runs one frame. Pass null for [pixels] to skip video, null for [audio] to drop sound. Returns audio frames written, or -1. */
    external fun runFrame(handle: Long, pixels: IntArray?, audio: ShortArray?, rewinding: Boolean): Int
    external fun setKeys(handle: Long, mask: Int)
    external fun saveState(handle: Long, path: String): Boolean
    external fun loadState(handle: Long, path: String): Boolean
    external fun setRewindEnabled(handle: Long, enabled: Boolean)
    external fun setCheats(handle: Long, names: Array<String>, codes: Array<String>, enabled: BooleanArray): Int
    external fun rumbleLevel(handle: Long): Float
    external fun setSensors(handle: Long, ax: Float, ay: Float, gz: Float)
    external fun setSolar(handle: Long, level: Int)
    external fun reset(handle: Long)
    external fun destroy(handle: Long)

    object Key {
        const val A = 0
        const val B = 1
        const val SELECT = 2
        const val START = 3
        const val RIGHT = 4
        const val LEFT = 5
        const val UP = 6
        const val DOWN = 7
        const val R = 8
        const val L = 9
        fun mask(key: Int) = 1 shl key
    }
}
