package com.donutboypro.emulator

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONArray
import org.json.JSONObject

/** User-chosen positions (dp offsets from the default spot) for each on-screen control group, per orientation. */
class ControlLayout(private val context: Context, private val orientation: String) {
    val offsets = mutableStateMapOf<String, Pair<Float, Float>>()

    init {
        val raw = prefs().getString(orientation, null)
        if (raw != null) {
            runCatching {
                val o = JSONObject(raw)
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val a = o.getJSONArray(k)
                    offsets[k] = Pair(a.getDouble(0).toFloat(), a.getDouble(1).toFloat())
                }
            }
        }
    }

    private fun prefs() = context.getSharedPreferences("donut_boy_layout", Context.MODE_PRIVATE)

    fun get(id: String): Pair<Float, Float> = offsets[id] ?: Pair(0f, 0f)

    fun move(id: String, dx: Float, dy: Float) {
        val c = get(id)
        offsets[id] = Pair(c.first + dx, c.second + dy)
    }

    fun save() {
        val o = JSONObject()
        for (entry in offsets.entries) {
            o.put(entry.key, JSONArray().put(entry.value.first.toDouble()).put(entry.value.second.toDouble()))
        }
        prefs().edit().putString(orientation, o.toString()).apply()
    }

    fun reset() {
        offsets.clear()
        save()
    }
}
