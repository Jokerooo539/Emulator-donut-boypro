package com.donutboypro.emulator

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Muted = Color(0xFF9AA8B8)
private val Accent = Color(0xFF72E0C2)
private val CardColor = Color(0xFF1B2430)

@Composable
fun HomeScreen(
    games: List<Game>,
    folders: List<Uri>,
    scanning: Boolean,
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    onImportFiles: () -> Unit,
    onAddFolder: () -> Unit,
    onRescan: () -> Unit,
    onRemoveFolder: (Uri) -> Unit,
    onOpen: (Game) -> Unit,
    onRemove: (Game) -> Unit,
    coverVersion: Int,
    onSetCover: (Game) -> Unit,
    onClearCover: (Game) -> Unit,
    biosPresent: Boolean,
    onImportBios: () -> Unit,
    onRemoveBios: () -> Unit
) {
    var tab by remember { mutableStateOf("Library") }
    Column(Modifier.fillMaxSize().background(Color(0xFF10151D)).statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Text("DONUT BOY PRO", color = Accent, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text("Your GBA game space", color = Color.White, fontSize = 26.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Library", "Settings", "Features").forEach { label ->
                FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            "Library" -> LibraryTab(games, folders, scanning, onImportFiles, onAddFolder, onRescan, onRemoveFolder, onOpen, onRemove, coverVersion, onSetCover, onClearCover)
            "Settings" -> SettingsTab(settings, onSettingsChange, biosPresent, onImportBios, onRemoveBios)
            else -> FeaturesTab()
        }
        Spacer(Modifier.height(8.dp))
        Text("Prototype 0.5.0 • mGBA core • No ROMs or BIOS included", color = Color(0xFF788797), fontSize = 11.sp)
    }
}

@Composable
private fun ColumnScope.LibraryTab(
    games: List<Game>,
    folders: List<Uri>,
    scanning: Boolean,
    onImportFiles: () -> Unit,
    onAddFolder: () -> Unit,
    onRescan: () -> Unit,
    onRemoveFolder: (Uri) -> Unit,
    onOpen: (Game) -> Unit,
    onRemove: (Game) -> Unit,
    coverVersion: Int,
    onSetCover: (Game) -> Unit,
    onClearCover: (Game) -> Unit
) {
    val context = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onImportFiles, modifier = Modifier.weight(1f)) { Text("＋ Games") }
        Button(onClick = onAddFolder, modifier = Modifier.weight(1f)) { Text("📁 Folder") }
        OutlinedButton(onClick = onRescan) { Text(if (scanning) "…" else "↻") }
    }
    Spacer(Modifier.height(6.dp))
    Text(".gba files and .zip archives containing a .gba are supported.", color = Muted, fontSize = 12.sp)
    if (folders.isNotEmpty()) {
        Spacer(Modifier.height(6.dp))
        folders.forEach { folder ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📁 " + (folder.lastPathSegment?.substringAfterLast(':') ?: folder.toString()), color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1)
                TextButton(onClick = { onRemoveFolder(folder) }) { Text("Remove", fontSize = 12.sp) }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    if (games.isEmpty()) {
        EmptyPanel()
    } else {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(games, key = { it.uri.toString() }) { game ->
                val cover by produceState<Bitmap?>(null, game.uri, coverVersion) {
                    value = withContext(Dispatchers.IO) { CoverStore.load(context, game) }
                }
                var menuOpen by remember { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardColor)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.width(84.dp).height(56.dp).background(Color(0xFF10151D), RoundedCornerShape(8.dp)).clickable { onOpen(game) },
                            contentAlignment = Alignment.Center
                        ) {
                            val bmp = cover
                            if (bmp != null) {
                                Image(bitmap = bmp.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            } else {
                                Text("🎮", fontSize = 22.sp)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f).clickable { onOpen(game) }) {
                            Text(game.title, color = Color.White, maxLines = 2)
                            Text(
                                (if (game.isZip) "GBA • zip" else "GBA") + (if (game.fromFolder) " • folder" else "") + " • tap to play",
                                color = Muted, fontSize = 12.sp
                            )
                        }
                        Box {
                            TextButton(onClick = { menuOpen = true }) { Text("⋮", color = Color.White, fontSize = 18.sp) }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(text = { Text("Set cover image…") }, onClick = { menuOpen = false; onSetCover(game) })
                                if (cover != null) DropdownMenuItem(text = { Text("Remove cover") }, onClick = { menuOpen = false; onClearCover(game) })
                                if (!game.fromFolder) DropdownMenuItem(text = { Text("Remove from library") }, onClick = { menuOpen = false; onRemove(game) })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.SettingsTab(
    s: AppSettings, onChange: (AppSettings) -> Unit,
    biosPresent: Boolean, onImportBios: () -> Unit, onRemoveBios: () -> Unit
) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        SectionTitle("Sound & feedback")
        SwitchRow("Sound", "Play game audio", s.audioEnabled) { onChange(s.copy(audioEnabled = it)) }
        SwitchRow("Button vibration", "Short haptic tick on every touch button", s.vibrateButtons) { onChange(s.copy(vibrateButtons = it)) }
        SwitchRow("Rumble", "Vibrate for games with a rumble cartridge", s.rumble) { onChange(s.copy(rumble = it)) }
        SwitchRow("Motion controls", "Tilt / gyro for games that use them (next game start)", s.motionControls) { onChange(s.copy(motionControls = it)) }
        SliderRow("Motion sensitivity", "${(s.motionSensitivity * 100).roundToInt()}%", s.motionSensitivity, 0.3f..3f, 0) { onChange(s.copy(motionSensitivity = it)) }
        SliderRow("Default sun level", "${s.solarLevel}", s.solarLevel.toFloat(), 0f..255f, 0) { onChange(s.copy(solarLevel = it.roundToInt())) }

        SectionTitle("Video")
        SwitchRow("Smooth filtering", "Linear filtering instead of sharp pixels", s.linearFilter) { onChange(s.copy(linearFilter = it)) }
        SwitchRow("Perfect pixel match", "Only whole-number scaling (can leave borders)", s.integerScale) { onChange(s.copy(integerScale = it)) }
        SwitchRow("Show FPS", "Frame counter in portrait mode", s.showFps) { onChange(s.copy(showFps = it)) }
        val effects = listOf("Off", "Scanlines", "LCD grid", "GBA colours", "Scanlines + GBA colours")
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Screen effect", color = Color.White)
                Text(effects[s.screenEffect.coerceIn(0, effects.size - 1)], color = Muted, fontSize = 12.sp)
            }
            OutlinedButton(onClick = { onChange(s.copy(screenEffect = (s.screenEffect + 1) % effects.size)) }) { Text("Change") }
        }

        SectionTitle("Controls")
        SliderRow("Controls opacity", "${(s.controlsOpacity * 100).roundToInt()}%", s.controlsOpacity, 0.2f..1f, 0) { onChange(s.copy(controlsOpacity = it)) }
        SliderRow("Controls size", "${(s.controlsScale * 100).roundToInt()}%", s.controlsScale, 0.6f..1.5f, 0) { onChange(s.copy(controlsScale = it)) }
        SliderRow("D-pad dead zone", "${(s.dpadDeadZone * 100).roundToInt()}%", s.dpadDeadZone, 0.05f..0.6f, 0) { onChange(s.copy(dpadDeadZone = it)) }
        SwitchRow("Disable d-pad diagonals", "Only one direction at a time", s.disableDiagonals) { onChange(s.copy(disableDiagonals = it)) }
        SliderRow("Turbo speed", "${s.turboClicksPerSecond} presses/sec", s.turboClicksPerSecond.toFloat(), 2f..30f, 0) { onChange(s.copy(turboClicksPerSecond = it.roundToInt())) }

        SectionTitle("Speed & rewind")
        SliderRow("Fast-forward speed", "${s.fastForwardSpeed}x", s.fastForwardSpeed.toFloat(), 2f..8f, 5) { onChange(s.copy(fastForwardSpeed = it.roundToInt())) }
        SwitchRow("Rewind", "Hold ⏪ to rewind about 30 seconds (next game start)", s.rewindEnabled) { onChange(s.copy(rewindEnabled = it)) }

        SectionTitle("Saving")
        SwitchRow("Auto save state", "Save automatically when leaving a game", s.autoSaveState) { onChange(s.copy(autoSaveState = it)) }
        SwitchRow("Auto load state", "Resume where you left off when starting a game", s.autoLoadState) { onChange(s.copy(autoLoadState = it)) }
        SliderRow("Timed auto save", if (s.timedAutoSaveMinutes == 0) "Off" else "every ${s.timedAutoSaveMinutes} min", s.timedAutoSaveMinutes.toFloat(), 0f..15f, 14) { onChange(s.copy(timedAutoSaveMinutes = it.roundToInt())) }
        SwitchRow("Rotate quick-save slots", "Quick save cycles through 4 slots", s.rotateQuickSlots) { onChange(s.copy(rotateQuickSlots = it)) }
        if (!s.rotateQuickSlots) {
            SliderRow("Quick-save slot", "Slot ${s.quickSlot}", s.quickSlot.toFloat(), 1f..8f, 6) { onChange(s.copy(quickSlot = it.roundToInt())) }
        }
        SwitchRow("Confirm quick save", null, s.confirmQuickSave) { onChange(s.copy(confirmQuickSave = it)) }
        SwitchRow("Confirm quick load", null, s.confirmQuickLoad) { onChange(s.copy(confirmQuickLoad = it)) }

        SectionTitle("BIOS (optional)")
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Your GBA BIOS file", color = Color.White)
                Text(if (biosPresent) "gba_bios.bin loaded (16 KB)" else "Not set — the built-in replacement BIOS is used", color = Muted, fontSize = 12.sp)
            }
            if (biosPresent) TextButton(onClick = onRemoveBios) { Text("Remove") }
            OutlinedButton(onClick = onImportBios) { Text(if (biosPresent) "Replace" else "Import") }
        }
        SwitchRow("Use my BIOS", "Boot with the real BIOS (needs a valid 16 KB file; next game start)", s.useCustomBios) { onChange(s.copy(useCustomBios = it)) }

        SectionTitle("Startup")
        SwitchRow("Load last game on startup", "Open the last game you played automatically", s.loadLastGameOnStartup) { onChange(s.copy(loadLastGameOnStartup = it)) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ColumnScope.FeaturesTab() {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        FeatureStatus("Audio", "Active — stereo output, synced to the game speed")
        FeatureStatus("Battery saves", "Active — in-game saves (SRAM/Flash/EEPROM) kept per game")
        FeatureStatus("Save states", "Active — 8 slots, quick save/load, auto & timed auto save, quick-slot rotation")
        FeatureStatus("Fast-forward & rewind", "Active — 2x–8x fast-forward, hold-to-rewind")
        FeatureStatus("Cheats", "Active — GameShark / Action Replay / CodeBreaker, .cht import")
        FeatureStatus("Controls", "Active — multi-touch, turbo, A+B macro, d-pad dead zone, physical gamepads")
        FeatureStatus("ROM library", "Active — files, folders, zip archives, last-game startup")
        FeatureStatus("Video", "Active — sharp / smooth, perfect-pixel scaling, screenshots")
        FeatureStatus("Rumble & motion", "Active — rumble cartridges, tilt & gyro (needs device testing)")
        FeatureStatus("Screen effects", "Active — scanlines, LCD grid, GBA colour tint")
        FeatureStatus("Movable controls", "Active — drag, resize, per orientation")
        FeatureStatus("GIF recording", "Active — 30 fps, up to 20 s, saved to Pictures/DonutBoyPro")
        FeatureStatus("Per-game settings", "Active — video, controls and sun level are remembered per game")
        FeatureStatus("Cover art & BIOS import", "Active — gallery covers, automatic cover from play, your own BIOS")
        FeatureStatus("Solar sensor", "Active — adjustable sun level for Boktai-style games")
        FeatureStatus("Custom skins, shader packs", "Planned")
        FeatureStatus("RetroAchievements, link-cable multiplayer", "Planned")
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(14.dp))
    Text(text.uppercase(), color = Accent, fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun SwitchRow(title: String, summary: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White)
            if (summary != null) Text(summary, color = Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(title: String, valueLabel: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row {
            Text(title, color = Color.White, modifier = Modifier.weight(1f))
            Text(valueLabel, color = Muted, fontSize = 12.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun EmptyPanel() {
    Box(Modifier.fillMaxWidth().height(210.dp).background(CardColor, RoundedCornerShape(20.dp)).padding(20.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎮", fontSize = 38.sp)
            Spacer(Modifier.height(10.dp))
            Text("Your GBA library is empty", color = Color.White)
            Text("Add games or a folder of your legally obtained .gba files.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun FeatureStatus(title: String, status: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = CardColor)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.White)
            Text(status, color = if (status.startsWith("Active")) Accent else Color(0xFFFFC66D), fontSize = 12.sp)
        }
    }
}
